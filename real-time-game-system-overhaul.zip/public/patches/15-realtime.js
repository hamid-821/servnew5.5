/* 📡 اتصال زندهٔ سرور (SSE) + انتشار فوری پست/استوری/چت + اعلان سراسری مدیر + تنظیمات آنلاین
   - یک اتصال EventSource به /api/events با reconnect و backoff؛ در تب غیرفعال بسته می‌شود
   - پست/استوری/پیام تازهٔ کاربران واقعی زیر ۱ ثانیه در store بازی همهٔ کاربران می‌نشیند
   - اعلان مدیر به‌صورت پنجره نمایش داده می‌شود و با کلیک به بخش تعریف‌شده می‌رود
   - تغییر متن/لوگو/تنظیمات مدیر بدون رفرش اعمال می‌شود */
(function () {
  "use strict";
  if (window.__gamifyRealtime) return;
  window.__gamifyRealtime = true;

  var LS_KEY = "gamify2-store-v2";
  var META_KEY = "gamify2-server";
  var es = null, backoff = 1000, closedByUs = false, connected = false, lastEventAt = 0;
  var handlers = {};
  var seenIds = {};

  function readStore() { try { return JSON.parse(localStorage.getItem(LS_KEY) || "null"); } catch (e) { return null; } }
  function liveStore() { try { if (window.__gamifyLiveGet) { var s = window.__gamifyLiveGet(); if (s && typeof s === "object") return s; } } catch (e) {} return readStore(); }
  function meta() { try { return JSON.parse(localStorage.getItem(META_KEY) || "{}"); } catch (e) { return {}; } }
  function setStore(fn) {
    try {
      if (window.__gamifyLiveSet) { window.__gamifyLiveSet(function (s) { var n = fn(s); return n || s; }); return true; }
      var st = readStore(); if (!st) return false; var n2 = fn(st); localStorage.setItem(LS_KEY, JSON.stringify(n2 || st)); return true;
    } catch (e) { return false; }
  }
  function esc(s) { return String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  function toast(m) { try { if (window.__gamifyToast) return window.__gamifyToast(m); } catch (e) {} try { console.log("[gamify]", m); } catch (e) {} }
  function uid(p) { return (p || "id") + "-" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }
  function profile() { var s = liveStore(); return s && s.profile && s.profile.id ? s.profile : null; }
  function serverId() { return meta().serverId || null; }

  // ---------- رویداد ----------
  function on(type, fn) { (handlers[type] = handlers[type] || []).push(fn); }
  function emit(type, data) {
    (handlers[type] || []).forEach(function (fn) { try { fn(data); } catch (e) {} });
    try { window.dispatchEvent(new CustomEvent("gamify:rt", { detail: { type: type, data: data } })); } catch (e) {}
  }

  var TYPES = ["hello", "ping", "pvp:invite", "pvp:outgoing", "pvp:accepted", "pvp:q", "pvp:reveal", "pvp:opp-answered", "pvp:finished", "pvp:update",
    "feed:post", "feed:story", "chat:message", "broadcast", "broadcast:remove", "config", "notice", "profile:avatar", "profile:coins", "tribe:joined", "tribe:left", "moderation:pending"];

  function connect() {
    if (es || closedByUs) return;
    if (document.hidden) return;
    var tok = meta().token || "";
    var p = profile();
    if (!p && !tok) return; // هنوز پروفایل ساخته نشده
    var qs = [];
    if (tok) qs.push("token=" + encodeURIComponent(tok));
    if (p) qs.push("uid=" + encodeURIComponent(p.id));
    try {
      es = new EventSource("/api/events?" + qs.join("&"), { withCredentials: true });
    } catch (e) { es = null; scheduleReconnect(); return; }
    TYPES.forEach(function (t) {
      es.addEventListener(t, function (ev) {
        lastEventAt = Date.now();
        var data = null; try { data = JSON.parse(ev.data); } catch (e) { data = ev.data; }
        if (t === "hello") { connected = true; backoff = 1000; emit("connected", data); return; }
        if (t === "ping") return;
        emit(t, data);
      });
    });
    es.onerror = function () {
      try { es.close(); } catch (e) {}
      es = null; connected = false;
      emit("disconnected", {});
      scheduleReconnect();
    };
  }
  function scheduleReconnect() {
    if (closedByUs) return;
    setTimeout(function () { backoff = Math.min(backoff * 1.7, 20000); connect(); }, backoff + Math.random() * 400);
  }
  function disconnect() { if (es) { try { es.close(); } catch (e) {} es = null; connected = false; } }

  document.addEventListener("visibilitychange", function () {
    if (document.hidden) disconnect(); else { backoff = 1000; connect(); emit("resume", {}); }
  });
  window.addEventListener("beforeunload", function () { closedByUs = true; disconnect(); });
  window.addEventListener("gamify:synced", function () { if (!es) connect(); });

  // ---------- ورود مهمان خودکار: همهٔ امکانات بدون «ابتدا وارد شو» ----------
  function ensureGuest() {
    if (profile()) return;
    var ok = setStore(function (s) {
      if (s.profile && s.profile.id) return s;
      var av = window.__gmAvatarFor ? window.__gmAvatarFor("مهمان") : { img: 7 };
      return {
        ...s,
        profile: {
          id: uid("u"), name: "میهمان " + Math.floor(100 + Math.random() * 900), avatar: av,
          bio: "هر روز یک چیز تازه یاد می‌گیرم.", provider: "guest", xp: 0, coins: 50, cups: 0, rating: 1000, streak: 0, lastDaily: "",
          played: 0, wins: 0, interests: ["general"], interestsSet: false, chatPrivacy: "all", friends: [], org: "", createdAt: Date.now(), inventory: [], title: ""
        }
      };
    });
    if (ok) { try { window.dispatchEvent(new CustomEvent("gamify:profile-changed")); } catch (e) {} }
  }
  window.__gamifyEnsureGuest = ensureGuest;

  // ---------- پست/استوری فوری ----------
  function pushPost(d) {
    if (!d || !d.id || seenIds["p" + d.id]) return; seenIds["p" + d.id] = 1;
    var me = profile(); if (me && (d.authorId === me.id || d.authorId === serverId())) return;
    setStore(function (s) {
      if ((s.posts || []).some(function (p) { return p && (p.id === d.id || p.id === "srv-" + d.id); })) return s;
      var post = { id: "srv-" + d.id, author: d.author || "بازیکن", authorId: d.authorId, avatar: d.avatar || 1, category: d.category || "work", body: d.body || "", media: d.media || "", audio: d.audio || "", likes: 0, liked: false, saved: false, comments: [], at: d.at || Date.now(), status: "approved", real: true };
      return { ...s, posts: [post].concat(s.posts || []).slice(0, 400) };
    });
    toast("📝 پست تازه از " + (d.author || "یک بازیکن واقعی"));
  }
  function pushStory(d) {
    if (!d || !d.id || seenIds["s" + d.id]) return; seenIds["s" + d.id] = 1;
    var me = profile(); if (me && (d.authorId === me.id || d.authorId === serverId())) return;
    setStore(function (s) {
      if ((s.stories || []).some(function (p) { return p && (p.id === d.id || p.id === "srv-" + d.id); })) return s;
      var story = { id: "srv-" + d.id, author: d.author || "بازیکن", authorId: d.authorId, avatar: d.avatar || 1, text: d.title || "", title: d.title || "", options: d.options || [], correct: d.correct || 0, explanation: d.explanation || "", image: d.media || "", color: "#8960c5", at: d.at || Date.now(), expiresAt: d.expiresAt || (Date.now() + 86400000), status: "approved", views: 0, real: true };
      return { ...s, stories: [story].concat(s.stories || []).slice(0, 200) };
    });
    toast("📸 استوری تازه از " + (d.author || "یک بازیکن واقعی"));
  }
  on("feed:post", pushPost);
  on("feed:story", pushStory);

  // آینهٔ فوری پست/استوری خودم (به‌جای انتظار ۲۰ ثانیه)
  var mirrored = {};
  try { var mm = meta(); mirrored = Object.assign({}, mm.mirroredPosts || {}, mm.mirroredStories || {}); } catch (e) {}
  function mirrorNow() {
    var s = liveStore(); if (!s || !s.profile) return;
    var my = s.profile.id;
    (s.posts || []).filter(function (p) { return p && p.authorId === my && !mirrored[p.id] && String(p.id).indexOf("srv-") !== 0; }).slice(0, 3).forEach(function (p) {
      mirrored[p.id] = 1; persistMirror("mirroredPosts", p.id);
      fetch("/api/feed?type=post", { method: "POST", headers: { "Content-Type": "application/json" }, credentials: "include",
        body: JSON.stringify({ id: String(p.id).slice(0, 60), category: p.category || "work", body: p.body || "", media: typeof p.media === "string" && p.media.length < 200000 ? p.media : "" }) })
        .then(function (r) { return r.json(); }).then(function (j) {
          if (j && j.status === "pending") toast("⏳ پستت برای تأیید مدیر فرستاده شد");
          else if (j && j.ok) { setStore(function (st) { return { ...st, posts: (st.posts || []).map(function (x) { return x && x.id === p.id ? { ...x, status: "approved" } : x; }) }; }); }
        }).catch(function () {});
    });
    (s.stories || []).filter(function (st) { return st && st.authorId === my && !mirrored[st.id] && String(st.id).indexOf("srv-") !== 0; }).slice(0, 3).forEach(function (st) {
      mirrored[st.id] = 1; persistMirror("mirroredStories", st.id);
      fetch("/api/feed?type=story", { method: "POST", headers: { "Content-Type": "application/json" }, credentials: "include",
        body: JSON.stringify({ id: String(st.id).slice(0, 60), category: st.category || "general", title: st.title || st.text || st.body || "", options: st.options || [], correct: st.correct || 0, explanation: st.explanation || "", media: typeof st.image === "string" && st.image.length < 200000 ? st.image : (typeof st.media === "string" ? st.media : "") }) })
        .then(function (r) { return r.json(); }).then(function (j) {
          if (j && j.status === "pending") toast("⏳ استوری‌ات برای تأیید مدیر فرستاده شد");
          else if (j && j.ok) { setStore(function (x) { return { ...x, stories: (x.stories || []).map(function (y) { return y && y.id === st.id ? { ...y, status: "approved" } : y; }) }; }); }
        }).catch(function () {});
    });
  }
  function persistMirror(key, id) { try { var m = meta(); m[key] = m[key] || {}; m[key][id] = 1; localStorage.setItem(META_KEY, JSON.stringify(m)); } catch (e) {} }
  // تشخیص تغییر store (هوک روی ذخیره‌کنندهٔ بازی)
  (function hookStore() {
    var orig = window.__gamifyLiveSet;
    if (typeof orig !== "function") { setTimeout(hookStore, 300); return; }
    if (orig.__gmHooked) return;
    var wrapped = function (fn) { var r = orig.apply(this, arguments); try { setTimeout(mirrorNow, 50); } catch (e) {} return r; };
    wrapped.__gmHooked = true;
    window.__gamifyLiveSet = wrapped;
  })();

  // بارگذاری اولیهٔ پست/استوری‌های سرور (آخرین ۶۰)
  function loadServerFeed() {
    fetch("/api/feed?type=posts", { credentials: "include" }).then(function (r) { return r.json(); }).then(function (rows) {
      if (!Array.isArray(rows)) return;
      rows.slice().reverse().forEach(function (p) { pushPostSilent(p); });
    }).catch(function () {});
    fetch("/api/feed?type=stories", { credentials: "include" }).then(function (r) { return r.json(); }).then(function (rows) {
      if (!Array.isArray(rows)) return;
      rows.filter(function (s) { return (s.expiresAt || 0) > Date.now(); }).slice().reverse().forEach(function (st) {
        seenIds["s" + st.id] = 1;
        var me = profile(); if (me && st.userId === me.id) return;
        setStore(function (s) {
          if ((s.stories || []).some(function (p) { return p && (p.id === st.id || p.id === "srv-" + st.id); })) return s;
          return { ...s, stories: [{ id: "srv-" + st.id, author: st.userName || "بازیکن", authorId: st.userId, avatar: 1, text: st.title, title: st.title, options: st.options || [], correct: st.correct || 0, explanation: st.explanation || "", image: st.media || "", color: "#8960c5", at: st.createdAt, expiresAt: st.expiresAt, status: "approved", views: 0, real: true }].concat(s.stories || []).slice(0, 200) };
        });
      });
    }).catch(function () {});
  }
  function pushPostSilent(p) {
    seenIds["p" + p.id] = 1;
    var me = profile(); if (me && (p.userId === me.id || p.userId === serverId())) return;
    setStore(function (s) {
      if ((s.posts || []).some(function (x) { return x && (x.id === p.id || x.id === "srv-" + p.id); })) return s;
      return { ...s, posts: [{ id: "srv-" + p.id, author: p.userName || "بازیکن", authorId: p.userId, avatar: 1, category: p.category || "work", body: p.body || "", media: p.media || "", audio: p.audio || "", likes: p.likes || 0, liked: false, saved: false, comments: [], at: p.createdAt, status: "approved", real: true }].concat(s.posts || []).sort(function (a, b) { return (b.at || 0) - (a.at || 0); }).slice(0, 400) };
    });
  }

  // ---------- چت فوری ----------
  on("chat:message", function (d) {
    if (!d || !d.id) return;
    var key = "srv-" + d.id;
    setStore(function (s) {
      if ((s.messages || []).some(function (m) { return m && m.id === key; })) return s;
      var players = s.players || [];
      if (!players.some(function (p) { return p && p.id === d.from; })) {
        players = players.concat([{ id: d.from, name: d.fromName || "بازیکن", avatar: d.avatar || 1, bio: "بازیکن واقعی", xp: 0, cups: 0, rating: 1000, wins: 0, played: 0, weekXp: 0, org: "", publicVisible: true, chatPrivacy: "all", kind: "real", banned: false, lastSeen: Date.now() }]);
      }
      return { ...s, players: players, messages: (s.messages || []).concat([{ id: key, thread: d.from, from: "them", text: d.text || "", media: d.media || "", at: d.at || Date.now(), read: false, real: true }]) };
    });
    toast("💬 " + (d.fromName || "پیام جدید") + ": " + String(d.text || "").slice(0, 50));
    try { window.dispatchEvent(new CustomEvent("gamify:dm", { detail: { fresh: 1 } })); } catch (e) {}
  });

  // ---------- اعلان سراسری مدیر (پنجره) ----------
  var shownBroadcast = {};
  try { shownBroadcast = JSON.parse(localStorage.getItem("gamify2-bc-seen") || "{}"); } catch (e) {}
  function goSection(link) {
    if (!link) return;
    if (/^https?:\/\//.test(link)) { window.open(link, "_blank", "noopener"); return; }
    var l = String(link).replace(/^#/, "");
    if (l === "tribes" && window.__gamifyTribes && window.__gamifyTribes.open) return window.__gamifyTribes.open();
    if (l === "pvp" && window.__gamifyPvP && window.__gamifyPvP.open) return window.__gamifyPvP.open();
    if (l === "arena" && window.__gamifyArena && window.__gamifyArena.open) return window.__gamifyArena.open();
    location.hash = "#" + l;
  }
  window.__gamifyGo = goSection;
  function showBroadcast(b, force) {
    if (!b || !b.id) return;
    if (!force && shownBroadcast[b.id]) return;
    var me = profile();
    if (b.target === "real" && me && me.provider === "guest") return;
    if (b.target && b.target.indexOf("org:") === 0 && (!me || me.org !== b.target.slice(4))) return;
    shownBroadcast[b.id] = Date.now();
    try { localStorage.setItem("gamify2-bc-seen", JSON.stringify(shownBroadcast)); } catch (e) {}
    var old = document.getElementById("gm-broadcast"); if (old) old.remove();
    var d = document.createElement("div");
    d.id = "gm-broadcast";
    d.className = "gamify-overlay open gm-bc-overlay";
    d.innerHTML = '<div class="gamify-modal gm-bc" role="dialog" aria-modal="true">' +
      '<button class="gm-bc-x" aria-label="بستن">✕</button>' +
      (b.image ? '<img class="gm-bc-img" src="' + esc(b.image) + '" alt="">' : "") +
      '<h3>' + esc(b.title) + "</h3>" + (b.body ? "<p>" + esc(b.body) + "</p>" : "") +
      (b.link ? '<button class="gamify-btn gm-bc-go">مشاهده ⬅</button>' : "") + "</div>";
    document.body.appendChild(d);
    d.querySelector(".gm-bc-x").addEventListener("click", function () { d.remove(); });
    d.addEventListener("click", function (e) { if (e.target === d) d.remove(); });
    var go = d.querySelector(".gm-bc-go");
    if (go) go.addEventListener("click", function () { d.remove(); goSection(b.link); });
  }
  on("broadcast", function (b) { showBroadcast(b, true); });
  on("broadcast:remove", function (b) { var d = document.getElementById("gm-broadcast"); if (d) d.remove(); });
  on("notice", function (n) { toast((n.title || "🔔") + (n.body ? " — " + n.body : "")); });
  on("profile:avatar", function (d) { if (d && d.avatar) setStore(function (s) { return s.profile ? { ...s, profile: { ...s.profile, avatar: d.avatar } } : s; }); toast("🖼️ آواتارت توسط مدیر به‌روز شد"); });
  on("profile:coins", function (d) { if (d && d.delta) setStore(function (s) { return s.profile ? { ...s, profile: { ...s.profile, coins: Math.max(0, (s.profile.coins || 0) + d.delta) } } : s; }); });
  on("tribe:joined", function (d) { toast("🛡️ به قبیلهٔ «" + (d.name || "") + "» اضافه شدی"); });

  // ---------- تنظیمات و متن‌های آنلاین ----------
  var textMap = {}, assetMap = {}, cfgLoaded = false;
  function applyConfig(cfg) {
    if (!cfg) return;
    cfgLoaded = true;
    textMap = cfg.textOverrides || {};
    assetMap = cfg.assetOverrides || {};
    window.__gamifyConfig = cfg;
    if (cfg.settings) setStore(function (s) { return { ...s, settings: { ...(s.settings || {}), ...cfg.settings } }; });
    if (cfg.settings && cfg.settings.siteTitle) { try { document.title = cfg.settings.siteTitle; } catch (e) {} }
    applyTextOverrides(document.body);
    applyAssets(document.body);
    (cfg.broadcasts || []).forEach(function (b) { showBroadcast(b, false); });
    try { window.dispatchEvent(new CustomEvent("gamify:config", { detail: cfg })); } catch (e) {}
  }
  function loadConfig() {
    fetch("/admin-config.json?t=" + Date.now(), { cache: "no-cache", credentials: "include" }).then(function (r) { return r.ok ? r.json() : null; }).then(applyConfig).catch(function () {});
  }
  on("config", loadConfig);
  var keys = [];
  function applyTextOverrides(root) {
    keys = Object.keys(textMap).filter(function (k) { return k && k.length >= 2 && textMap[k] != null; });
    if (!keys.length || !root) return;
    var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null);
    var nodes = [];
    while (walker.nextNode()) nodes.push(walker.currentNode);
    nodes.forEach(function (n) {
      var v = n.nodeValue; if (!v || !v.trim()) return;
      var p = n.parentNode; if (!p || p.nodeName === "SCRIPT" || p.nodeName === "STYLE" || p.nodeName === "TEXTAREA" || p.isContentEditable) return;
      var t = v.trim();
      if (textMap[t] != null) { if (v !== v.replace(t, textMap[t])) n.nodeValue = v.replace(t, textMap[t]); return; }
      var out = v;
      keys.forEach(function (k) { if (k.length >= 4 && out.indexOf(k) >= 0) out = out.split(k).join(textMap[k]); });
      if (out !== v) n.nodeValue = out;
    });
    if (root.querySelectorAll) root.querySelectorAll("input[placeholder],textarea[placeholder]").forEach(function (el) { var ph = el.getAttribute("placeholder"); if (textMap[ph] != null) el.setAttribute("placeholder", textMap[ph]); });
  }
  function applyAssets(root) {
    var ks = Object.keys(assetMap); if (!ks.length || !root || !root.querySelectorAll) return;
    root.querySelectorAll("img[src]").forEach(function (img) {
      var src = img.getAttribute("src") || "";
      ks.forEach(function (k) { if (k && (src === k || (k.length > 8 && src.indexOf(k) === 0)) && assetMap[k] && src !== assetMap[k]) img.setAttribute("src", assetMap[k]); });
    });
  }
  var pending = false;
  var mo = new MutationObserver(function (muts) {
    if (pending) return;
    pending = true;
    requestAnimationFrame(function () {
      pending = false;
      if (!Object.keys(textMap).length && !Object.keys(assetMap).length) return;
      muts.forEach(function (m) {
        if (m.type === "characterData") { var p = m.target.parentNode; if (p) applyTextOverrides(p); }
        m.addedNodes && m.addedNodes.forEach(function (n) { if (n.nodeType === 1) { applyTextOverrides(n); applyAssets(n); } else if (n.nodeType === 3 && n.parentNode) applyTextOverrides(n.parentNode); });
      });
    });
  });
  try { mo.observe(document.documentElement, { childList: true, subtree: true, characterData: true }); } catch (e) {}

  // ---------- API عمومی ----------
  window.__gamifyRT = {
    on: on, connected: function () { return connected; }, reconnect: function () { disconnect(); backoff = 1000; connect(); },
    showBroadcast: showBroadcast, go: goSection, lastEventAt: function () { return lastEventAt; }, reloadConfig: loadConfig,
    mirrorNow: mirrorNow,
  };

  function boot() {
    ensureGuest();
    loadConfig();
    setTimeout(function () { connect(); loadServerFeed(); }, 1200);
    setTimeout(ensureGuest, 4000);
    // نگهبان اتصال: اگر ۷۰ ثانیه رویدادی (حتی ping) نیامد، دوباره وصل شو
    setInterval(function () { if (!document.hidden && (!es || (lastEventAt && Date.now() - lastEventAt > 70000))) { disconnect(); connect(); } }, 15000);
    // چرخهٔ پشتیبان بسیار کم‌تکرار برای زمانی که SSE در دسترس نیست
    setInterval(function () { if (!connected && !document.hidden) loadServerFeed(); }, 45000);
  }
  if (document.readyState === "complete" || document.readyState === "interactive") setTimeout(boot, 400);
  else document.addEventListener("DOMContentLoaded", function () { setTimeout(boot, 400); });
})();
