/* 🛠️ پنل مدیریت سرور — همه‌چیز آنلاین و برخط
   - ورود مدیر با کد مدیریت که سمت سرور بررسی می‌شود (توکن امضاشده؛ هدر x-admin-token)
   - کاربران واقعی/مهمان/ربات/مدیر جدا، جست‌وجو و صفحه‌بندی سمت سرور، نمایش موبایل/ایمیل با ثبت در لاگ ممیزی
   - تغییر آواتار، عضو کردن در قبیله، سازمان، سکه، بن، ادمین، حذف
   - ترتیب‌دادن مسابقهٔ زنده بین دو کاربر واقعی
   - اعلان سراسری (عکس + متن + لینک به بخش بازی) به‌صورت پنجره
   - تنظیمات سایت (عنوان، شعار، لوگو، بنرها، بخش‌های مخفی)، تأیید پست/استوری، تغییر هر متن و تصویر */
(function () {
  "use strict";
  if (window.__gamifyAdminPanel) return;
  window.__gamifyAdminPanel = true;

  var TOK_KEY = "gamify2-admin-token";
  var LS_KEY = "gamify2-store-v2";
  var S = { ov: null, tab: "users", kind: "real", q: "", page: 1, data: null, token: localStorage.getItem(TOK_KEY) || "", name: "", sel: {}, settings: null, categories: [], tribes: [], orgs: [], matchA: "", matchB: "", revealed: {} };

  function readStore() { try { return JSON.parse(localStorage.getItem(LS_KEY) || "null"); } catch (e) { return null; } }
  function liveStore() { try { if (window.__gamifyLiveGet) return window.__gamifyLiveGet(); } catch (e) {} return readStore(); }
  function esc(s) { return String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  function fa(n) { try { return Number(n || 0).toLocaleString("fa-IR"); } catch (e) { return String(n || 0); } }
  function toast(m) { try { if (window.__gamifyToast) return window.__gamifyToast(m); } catch (e) {} alert(m); }
  function ago(ts) { if (!ts) return "—"; var d = Date.now() - ts; if (d < 60000) return "همین الان"; if (d < 3600000) return fa(Math.floor(d / 60000)) + " دقیقه پیش"; if (d < 86400000) return fa(Math.floor(d / 3600000)) + " ساعت پیش"; return fa(Math.floor(d / 86400000)) + " روز پیش"; }
  function avSrc(av) { var pad = function (n) { return String(n).padStart(2, "0"); }; if (av && typeof av === "object" && av.img) return "/assets/avatars/" + pad(av.img) + ".png"; if (typeof av === "number") return "/assets/avatars/" + pad(((av % 20) + 20) % 20 + 1) + ".png"; return "/assets/avatars/07.png"; }
  function headers() { var h = { "Content-Type": "application/json" }; if (S.token) h["x-admin-token"] = S.token; return h; }
  function api(path, method, body) {
    return fetch(path, { method: method || "GET", credentials: "include", headers: headers(), body: body ? JSON.stringify(body) : undefined })
      .then(function (r) { return r.text().then(function (t) { var j; try { j = JSON.parse(t); } catch (e) { j = { error: "server " + r.status }; } return { status: r.status, body: j }; }); })
      .catch(function () { return { status: 0, body: { error: "network" } }; });
  }
  function localAdmin() { var st = liveStore(); return !!(st && (st.admin === true || (st.profile && st.profile.role === "admin"))); }

  // ---------- ورود ----------
  function login(cb) {
    var code = prompt("کد مدیریت را وارد کن (سمت سرور بررسی می‌شود):");
    if (!code) return;
    var st = liveStore();
    api("/api/admin?action=login", "POST", { code: code, name: (st && st.adminName) || (st && st.profile && st.profile.name) || "مدیر" }).then(function (r) {
      if (!r.body || r.body.error) return toast("⚠️ " + (r.body && r.body.error || "ورود ناموفق"));
      S.token = r.body.token; S.name = r.body.name; localStorage.setItem(TOK_KEY, S.token);
      toast("✅ ورود مدیر سرور انجام شد");
      if (cb) cb();
    });
  }
  window.__gamifyAdminHeaders = headers;
  window.__gamifyAdminToken = function () { return S.token; };

  // ---------- پنل ----------
  function ensure() {
    if (S.ov) return S.ov;
    var ov = document.createElement("div"); ov.className = "gamify-overlay"; ov.id = "gm-admin-overlay";
    ov.addEventListener("click", function (e) { if (e.target === ov) close(); });
    document.body.appendChild(ov); S.ov = ov; return ov;
  }
  function open() { var ov = ensure(); ov.classList.add("open"); render(); load(); }
  function close() { if (S.ov) S.ov.classList.remove("open"); }

  function load() {
    if (!S.token) { render(); return; }
    var p;
    if (S.tab === "users" || S.tab === "match") p = api("/api/admin?view=users&kind=" + encodeURIComponent(S.tab === "match" ? "real" : S.kind) + "&q=" + encodeURIComponent(S.q) + "&page=" + S.page + "&size=30");
    else if (S.tab === "overview") p = api("/api/admin?view=overview");
    else if (S.tab === "broadcast") p = api("/api/admin?view=broadcasts");
    else if (S.tab === "settings") p = api("/api/admin?view=settings");
    else if (S.tab === "categories") p = api("/api/admin?view=categories");
    else p = Promise.resolve({ body: {} });
    Promise.all([p, S.tribes.length ? null : api("/api/admin?view=tribes"), S.orgs.length ? null : api("/api/admin?view=orgs"), S.categories.length ? null : api("/api/admin?view=categories")]).then(function (res) {
      if (res[0].status === 403) { S.token = ""; localStorage.removeItem(TOK_KEY); render(); return; }
      S.data = res[0].body;
      if (res[1] && Array.isArray(res[1].body)) S.tribes = res[1].body;
      if (res[2] && Array.isArray(res[2].body)) S.orgs = res[2].body;
      if (res[3] && Array.isArray(res[3].body)) S.categories = res[3].body;
      if (S.tab === "categories" && Array.isArray(S.data)) S.categories = S.data;
      if (S.tab === "settings") S.settings = S.data;
      render();
    });
  }

  var TABS = [["overview", "📊 نمای کلی"], ["users", "👥 کاربران"], ["match", "🏟️ مسابقهٔ دونفره"], ["broadcast", "📣 اعلان سراسری"], ["settings", "⚙️ تنظیمات و متن‌ها"], ["categories", "🗂️ دسته‌ها"]];

  function render() {
    var ov = ensure(); if (!ov.classList.contains("open")) return;
    var head = '<div class="gamify-modal-head"><b>🛠️ پنل مدیریت سرور' + (S.name ? " — " + esc(S.name) : "") + '</b><button class="gamify-btn sm" data-x="1">✕</button></div>';
    if (!S.token) {
      ov.innerHTML = '<div class="gamify-modal gm-admin">' + head + '<div class="gamify-empty"><div style="font-size:48px">🔐</div><h3>ورود مدیر</h3><p>برای مدیریت کاربران واقعی، اعلان و تنظیمات آنلاین، کد مدیریت را وارد کن.</p><button class="gamify-btn primary" data-login="1">ورود با کد مدیریت</button></div></div>';
      ov.querySelector("[data-x]").addEventListener("click", close);
      ov.querySelector("[data-login]").addEventListener("click", function () { login(function () { render(); load(); }); });
      return;
    }
    var tabs = '<div class="gm-tabs">' + TABS.map(function (t) { return '<button class="gamify-btn sm ' + (S.tab === t[0] ? "primary" : "") + '" data-tab="' + t[0] + '">' + t[1] + "</button>"; }).join("") + "</div>";
    var body = "";
    var d = S.data || {};
    if (S.tab === "overview") body = renderOverview(d);
    else if (S.tab === "users") body = renderUsers(d);
    else if (S.tab === "match") body = renderMatch(d);
    else if (S.tab === "broadcast") body = renderBroadcast(d);
    else if (S.tab === "settings") body = renderSettings(d);
    else if (S.tab === "categories") body = renderCategories();
    ov.innerHTML = '<div class="gamify-modal gm-admin">' + head + tabs + '<div class="gamify-body">' + body + "</div></div>";
    bind(ov);
  }

  function renderOverview(d) {
    if (!d.stats) return '<div class="gamify-loading">در حال دریافت…</div>';
    var s = d.stats;
    var cards = [["👤 کاربران واقعی", s.realUsers], ["🟢 آنلاین (۲ دقیقه)", s.onlineUsers], ["📡 اتصال زنده", s.liveConnections], ["⚔️ دوئل زندهٔ فعال", s.liveDuels], ["🛡️ قبیله‌ها", s.totalTribes], ["📝 پست منتظر تأیید", s.pendingPosts], ["📸 استوری منتظر", s.pendingStories], ["🏆 تورنمنت‌ها", s.totalTournaments], ["👥 کل حساب‌ها", s.totalUsers]];
    var h = '<div class="gm-stats">' + cards.map(function (c) { return '<div class="gm-stat"><b>' + fa(c[1]) + "</b><span>" + c[0] + "</span></div>"; }).join("") + "</div>";
    h += '<div class="gm-card"><b>آخرین کاربران واقعی</b><table><tr><th>نام</th><th>نوع</th><th>سازمان</th><th>آخرین فعالیت</th><th>موبایل</th><th>ایمیل</th></tr>' + (d.recentUsers || []).map(function (u) { return "<tr><td>" + (u.online ? "🟢 " : "⚪ ") + esc(u.name) + "</td><td class=\"kind-" + u.kind + '">' + kindLabel(u.kind) + "</td><td>" + esc(u.orgId || "—") + "</td><td>" + ago(u.lastSeen) + "</td><td dir=\"ltr\">" + (u.hasPhone ? esc(u.phone) : "ثبت نشده") + "</td><td dir=\"ltr\">" + (u.hasEmail ? esc(u.email) : "ثبت نشده") + "</td></tr>"; }).join("") + "</table></div>";
    h += '<div class="gm-card"><b>لاگ ممیزی</b><div style="font-size:12px;color:#cdbde0;line-height:1.9">' + (d.logs || []).map(function (l) { return "• " + esc(l.actor) + " → " + esc(l.action) + " " + esc(l.target || "") + " <small>(" + ago(l.createdAt) + ")</small>"; }).join("<br>") + "</div></div>";
    return h;
  }
  function kindLabel(k) { return { real: "واقعی", guest: "مهمان", bot: "ربات", admin: "مدیر" }[k] || k; }

  function renderUsers(d) {
    var c = d.counts || {};
    var kinds = [["real", "👤 واقعی (" + fa(c.real) + ")"], ["online", "🟢 آنلاین (" + fa(c.online) + ")"], ["guest", "🌱 مهمان (" + fa(c.guest) + ")"], ["admin", "👑 مدیران (" + fa(c.admin) + ")"], ["bot", "🤖 ربات‌ها (" + fa(c.bot) + ")"], ["all", "همه"]];
    var h = '<div class="gm-row"><select data-kind>' + kinds.map(function (k) { return '<option value="' + k[0] + '"' + (S.kind === k[0] ? " selected" : "") + ">" + k[1] + "</option>"; }).join("") + '</select><input data-q placeholder="جست‌وجو: نام، موبایل، ایمیل، سازمان" value="' + esc(S.q) + '"><button class="gamify-btn sm" data-search>جست‌وجو</button><span style="font-size:12px;color:#cdbde0">' + fa(d.total || 0) + " نتیجه · اتصال زنده: " + fa(c.live || 0) + "</span></div>";
    if (!d.users) return h + '<div class="gamify-loading">در حال دریافت…</div>';
    h += '<table><tr><th></th><th>نام</th><th>نوع</th><th>موبایل</th><th>ایمیل</th><th>سازمان</th><th>قبیله</th><th>XP</th><th>آخرین فعالیت</th><th>عملیات</th></tr>';
    d.users.forEach(function (u) {
      var rv = S.revealed[u.id];
      h += "<tr" + (u.banned ? ' style="opacity:.5"' : "") + '><td><img src="' + avSrc(u.avatar) + '" style="width:30px;height:30px;border-radius:50%"></td><td>' + (u.online ? "🟢 " : "⚪ ") + esc(u.name) + (u.role === "admin" ? " 👑" : "") + '</td><td class="kind-' + u.kind + '">' + kindLabel(u.kind) + '</td>' +
        '<td dir="ltr">' + (u.hasPhone ? esc(rv ? rv.phone : u.phone) : '<span style="color:#888">ثبت نشده</span>') + '</td><td dir="ltr">' + (u.hasEmail ? esc(rv ? rv.email : u.email) : '<span style="color:#888">ثبت نشده</span>') + "</td>" +
        "<td>" + esc(u.orgId || "—") + "</td><td>" + esc(u.tribe ? u.tribe.name : "—") + "</td><td>" + fa(u.xp) + "</td><td>" + ago(u.lastSeen) + "</td>" +
        '<td><button class="gamify-btn sm" data-user="' + esc(u.id) + '">⚙️</button></td></tr>';
    });
    h += "</table>";
    var pages = Math.max(1, Math.ceil((d.total || 0) / (d.size || 30)));
    h += '<div class="gm-row"><button class="gamify-btn sm" data-page="' + (S.page - 1) + '"' + (S.page <= 1 ? " disabled" : "") + '>قبلی</button><span>صفحهٔ ' + fa(S.page) + " از " + fa(pages) + '</span><button class="gamify-btn sm" data-page="' + (S.page + 1) + '"' + (S.page >= pages ? " disabled" : "") + ">بعدی</button></div>";
    if (S.sel.id) h += renderUserCard(S.sel);
    return h;
  }
  function renderUserCard(u) {
    var rv = S.revealed[u.id];
    var avs = ""; for (var i = 1; i <= 20; i++) avs += '<img src="/assets/avatars/' + String(i).padStart(2, "0") + '.png" data-av="' + i + '" class="' + (u.avatar && u.avatar.img === i ? "sel" : "") + '" title="آواتار ' + i + '">';
    return '<div class="gm-card" id="gm-user-card"><div class="gm-row" style="justify-content:space-between"><b>⚙️ ' + esc(u.name) + ' <small class="kind-' + u.kind + '">(' + kindLabel(u.kind) + ")</small></b><button class=\"gamify-btn sm\" data-unsel>بستن</button></div>" +
      '<div class="gm-row"><span>موبایل: <b dir="ltr">' + (u.hasPhone ? esc(rv ? rv.phone : u.phone) : "ثبت نشده") + '</b></span><span>ایمیل: <b dir="ltr">' + (u.hasEmail ? esc(rv ? rv.email : u.email) : "ثبت نشده") + "</b></span>" + ((u.hasPhone || u.hasEmail) && !rv ? '<button class="gamify-btn sm" data-reveal>👁️ نمایش کامل (ثبت در لاگ)</button>' : "") + "<span>ورود: " + esc(u.provider || "guest") + "</span><span>عضویت: " + ago(u.createdAt) + "</span></div>" +
      '<div class="gm-row"><input data-name value="' + esc(u.name) + '" placeholder="نام"><button class="gamify-btn sm" data-act="set-name">ذخیرهٔ نام</button>' +
      '<select data-org><option value="">بدون سازمان</option>' + S.orgs.map(function (o) { return '<option value="' + esc(o.id) + '"' + (o.id === u.orgId ? " selected" : "") + ">" + esc(o.name) + "</option>"; }).join("") + '</select><button class="gamify-btn sm" data-act="set-org">ذخیرهٔ سازمان</button></div>' +
      '<div class="gm-row"><select data-tribe><option value="">— انتخاب قبیله —</option>' + S.tribes.map(function (t) { return '<option value="' + esc(t.id) + '"' + (u.tribe && u.tribe.id === t.id ? " selected" : "") + ">" + esc(t.logo || "") + " " + esc(t.name) + "</option>"; }).join("") + '</select><button class="gamify-btn sm primary" data-act="add-to-tribe">🛡️ عضو قبیله کن</button><button class="gamify-btn sm" data-act="remove-from-tribe">خروج از قبیله</button>' +
      '<input data-coins type="number" value="100" style="width:90px"><button class="gamify-btn sm" data-act="set-coins">🪙 افزودن سکه</button></div>' +
      '<div class="gm-row"><input data-ntitle placeholder="عنوان پیام" style="width:160px"><input data-nbody placeholder="متن پیام خصوصی به این کاربر" style="flex:1"><button class="gamify-btn sm" data-act="notify-user">📩 ارسال</button></div>' +
      '<div class="gm-row">' + (u.banned ? '<button class="gamify-btn sm" data-act="unban">✅ رفع مسدودی</button>' : '<button class="gamify-btn sm danger" data-act="ban">⛔ مسدود</button>') + (u.role === "admin" ? '<button class="gamify-btn sm" data-act="remove-admin">حذف نقش مدیر</button>' : '<button class="gamify-btn sm" data-act="make-admin">👑 مدیر کن</button>') + '<button class="gamify-btn sm danger" data-act="delete-user">🗑️ حذف حساب</button><button class="gamify-btn sm" data-match-with="' + esc(u.id) + '">⚔️ مسابقه با…</button></div>' +
      '<div><b style="font-size:12px">آواتار:</b><div class="gm-avatars">' + avs + "</div></div></div>";
  }

  function renderMatch(d) {
    var users = (d.users || []);
    var opts = function (sel) { return '<option value="">— انتخاب بازیکن واقعی —</option>' + users.map(function (u) { return '<option value="' + esc(u.id) + '"' + (sel === u.id ? " selected" : "") + ">" + (u.online ? "🟢 " : "⚪ ") + esc(u.name) + (u.orgId ? " · " + esc(u.orgId) : "") + "</option>"; }).join(""); };
    return '<div class="gm-card"><h3 style="margin:0 0 6px">🏟️ ترتیب‌دادن مسابقهٔ زندهٔ دونفره</h3><p style="font-size:13px;color:#cdbde0;line-height:1.8">دو کاربر واقعی را انتخاب کن؛ برای هر دو همان لحظه پنجرهٔ دعوت باز می‌شود (مثل این‌که خودشان دعوت داده‌اند) و بعد از پذیرش، هم‌زمان با هم مسابقه می‌دهند.</p>' +
      '<div class="gm-row"><input data-mq placeholder="جست‌وجوی نام" value="' + esc(S.q) + '"><button class="gamify-btn sm" data-msearch>جست‌وجو</button></div>' +
      '<div class="gm-row"><label>بازیکن ۱ <select data-ma>' + opts(S.matchA) + "</select></label><label>بازیکن ۲ <select data-mb>" + opts(S.matchB) + '</select></label><label>دسته <select data-mcat>' + S.categories.map(function (c) { return '<option value="' + esc(c.id) + '">' + esc(c.name) + "</option>"; }).join("") + '</select></label><button class="gamify-btn primary" data-go-match>⚔️ ارسال درخواست مسابقه</button></div></div>';
  }

  function renderBroadcast(d) {
    var list = Array.isArray(d) ? d : [];
    var links = [["", "بدون لینک"], ["feed", "فید"], ["tournaments", "تورنمنت‌ها"], ["tribes", "قبیله‌ها"], ["pvp", "نبرد زنده"], ["arena", "مرکز پاداش"], ["leaderboard", "جدول رتبه‌بندی"], ["messages", "گفت‌وگو"], ["profile", "پروفایل"], ["shop", "فروشگاه"], ["settings", "تنظیمات"]];
    return '<div class="gm-card"><h3 style="margin:0 0 6px">📣 اعلان سراسری (پنجره روی صفحهٔ همه)</h3>' +
      '<div class="gm-row"><input data-bt placeholder="عنوان" style="flex:1"><select data-btarget><option value="all">همهٔ کاربران</option><option value="real">فقط کاربران واقعی</option>' + S.orgs.map(function (o) { return '<option value="org:' + esc(o.id) + '">سازمان ' + esc(o.name) + "</option>"; }).join("") + "</select></div>" +
      '<textarea data-bb placeholder="متن کوتاه"></textarea>' +
      '<div class="gm-row"><input data-bi placeholder="لینک عکس (اختیاری)" style="flex:1" dir="ltr"><input type="file" accept="image/*" data-bfile></div>' +
      '<div class="gm-row"><select data-bl>' + links.map(function (l) { return '<option value="' + l[0] + '">' + l[1] + "</option>"; }).join("") + '</select><input data-bcustom placeholder="یا آدرس دلخواه https://…" dir="ltr" style="flex:1"><input data-bh type="number" value="24" style="width:80px" title="ساعت"> ساعت<button class="gamify-btn primary" data-send-bc>🚀 ارسال زنده</button></div></div>' +
      '<div class="gm-card"><b>اعلان‌های اخیر</b><table><tr><th>عنوان</th><th>هدف</th><th>لینک</th><th>زمان</th><th></th></tr>' + list.map(function (b) { return "<tr" + (!b.active ? ' style="opacity:.5"' : "") + "><td class=\"wrap\">" + esc(b.title) + "</td><td>" + esc(b.target) + "</td><td>" + esc(b.link || "—") + "</td><td>" + ago(b.createdAt) + "</td><td>" + (b.active ? '<button class="gamify-btn sm" data-del-bc="' + esc(b.id) + '">حذف</button>' : "") + "</td></tr>"; }).join("") + "</table></div>";
  }

  function renderSettings(d) {
    if (!d || !d.site) return '<div class="gamify-loading">در حال دریافت…</div>';
    var st = liveStore(); var local = (st && st.settings) || {};
    var site = Object.assign({}, local, d.site);
    var txt = d.textOverrides || {}; var ass = d.assetOverrides || {};
    var sections = [["feed", "فید"], ["stories", "استوری"], ["tournaments", "تورنمنت"], ["leagues", "لیگ‌ها"], ["messages", "گفت‌وگو"], ["shop", "فروشگاه"], ["leaderboard", "رتبه‌بندی"], ["daily", "چالش روزانه"], ["events", "رویدادها"], ["support", "ارتباط با مدیر"]];
    var hidden = Array.isArray(site.hiddenSections) ? site.hiddenSections : [];
    var h = '<div class="gm-card"><h3 style="margin:0 0 6px">⚙️ تنظیمات اصلی (برای همه، فوری)</h3>' +
      '<div class="gm-row"><label>عنوان سایت <input data-s="siteTitle" value="' + esc(site.siteTitle || "") + '"></label><label>شعار <input data-s="tagline" value="' + esc(site.tagline || "") + '"></label></div>' +
      '<div class="gm-row"><label style="flex:1">متن خوش‌آمد <input data-s="welcome" value="' + esc(site.welcome || "") + '" style="width:100%"></label></div>' +
      '<div class="gm-row"><label>لوگو (لینک یا آپلود) <input data-s="logo" value="' + esc(site.logo || "") + '" dir="ltr"></label><input type="file" accept="image/*" data-logo-file>' + (site.logo ? '<img src="' + esc(site.logo) + '" style="height:36px;border-radius:8px">' : "") + "</div>" +
      '<div class="gm-row"><label>زمان هر سؤال (ثانیه) <input data-s="roundSeconds" type="number" value="' + esc(site.roundSeconds || 25) + '" style="width:80px"></label><label>تعداد سؤال چالش روزانه <input data-s="dailyCount" type="number" value="' + esc(site.dailyCount || 5) + '" style="width:80px"></label></div>' +
      '<div class="gm-row">' + [["moderatePosts", "پست با تأیید مدیر منتشر شود"], ["moderateStories", "استوری با تأیید مدیر منتشر شود"], ["chatEnabled", "گفت‌وگو فعال"], ["shopEnabled", "فروشگاه فعال"], ["assistantEnabled", "دستیار هوشمند فعال"], ["staffActivity", "فعالیت ربات‌ها/کادر"], ["botEnabled", "حریف رایانه‌ای فعال"]].map(function (k) { return '<label class="gm-toggle"><input type="checkbox" data-b="' + k[0] + '"' + (site[k[0]] !== false && site[k[0]] !== undefined ? (site[k[0]] ? " checked" : "") : (k[0].indexOf("moderate") === 0 ? "" : " checked")) + "> " + k[1] + "</label>"; }).join("") + "</div>" +
      '<div><b style="font-size:13px">بخش‌های پنهان:</b><div class="gm-row">' + sections.map(function (s) { return '<label class="gm-toggle"><input type="checkbox" data-hide="' + s[0] + '"' + (hidden.indexOf(s[0]) >= 0 ? " checked" : "") + "> " + s[1] + "</label>"; }).join("") + "</div></div>" +
      '<div><b style="font-size:13px">بنر بالای صفحه:</b><div class="gm-row"><input data-banner-text placeholder="متن بنر" value="' + esc(site.banners && site.banners[0] ? site.banners[0].text : "") + '" style="flex:1"><input data-banner-link placeholder="بخش (مثلاً tournaments)" value="' + esc(site.banners && site.banners[0] ? site.banners[0].link : "") + '"><input data-banner-color type="color" value="' + esc(site.banners && site.banners[0] && /^#/.test(site.banners[0].color) ? site.banners[0].color : "#f2ca7c") + '"></div></div>' +
      '<div class="gm-row"><button class="gamify-btn primary" data-save-site>💾 ذخیره و انتشار آنلاین</button><button class="gamify-btn sm" data-push-local>⬆️ انتشار تنظیمات پنل داخلی بازی (مدال‌ها، بانک وضعیت، خطوط کمکی…)</button></div></div>';
    h += '<div class="gm-card"><details open><summary>✏️ تغییر هر متن/جملهٔ بازی (' + fa(Object.keys(txt).length) + ')</summary><p style="font-size:12px;color:#cdbde0">متن دقیق فعلی را در ستون چپ و متن جدید را در ستون راست بنویس؛ بلافاصله برای همه عوض می‌شود. (برای حذف، متن جدید را خالی بگذار)</p><div id="gm-txt">' +
      Object.keys(txt).map(function (k) { return '<div class="gm-row gm-txt-row"><input class="t-from" value="' + esc(k) + '" style="flex:1"><span>→</span><input class="t-to" value="' + esc(txt[k]) + '" style="flex:1"></div>'; }).join("") +
      '<div class="gm-row gm-txt-row"><input class="t-from" placeholder="متن فعلی (مثلاً: جام هفتگی گیمیفای)" style="flex:1"><span>→</span><input class="t-to" placeholder="متن جدید" style="flex:1"></div></div><div class="gm-row"><button class="gamify-btn sm" data-add-txt>+ ردیف</button><button class="gamify-btn primary sm" data-save-txt>💾 ذخیرهٔ متن‌ها</button></div></details></div>';
    h += '<div class="gm-card"><details><summary>🖼️ جایگزینی تصاویر (آواتارها، نماد دسته‌ها، جام…) (' + fa(Object.keys(ass).length) + ')</summary><p style="font-size:12px;color:#cdbde0">آدرس تصویر فعلی (مثلاً /assets/avatars/01.png یا /assets/trophy.svg) و تصویر جدید (لینک یا آپلود). هر img با این src به‌صورت زنده عوض می‌شود.</p><div id="gm-ass">' +
      Object.keys(ass).map(function (k) { return '<div class="gm-row gm-ass-row"><input class="a-from" value="' + esc(k) + '" dir="ltr" style="flex:1"><span>→</span><input class="a-to" value="' + esc(ass[k]) + '" dir="ltr" style="flex:1"><input type="file" accept="image/*" class="a-file"></div>'; }).join("") +
      '<div class="gm-row gm-ass-row"><input class="a-from" placeholder="/assets/..." dir="ltr" style="flex:1"><span>→</span><input class="a-to" placeholder="https://… یا آپلود" dir="ltr" style="flex:1"><input type="file" accept="image/*" class="a-file"></div></div><div class="gm-row"><button class="gamify-btn sm" data-add-ass>+ ردیف</button><button class="gamify-btn primary sm" data-save-ass>💾 ذخیرهٔ تصاویر</button></div></details></div>';
    return h;
  }

  function renderCategories() {
    return '<div class="gm-card"><h3 style="margin:0 0 6px">🗂️ دسته‌های سؤال (نام، نماد، رنگ، فعال)</h3><p style="font-size:12px;color:#cdbde0">نماد می‌تواند ایموجی یا لینک تصویر باشد. در نبرد زنده، قبیله و تورنمنت استفاده می‌شود.</p><table><tr><th>شناسه</th><th>نام</th><th>زیرعنوان</th><th>نماد</th><th>رنگ</th><th>فعال</th><th></th></tr>' +
      S.categories.map(function (c) { return '<tr data-cat="' + esc(c.id) + '"><td dir="ltr">' + esc(c.id) + '</td><td><input class="c-name" value="' + esc(c.name) + '" style="width:130px"></td><td><input class="c-sub" value="' + esc(c.subtitle || "") + '" style="width:150px"></td><td><input class="c-icon" value="' + esc(c.icon || "") + '" style="width:110px"></td><td><input class="c-color" type="color" value="' + esc(/^#/.test(c.color || "") ? c.color : "#a98cf7") + '"></td><td><input class="c-active" type="checkbox"' + (c.active !== 0 ? " checked" : "") + '></td><td><button class="gamify-btn sm" data-save-cat="' + esc(c.id) + '">ذخیره</button></td></tr>'; }).join("") +
      '</table><div class="gm-row"><input data-newcat placeholder="شناسهٔ دستهٔ جدید (انگلیسی)" dir="ltr"><input data-newcat-name placeholder="نام دسته"><button class="gamify-btn sm" data-add-cat>+ افزودن دسته</button></div></div>';
  }

  function fileToData(file, cb) { var r = new FileReader(); r.onload = function () { cb(String(r.result || "")); }; r.readAsDataURL(file); }
  function userAct(action, extra) {
    var body = Object.assign({ userId: S.sel.id }, extra || {});
    api("/api/admin?action=" + action, "POST", body).then(function (r) {
      if (!r.body || r.body.error) return toast("⚠️ " + (r.body && r.body.error || "خطا"));
      toast("✅ انجام شد");
      if (action === "delete-user") S.sel = {};
      load();
    });
  }

  function bind(ov) {
    ov.querySelector("[data-x]").addEventListener("click", close);
    ov.querySelectorAll("[data-tab]").forEach(function (b) { b.addEventListener("click", function () { S.tab = b.getAttribute("data-tab"); S.page = 1; S.data = null; render(); load(); }); });
    var kind = ov.querySelector("[data-kind]"); if (kind) kind.addEventListener("change", function () { S.kind = kind.value; S.page = 1; load(); });
    var q = ov.querySelector("[data-q]"); var doSearch = function () { S.q = q ? q.value.trim() : ""; S.page = 1; load(); };
    if (q) q.addEventListener("keydown", function (e) { if (e.key === "Enter") doSearch(); });
    var sb = ov.querySelector("[data-search]"); if (sb) sb.addEventListener("click", doSearch);
    ov.querySelectorAll("[data-page]").forEach(function (b) { b.addEventListener("click", function () { S.page = Number(b.getAttribute("data-page")); load(); }); });
    ov.querySelectorAll("[data-user]").forEach(function (b) { b.addEventListener("click", function () { var id = b.getAttribute("data-user"); S.sel = (S.data.users || []).filter(function (u) { return u.id === id; })[0] || {}; render(); var c = document.getElementById("gm-user-card"); if (c) c.scrollIntoView({ behavior: "smooth" }); }); });
    var un = ov.querySelector("[data-unsel]"); if (un) un.addEventListener("click", function () { S.sel = {}; render(); });
    var rv = ov.querySelector("[data-reveal]"); if (rv) rv.addEventListener("click", function () { api("/api/admin?action=reveal-contact", "POST", { userId: S.sel.id }).then(function (r) { if (r.body && r.body.ok) { S.revealed[S.sel.id] = r.body; render(); } }); });
    ov.querySelectorAll("[data-act]").forEach(function (b) {
      b.addEventListener("click", function () {
        var a = b.getAttribute("data-act");
        if (a === "set-name") return userAct(a, { name: ov.querySelector("[data-name]").value });
        if (a === "set-org") return userAct(a, { orgId: ov.querySelector("[data-org]").value });
        if (a === "add-to-tribe") { var t = ov.querySelector("[data-tribe]").value; if (!t) return toast("قبیله را انتخاب کن"); return userAct(a, { tribeId: t }); }
        if (a === "set-coins") return userAct(a, { delta: Number(ov.querySelector("[data-coins]").value) || 0 });
        if (a === "notify-user") return userAct(a, { title: ov.querySelector("[data-ntitle]").value, body: ov.querySelector("[data-nbody]").value });
        if (a === "delete-user" && !confirm("حساب حذف شود؟ این کار برگشت‌پذیر نیست.")) return;
        userAct(a);
      });
    });
    ov.querySelectorAll("[data-av]").forEach(function (img) { img.addEventListener("click", function () { userAct("set-avatar", { img: Number(img.getAttribute("data-av")) }); }); });
    var mw = ov.querySelector("[data-match-with]"); if (mw) mw.addEventListener("click", function () { S.matchA = mw.getAttribute("data-match-with"); S.tab = "match"; S.q = ""; render(); load(); });
    // match
    var mq = ov.querySelector("[data-mq]"); var ms = ov.querySelector("[data-msearch]"); if (ms) ms.addEventListener("click", function () { S.q = mq.value.trim(); load(); });
    var ma = ov.querySelector("[data-ma]"), mb = ov.querySelector("[data-mb]");
    if (ma) ma.addEventListener("change", function () { S.matchA = ma.value; }); if (mb) mb.addEventListener("change", function () { S.matchB = mb.value; });
    var gm = ov.querySelector("[data-go-match]"); if (gm) gm.addEventListener("click", function () {
      if (!S.matchA || !S.matchB) return toast("هر دو بازیکن را انتخاب کن");
      api("/api/pvp?action=admin-match", "POST", { a: S.matchA, b: S.matchB, category: ov.querySelector("[data-mcat]").value }).then(function (r) {
        if (!r.body || r.body.error) return toast("⚠️ " + (r.body && r.body.error || "خطا"));
        toast("⚔️ درخواست مسابقه برای هر دو ارسال شد");
      });
    });
    // broadcast
    var bf = ov.querySelector("[data-bfile]"); if (bf) bf.addEventListener("change", function () { if (bf.files[0]) fileToData(bf.files[0], function (d) { if (d.length > 400000) return toast("عکس بزرگ است؛ لینک بگذار یا کوچکش کن"); ov.querySelector("[data-bi]").value = d; }); });
    var sbc = ov.querySelector("[data-send-bc]"); if (sbc) sbc.addEventListener("click", function () {
      var link = ov.querySelector("[data-bcustom]").value.trim() || ov.querySelector("[data-bl]").value;
      api("/api/admin?action=broadcast", "POST", { title: ov.querySelector("[data-bt]").value, body: ov.querySelector("[data-bb]").value, image: ov.querySelector("[data-bi]").value, link: link, target: ov.querySelector("[data-btarget]").value, hours: Number(ov.querySelector("[data-bh]").value) || 24 }).then(function (r) {
        if (!r.body || r.body.error) return toast("⚠️ " + (r.body && r.body.error || "خطا")); toast("📣 اعلان برای همه ارسال شد"); load();
      });
    });
    ov.querySelectorAll("[data-del-bc]").forEach(function (b) { b.addEventListener("click", function () { api("/api/admin?action=delete-broadcast", "POST", { id: b.getAttribute("data-del-bc") }).then(load); }); });
    // settings
    var lf = ov.querySelector("[data-logo-file]"); if (lf) lf.addEventListener("change", function () { if (lf.files[0]) fileToData(lf.files[0], function (d) { if (d.length > 150000) return toast("لوگو بزرگ است (حداکثر ~۱۰۰KB)"); ov.querySelector('[data-s="logo"]').value = d; }); });
    var ss = ov.querySelector("[data-save-site]"); if (ss) ss.addEventListener("click", function () {
      var settings = {};
      ov.querySelectorAll("[data-s]").forEach(function (i) { var k = i.getAttribute("data-s"); settings[k] = i.type === "number" ? Number(i.value) : i.value; });
      ov.querySelectorAll("[data-b]").forEach(function (i) { settings[i.getAttribute("data-b")] = i.checked; });
      settings.hiddenSections = Array.from(ov.querySelectorAll("[data-hide]")).filter(function (i) { return i.checked; }).map(function (i) { return i.getAttribute("data-hide"); });
      var bt = ov.querySelector("[data-banner-text]").value.trim();
      settings.banners = bt ? [{ id: "b1", text: bt, link: ov.querySelector("[data-banner-link]").value.trim(), color: ov.querySelector("[data-banner-color]").value }] : [];
      api("/api/admin?action=publish-settings", "POST", { settings: settings }).then(function (r) { if (!r.body || r.body.error) return toast("⚠️ " + (r.body && r.body.error || "خطا")); toast("✅ تنظیمات برای همه منتشر شد"); if (window.__gamifyRT) window.__gamifyRT.reloadConfig(); load(); });
    });
    var pl = ov.querySelector("[data-push-local]"); if (pl) pl.addEventListener("click", function () {
      var st = liveStore(); if (!st || !st.settings) return toast("تنظیمات محلی پیدا نشد");
      var copy = Object.assign({}, st.settings); delete copy.logo; // لوگو جداگانه
      api("/api/admin?action=publish-settings", "POST", { settings: copy }).then(function (r) { if (!r.body || r.body.error) return toast("⚠️ " + (r.body && r.body.error || "خطا")); toast("✅ تنظیمات پنل داخلی برای همه منتشر شد"); });
    });
    var at = ov.querySelector("[data-add-txt]"); if (at) at.addEventListener("click", function () { ov.querySelector("#gm-txt").insertAdjacentHTML("beforeend", '<div class="gm-row gm-txt-row"><input class="t-from" placeholder="متن فعلی" style="flex:1"><span>→</span><input class="t-to" placeholder="متن جدید" style="flex:1"></div>'); });
    var stx = ov.querySelector("[data-save-txt]"); if (stx) stx.addEventListener("click", function () {
      var map = {}; ov.querySelectorAll(".gm-txt-row").forEach(function (r) { var f = r.querySelector(".t-from").value.trim(), t = r.querySelector(".t-to").value; if (f && t !== "") map[f] = t; });
      api("/api/admin?action=publish-settings", "POST", { textOverrides: map }).then(function (r) { if (!r.body || r.body.error) return toast("⚠️ خطا"); toast("✅ متن‌ها برای همه عوض شد"); if (window.__gamifyRT) window.__gamifyRT.reloadConfig(); load(); });
    });
    var aa = ov.querySelector("[data-add-ass]"); if (aa) aa.addEventListener("click", function () { ov.querySelector("#gm-ass").insertAdjacentHTML("beforeend", '<div class="gm-row gm-ass-row"><input class="a-from" placeholder="/assets/..." dir="ltr" style="flex:1"><span>→</span><input class="a-to" placeholder="https://…" dir="ltr" style="flex:1"><input type="file" accept="image/*" class="a-file"></div>'); bindAssFiles(ov); });
    bindAssFiles(ov);
    var sas = ov.querySelector("[data-save-ass]"); if (sas) sas.addEventListener("click", function () {
      var map = {}; ov.querySelectorAll(".gm-ass-row").forEach(function (r) { var f = r.querySelector(".a-from").value.trim(), t = r.querySelector(".a-to").value.trim(); if (f && t) map[f] = t; });
      api("/api/admin?action=publish-settings", "POST", { assetOverrides: map }).then(function (r) { if (!r.body || r.body.error) return toast("⚠️ " + (r.body && r.body.error || "خطا")); toast("✅ تصاویر برای همه عوض شد"); if (window.__gamifyRT) window.__gamifyRT.reloadConfig(); load(); });
    });
    // categories
    ov.querySelectorAll("[data-save-cat]").forEach(function (b) { b.addEventListener("click", function () { var tr = b.closest("tr"); api("/api/admin?action=set-category", "POST", { id: b.getAttribute("data-save-cat"), name: tr.querySelector(".c-name").value, subtitle: tr.querySelector(".c-sub").value, icon: tr.querySelector(".c-icon").value, color: tr.querySelector(".c-color").value, active: tr.querySelector(".c-active").checked }).then(function (r) { toast(r.body && r.body.ok ? "✅ ذخیره شد" : "⚠️ خطا"); S.categories = []; load(); }); }); });
    var ac = ov.querySelector("[data-add-cat]"); if (ac) ac.addEventListener("click", function () { var id = ov.querySelector("[data-newcat]").value.trim().toLowerCase().replace(/[^a-z0-9_-]/g, ""); if (!id) return toast("شناسهٔ انگلیسی لازم است"); api("/api/admin?action=set-category", "POST", { id: id, name: ov.querySelector("[data-newcat-name]").value || id, active: true }).then(function () { S.categories = []; load(); }); });
  }
  function bindAssFiles(ov) { ov.querySelectorAll(".a-file").forEach(function (f) { if (f.__b) return; f.__b = 1; f.addEventListener("change", function () { if (f.files[0]) fileToData(f.files[0], function (d) { if (d.length > 300000) return toast("تصویر بزرگ است؛ کوچکش کن"); f.parentNode.querySelector(".a-to").value = d; }); }); }); }

  // ---------- دکمهٔ شناور مدیر ----------
  function mountFab() {
    if (document.getElementById("gm-admin-fab")) return;
    var b = document.createElement("button"); b.id = "gm-admin-fab"; b.textContent = "🛠️"; b.title = "پنل مدیریت سرور";
    b.addEventListener("click", open); document.body.appendChild(b);
  }
  function unmountFab() { var b = document.getElementById("gm-admin-fab"); if (b) b.remove(); }
  function check() {
    if (localAdmin() || S.token) mountFab(); else unmountFab();
  }
  window.__gamifyAdmin = { open: open, login: login, token: function () { return S.token; } };

  function boot() {
    check(); setInterval(check, 4000);
    // اگر مدیر در پنل داخلی بازی وارد شد ولی هنوز توکن سرور ندارد → یک‌بار پیشنهاد ورود سرور
    var asked = false;
    setInterval(function () { if (!asked && localAdmin() && !S.token) { asked = true; setTimeout(function () { toast("🛠️ برای مدیریت سرور، روی دکمهٔ 🛠️ بزن و کد مدیریت را وارد کن"); }, 1500); } }, 3000);
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot); else setTimeout(boot, 300);
})();
