/* ⚔️ نبرد واقعی بازیکن‌به‌بازیکن (PvP) — دعوت/پذیرش/پاسخ/نتیجه همه از سرور
   - وقتی به یک بازیکن واقعی دعوت می‌فرستی، باندل اصلی `window.__gamifyPvpInvite` را صدا می‌زند (به‌جای شبیه‌سازی)
   - حریف واقعی از پنل ⚔️ دعوت را می‌بیند و می‌پذیرد؛ هر دو نفر همان سؤال‌ها را جداگانه جواب می‌دهند
   - امتیازدهی و نتیجه فقط سمت سرور محاسبه می‌شود */
(function () {
  "use strict";
  if (window.__gamifyPvp) return;
  window.__gamifyPvp = true;

  var LS_KEY = "gamify2-store-v2";
  var CATS = {
    safety: "ایمنی و نجات", electric: "دنیای برق", general: "اطلاعات عمومی", science: "علم و شگفتی",
    technology: "فناوری و آینده", work: "تجربه‌های کاری", nature: "زمین و زندگی", sport: "ورزش و سرگرمی",
    geography: "جغرافیا و سفر", history: "تاریخ و تمدن", literature: "ادبیات فارسی", math: "ریاضی و منطق",
    space: "نجوم و فضا", art: "هنر و طراحی", music: "موسیقی", cinema: "سینما و روایت", food: "آشپزی و خوراک",
    animals: "دنیای جانوران", english: "زبان انگلیسی", engineering: "مهندسی و ابزار"
  };
  function catName(id) { return CATS[id] || id || "اطلاعات عمومی"; }

  var S = {
    overlay: null, quizOv: null,
    inbox: null, me: null, badge: 0,
    waiting: null,        // نبردی که منتظر پذیرش حریفم
    watching: null,       // نبردی که منتظر جواب حریف پس از پاسخ منم
    quiz: null,           // { battle, qs, idx, answers, startedAt, locked, timerInt }
    result: null,
    openInviteIds: {},    // دعوت‌هایی که مودالشان باز است
    promptedActive: {},   // نبردهای فعالی که برایشان پیشنهاد شروع داده شده
    playersCache: [], playersAt: 0, tab: "invites",
    pollInt: null, stateInt: null
  };

  function readStore() { try { return JSON.parse(localStorage.getItem(LS_KEY) || "null"); } catch (e) { return null; } }
  function esc(s) { return String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }
  function fa(n) { try { return Number(n || 0).toLocaleString("fa-IR"); } catch (e) { return String(n || 0); } }
  function toast(m) {
    try { if (window.__gamifyToast) return window.__gamifyToast(m); } catch (e) {}
    try {
      var d = document.createElement("div");
      d.textContent = m;
      d.style.cssText = "position:fixed;bottom:86px;right:16px;z-index:99999;background:#241a33;color:#fff;padding:10px 16px;border-radius:14px;font-size:13px;box-shadow:0 8px 30px rgba(0,0,0,.4);border:1px solid #a98cf7;font-family:Vazirmatn,sans-serif;";
      document.body.appendChild(d);
      setTimeout(function () { d.style.transition = "opacity .4s"; d.style.opacity = "0"; setTimeout(function(){ d.remove(); }, 450); }, 3000);
    } catch (e) {}
  }
  function jingle() { try { if (window.__gamifyConfetti) window.__gamifyConfetti(); } catch (e) {} }
  function loggedIn() {
    try { if (window.__gamifySession && window.__gamifySession.isLoggedIn()) return true; } catch (e) {}
    var st = readStore(); return !!(st && st.profile && st.profile.id);
  }
  function api(path, method, body, retried) {
    var ready = window.__gamifyServer && window.__gamifyServer.ensureSynced ? window.__gamifyServer.ensureSynced() : Promise.resolve();
    return ready.catch(function () {}).then(function () {
      return fetch(path, { method: method || "GET", credentials: "include", headers: { "Content-Type": "application/json" }, body: body ? JSON.stringify(body) : undefined })
        .then(function (r) {
          return r.text().then(function (txt) {
            var j = null; try { j = JSON.parse(txt); } catch (e) { j = { error: "server", message: "سرور پاسخ نامعتبر داد (" + r.status + ")" }; }
            if (r.status === 401 && !retried && window.__gamifyServer && window.__gamifyServer.syncNow) {
              return window.__gamifyServer.syncNow().then(function () { return api(path, method, body, true); });
            }
            return { status: r.status, body: j };
          });
        });
    }).catch(function () { return { status: 0, body: { error: "network", message: "اتصال به سرور برقرار نشد؛ اینترنت را بررسی کن" } }; });
  }
  function avatarSrc(av) {
    var pad = function (n) { return String(n).padStart(2, "0"); };
    if (av && typeof av === "object" && av.img) return "/assets/avatars/" + pad(av.img) + ".png";
    if (typeof av === "number") return "/assets/avatars/" + pad(((av % 20) + 20) % 20 + 1) + ".png";
    if (av && typeof av === "object" && av.seed) return "/assets/avatars/" + pad(((av.seed % 20) + 20) % 20 + 1) + ".png";
    return "/assets/avatars/07.png";
  }
  function avatarHtml(av, name, size) {
    var ini = esc(String(name || "؟").trim().slice(0, 1) || "؟");
    return '<div class="pvp-av" style="width:' + size + "px;height:" + size + 'px"><img src="' + avatarSrc(av) + '" alt="" loading="lazy" onerror="this.remove()"><span>' + ini + "</span></div>";
  }

  // ================= پنل اصلی (ورودی‌ها / در جریان / نتایج / بازیکنان) =================
  function ensureOverlay() {
    if (S.overlay) return S.overlay;
    var ov = document.createElement("div");
    ov.className = "gamify-overlay pvp-overlay";
    ov.id = "gamify-pvp-overlay";
    ov.addEventListener("click", function (e) { if (e.target === ov) closePanel(); });
    document.body.appendChild(ov);
    S.overlay = ov;
    return ov;
  }
  function openPanel() {
    var ov = ensureOverlay();
    ov.classList.add("open");
    renderPanel();
    refreshInbox(true);
    loadPlayers();
  }
  function closePanel() { if (S.overlay) S.overlay.classList.remove("open"); }

  function badgeCount() {
    if (!S.inbox) return 0;
    var n = (S.inbox.incoming || []).length;
    (S.inbox.active || []).forEach(function (b) { if (!b.myDone) n++; });
    (S.inbox.results || []).forEach(function (b) { if (!b.seen) n++; });
    return n;
  }
  function updateFabBadge() {
    var b = document.getElementById("gamify-pvp-fab");
    if (!b) return;
    var old = b.querySelector(".gamify-fab-badge");
    if (old) old.remove();
    var n = badgeCount();
    if (n > 0) { var s = document.createElement("span"); s.className = "gamify-fab-badge"; s.textContent = fa(n); b.appendChild(s); }
  }

  function rowUser(u) {
    return '<div class="pvp-user">' + avatarHtml(u.avatar, u.name, 46) +
      '<div class="pvp-user-i"><b>' + esc(u.name) + '</b><span>' + (u.online ? "🟢 آنلاین" : "⚪ آفلاین") + ' · ⭐ ' + fa(u.xp || 0) + ' · 🏆 ' + fa(u.wins || 0) + "</span></div></div>";
  }

  function panelHtml() {
    var d = S.inbox || { incoming: [], outgoing: [], active: [], results: [] };
    var tabs = [["invites", "📨 دعوت‌ها (" + fa(d.incoming.length) + ")"], ["active", "⚔️ در جریان"], ["results", "🏁 نتایج"], ["players", "🧑‍🤝‍🧑 بازیکنان"]];
    var head = '<div class="gamify-modal-head"><b>⚔️ نبرد زنده</b><button data-act="close" class="gamify-btn sm">✕</button></div>';
    var tabsHtml = '<div class="gamify-tabs">' + tabs.map(function (t) {
      return '<button class="gamify-btn sm ' + (S.tab === t[0] ? "primary" : "") + '" data-act="tab" data-tab="' + t[0] + '">' + t[1] + "</button>";
    }).join("") + "</div>";
    var body = "";

    if (S.tab === "invites") {
      if (!d.incoming.length && !d.outgoing.length) body = '<div class="gamify-empty"><div style="font-size:44px;">🕊️</div><p>دعوت تازه‌ای نداری.<br>از تب «بازیکنان» یکی از بازیکنان واقعی را به نبرد بخوان!</p></div>';
      d.incoming.forEach(function (b) {
        body += '<div class="pvp-card">' + rowUser(b.opponent) +
          '<div class="pvp-cat">📚 دسته: ' + esc(catName(b.category)) + "</div>" +
          '<div class="pvp-acts"><button class="gamify-btn primary sm" data-act="accept" data-id="' + b.id + '">✅ قبول نبرد</button>' +
          '<button class="gamify-btn sm" data-act="decline" data-id="' + b.id + '">❌ رد</button></div></div>';
      });
      d.outgoing.forEach(function (b) {
        body += '<div class="pvp-card waiting-card">' + rowUser(b.opponent) +
          '<div class="pvp-cat">⏳ در انتظار پذیرش… 📚 ' + esc(catName(b.category)) + "</div>" +
          '<div class="pvp-acts"><button class="gamify-btn sm" data-act="cancel" data-id="' + b.id + '">لغو دعوت</button></div></div>';
      });
    } else if (S.tab === "active") {
      if (!d.active.length) body = '<div class="gamify-empty"><div style="font-size:44px;">⚔️</div><p>نبرد فعالی نداری.</p></div>';
      d.active.forEach(function (b) {
        var st = b.myDone ? (b.oppDone ? "در حال ثبت نتیجه…" : "⏳ منتظر پاسخ حریف…") : (b.oppDone ? "🔥 حریف تمام کرده — نوبت تو!" : "🎯 آماده برای شروع");
        body += '<div class="pvp-card">' + rowUser(b.opponent) +
          '<div class="pvp-cat">📚 ' + esc(catName(b.category)) + " · " + st + "</div>" +
          '<div class="pvp-acts">' +
          (!b.myDone ? '<button class="gamify-btn primary sm" data-act="play" data-id="' + b.id + '">🎮 شروع/ادامهٔ نبرد</button>' : '<button class="gamify-btn sm" data-act="watch" data-id="' + b.id + '">👀 پیگیری نتیجه</button>') +
          "</div></div>";
      });
    } else if (S.tab === "results") {
      if (!d.results.length) body = '<div class="gamify-empty"><div style="font-size:44px;">🏁</div><p>هنوز نتیجه‌ای ثبت نشده.</p></div>';
      d.results.forEach(function (b) {
        var r = !b.winnerId ? "مساوی ⚖️" : (b.winnerId === S.me ? "بردی 🏆" : "باختی 💪");
        body += '<div class="pvp-card ' + (!b.seen ? "unseen" : "") + '">' + rowUser(b.opponent) +
          '<div class="pvp-cat">' + r + " · " + fa(b.myScore || 0) + " برابر " + fa(b.oppScore || 0) + " · 📚 " + esc(catName(b.category)) + "</div>" +
          '<div class="pvp-acts"><button class="gamify-btn primary sm" data-act="show-result" data-id="' + b.id + '">📊 جزئیات</button>' +
          '<button class="gamify-btn sm" data-act="rematch" data-id="' + b.id + '">🔁 مبارزهٔ مجدد</button></div></div>';
      });
    } else {
      if (!S.playersCache.length) body = '<div class="gamify-loading">در حال دریافت بازیکنان واقعی…</div>';
      var others = S.playersCache.filter(function (p) { return p && p.id !== S.me; });
      if (S.playersCache.length && !others.length) body = '<div class="gamify-empty"><div style="font-size:44px;">🌱</div><p>فعلاً بازیکن واقعی دیگری وارد نشده؛ دوستت را به بازی دعوت کن!</p></div>';
      body += '<div class="pvp-search"><input type="search" id="pvp-search" placeholder="جست‌وجوی بازیکن…" value="' + esc(S.search || "") + '"></div>';
      others = others.filter(function (p) { return !S.search || (p.name || "").indexOf(S.search) >= 0; }).sort(function (a, b2) { return (b2.online ? 1 : 0) - (a.online ? 1 : 0); });
      others.forEach(function (p) {
        body += '<div class="pvp-card">' + rowUser(p) +
          '<div class="pvp-acts"><select class="pvp-sel" data-cat-for="' + esc(p.id) + '">' +
          Object.keys(CATS).map(function (c) { return '<option value="' + c + '"' + (c === "general" ? " selected" : "") + ">" + CATS[c] + "</option>"; }).join("") +
          '</select><button class="gamify-btn primary sm" data-act="invite" data-id="' + esc(p.id) + '">⚔️ دعوت</button></div></div>';
      });
    }
    return '<div class="gamify-modal pvp-modal">' + head + '<div style="height:10px"></div>' + tabsHtml + '<div class="gamify-body pvp-body">' + body + "</div></div>";
  }

  function renderPanel() {
    var ov = ensureOverlay();
    if (!ov.classList.contains("open")) return;
    if (!loggedIn()) {
      try { if (window.__gamifyEnsureGuest) window.__gamifyEnsureGuest(); } catch (e) {}
      if (!loggedIn()) { ov.innerHTML = '<div class="gamify-modal"><div class="gamify-modal-head"><b>⚔️ نبرد زنده</b><button data-act="close" class="gamify-btn sm">✕</button></div><div class="gamify-loading">در حال آماده‌سازی حساب…</div></div>'; bindPanel(ov); setTimeout(renderPanel, 800); return; }
    }
    ov.innerHTML = panelHtml();
    bindPanel(ov);
  }

  function bindPanel(ov) {
    var si = ov.querySelector("#pvp-search");
    if (si) si.addEventListener("input", function () { S.search = si.value.trim(); var t = ov.querySelector(".pvp-body"); if (t) { renderPanel(); var n = ov.querySelector("#pvp-search"); if (n) { n.focus(); n.setSelectionRange(n.value.length, n.value.length); } } });
    ov.querySelectorAll("[data-act]").forEach(function (el) {
      el.addEventListener("click", function () {
        var act = el.getAttribute("data-act");
        var id = el.getAttribute("data-id");
        if (act === "close") return closePanel();
        if (act === "tab") { S.tab = el.getAttribute("data-tab"); return renderPanel(); }
        if (act === "accept") return doAccept(id);
        if (act === "decline") return doSimple(id, "decline", "دعوت رد شد.");
        if (act === "cancel") return doSimple(id, "cancel", "دعوت لغو شد.");
        if (act === "play") return openQuizFromState(id);
        if (act === "watch") return watchResult(id, true);
        if (act === "show-result") return showResultById(id);
        if (act === "rematch") return doRematch(id);
        if (act === "invite") {
          var sel = ov.querySelector('select[data-cat-for="' + id + '"]');
          var cat = sel ? sel.value : "general";
          var p = S.playersCache.filter(function (x) { return String(x.id) === String(id); })[0];
          return sendInvite(p ? p.id : id, p ? p.name : "بازیکن", p ? p.avatar : null, cat);
        }
      });
    });
  }

  // ================= جریان نبرد =================
  function sendInvite(toId, name, avatar, category) {
    toast("⚔️ در حال ارسال دعوت واقعی…");
    api("/api/pvp?action=invite", "POST", { to: toId, category: category }).then(function (r) {
      if (!r.body || r.body.error) { toast("⚠️ " + ((r.body && (r.body.message || r.body.error)) || "خطا در ارسال دعوت")); return null; }
      var b = r.body.battle;
      startWaiting(b);
      return null;
    });
  }

  // نقطهٔ ورود از باندل اصلی (دکمهٔ «دعوت به مسابقه» روی بازیکن واقعی)
  window.__gamifyPvpInvite = function (player, category) {
    if (!player || !player.id) return;
    sendInvite(player.id, player.name, player.avatar, category || "general");
  };

  function doAccept(id) {
    api("/api/pvp?action=accept", "POST", { id: id }).then(function (r) {
      if (!r.body || r.body.error) { toast("⚠️ " + ((r.body && (r.body.message || r.body.error)) || "خطا")); return refreshInbox(true); }
      toast("✅ نبرد پذیرفته شد — آماده باش!");
      openLive(r.body.battle);
    });
  }
  function doSimple(id, action, msg) {
    api("/api/pvp?action=" + action, "POST", { id: id }).then(function () {
      toast(msg);
      var mo = document.getElementById("pvp-invite-modal");
      if (mo) mo.remove();
      delete S.openInviteIds[id];
      refreshInbox(true);
    });
  }
  function doRematch(id) {
    api("/api/pvp?action=rematch", "POST", { id: id }).then(function (r) {
      if (!r.body || r.body.error) { toast("⚠️ " + ((r.body && (r.body.message || r.body.error)) || "خطا")); return null; }
      closeResultModal();
      startWaiting(r.body.battle);
      return null;
    });
  }

  // ================= جریان زندهٔ هم‌زمان =================
  var clockOffset = 0; // serverNow - Date.now()
  function syncClock(st) { if (st && typeof st.serverNow === "number") clockOffset = st.serverNow - Date.now(); }
  function srvNow() { return Date.now() + clockOffset; }

  // ---- انتظار پذیرش (چالش‌گر) ----
  function startWaiting(battle) {
    S.waiting = battle;
    syncClock(battle);
    renderWaiting();
    if (S.stateInt) clearInterval(S.stateInt);
    // پشتیبان: اگر رویداد زنده نرسید، هر ۴ ثانیه وضعیت را بپرس
    S.stateInt = setInterval(function () { if (S.waiting) pollWaiting(battle.id); }, 4000);
  }
  function pollWaiting(id) {
    api("/api/pvp?action=state&id=" + encodeURIComponent(id)).then(function (r) {
      if (!r.body || r.body.error) return;
      handleStateChange(r.body);
    });
  }
  function handleStateChange(st) {
    syncClock(st);
    if (st.status === "accepted") {
      stopWaiting();
      if (!S.quiz || S.quiz.battle.id !== st.id) openLive(st);
    } else if (st.status === "declined") {
      stopWaiting(); toast("❌ " + ((st.opponent && st.opponent.name) || "حریف") + " الان برای نبرد آماده نیست."); refreshInbox(true);
    } else if (st.status === "expired" || st.status === "cancelled") {
      stopWaiting(); toast("⌛ دعوت بی‌پاسخ ماند؛ دوباره تلاش کن."); refreshInbox(true);
    } else if (st.status === "finished" && st.result) {
      closeQuiz(); showResult(st);
    }
  }
  function stopWaiting() { if (S.stateInt) { clearInterval(S.stateInt); S.stateInt = null; } S.waiting = null; closeWaiting(); }
  function renderWaiting() {
    closeWaiting();
    var b = S.waiting; if (!b) return;
    var d = document.createElement("div");
    d.className = "pvp-mini-overlay"; d.id = "pvp-waiting-modal";
    d.innerHTML = '<div class="gamify-modal pvp-mini">' +
      '<div class="pvp-versus">' + avatarHtml(b.opponent.avatar, b.opponent.name, 84) + '<div class="pvp-swords pulse">⚔️</div></div>' +
      "<h3>در انتظار پذیرش " + esc(b.opponent.name) + "…</h3>" +
      '<p class="pvp-sub">📚 ' + esc(catName(b.category)) + " · ۵ سؤال هم‌زمان · ۱۵ ثانیه برای هر سؤال</p>" +
      '<div class="pvp-wait-bar"><i></i></div>' +
      '<div class="pvp-acts center"><button class="gamify-btn sm" data-c="1">لغو دعوت</button></div></div>';
    document.body.appendChild(d);
    d.querySelector("[data-c]").addEventListener("click", function () { api("/api/pvp?action=cancel", "POST", { id: b.id }); stopWaiting(); refreshInbox(true); });
  }
  function closeWaiting() { var d = document.getElementById("pvp-waiting-modal"); if (d) d.remove(); }

  // ---- اتاق نبرد زنده ----
  function ensureQuizOverlay() {
    if (S.quizOv) return S.quizOv;
    var ov = document.createElement("div");
    ov.className = "gamify-overlay pvp-quiz-overlay"; ov.id = "gamify-pvp-quiz";
    document.body.appendChild(ov); S.quizOv = ov; return ov;
  }
  function openQuizFromState(id) {
    api("/api/pvp?action=state&id=" + encodeURIComponent(id)).then(function (r) {
      if (!r.body || r.body.error) { toast("⚠️ " + ((r.body && (r.body.message || r.body.error)) || "خطا")); return null; }
      syncClock(r.body);
      if (r.body.status === "finished") return showResult(r.body), null;
      if (r.body.status === "accepted") return openLive(r.body), null;
      toast("این نبرد هنوز شروع نشده."); return null;
    });
  }
  function openQuiz(b) { openLive(b); }
  function openLive(battle) {
    syncClock(battle);
    closeWaiting(); closeWatching(); closePanel();
    var inv = document.getElementById("pvp-invite-modal"); if (inv) inv.remove();
    var ov = ensureQuizOverlay(); ov.classList.add("open");
    var qs = (battle.questions || []).slice();
    S.quiz = { battle: battle, qs: qs, idx: -1, picked: {}, oppAnswered: battle.oppAnswered || [], reveal: battle.reveal || [], timerInt: null, locked: false, myScore: 0, oppScore: 0, myAnswered: battle.myAnswered || [] };
    if (S.quiz.timerInt) clearInterval(S.quiz.timerInt);
    S.quiz.timerInt = setInterval(tickLive, 100);
    tickLive();
  }
  function closeQuiz() {
    if (S.quiz && S.quiz.timerInt) clearInterval(S.quiz.timerInt);
    S.quiz = null;
    if (S.quizOv) { S.quizOv.classList.remove("open"); S.quizOv.innerHTML = ""; }
  }
  function qStart(k) { var b = S.quiz.battle; return b.startedAt + k * (b.seconds * 1000 + b.gap); }
  function tickLive() {
    var q = S.quiz; if (!q) return;
    var b = q.battle, t = srvNow(), n = b.qCount || q.qs.length || 5;
    if (t < b.startedAt) { renderCountdown(Math.ceil((b.startedAt - t) / 1000)); return; }
    var k = Math.min(n - 1, Math.floor((t - b.startedAt) / (b.seconds * 1000 + b.gap)));
    var within = t - qStart(k);
    var inGap = within > b.seconds * 1000;
    if (t >= b.deadline + 800) {
      // مهلت تمام شد؛ منتظر نتیجهٔ سرور
      if (!q.waitingResult) { q.waitingResult = true; renderLiveWaiting(); setTimeout(function () { if (S.quiz && S.quiz.waitingResult) pollWaitingResult(b.id); }, 1500); }
      return;
    }
    if (k !== q.idx) {
      q.idx = k; q.locked = false;
      if (!q.qs[k]) { fetchQuestion(k); }
      renderLiveQ();
    }
    var fill = document.getElementById("pvp-timer-fill");
    var left = Math.max(0, b.seconds * 1000 - within);
    if (fill) { fill.style.width = (left / (b.seconds * 1000) * 100) + "%"; fill.classList.toggle("low", left <= 3000); }
    var tl = document.getElementById("pvp-tleft"); if (tl) tl.textContent = fa(Math.ceil(left / 1000));
    if (inGap && !q.locked) { q.locked = true; markTimeout(); }
    if (inGap && q.reveal[k]) applyReveal(k);
  }
  function fetchQuestion(k) {
    var q = S.quiz; if (!q || q.fetching === k) return; q.fetching = k;
    api("/api/pvp?action=state&id=" + encodeURIComponent(q.battle.id)).then(function (r) {
      if (!S.quiz || !r.body || r.body.error) return;
      syncClock(r.body);
      if (r.body.status === "finished") { closeQuiz(); showResult(r.body); return; }
      (r.body.questions || []).forEach(function (qq, i) { if (qq && !S.quiz.qs[i]) S.quiz.qs[i] = qq; });
      S.quiz.oppAnswered = r.body.oppAnswered || S.quiz.oppAnswered; S.quiz.myAnswered = r.body.myAnswered || S.quiz.myAnswered;
      (r.body.reveal || []).forEach(function (rv, i) { if (rv) S.quiz.reveal[i] = rv; });
      S.quiz.fetching = -1;
      if (S.quiz.idx === k) renderLiveQ();
    });
  }
  function renderCountdown(sec) {
    var ov = S.quizOv, q = S.quiz;
    if (ov.getAttribute("data-mode") !== "cd") {
      ov.setAttribute("data-mode", "cd");
      ov.innerHTML = '<div class="gamify-modal pvp-quiz pvp-cd"><div class="pvp-versus">' + avatarHtml(q.battle.opponent.avatar, q.battle.opponent.name, 72) + '<div class="pvp-swords pulse">⚔️</div></div><h3>نبرد با ' + esc(q.battle.opponent.name) + '</h3><div class="pvp-cd-num" id="pvp-cd-num">' + fa(sec) + "</div><p class=\"pvp-sub\">هر دو هم‌زمان همین سؤال‌ها را می‌بینید — سریع‌تر و درست‌تر برنده است</p></div>";
    } else { var el = document.getElementById("pvp-cd-num"); if (el) el.textContent = fa(sec); }
  }
  function renderLiveQ() {
    var q = S.quiz; if (!q) return;
    var ov = S.quizOv; ov.setAttribute("data-mode", "q");
    var item = q.qs[q.idx], b = q.battle, n = b.qCount || q.qs.length || 5;
    var dots = ""; for (var i = 0; i < n; i++) dots += '<i class="' + (i < q.idx ? "done" : i === q.idx ? "cur" : "") + '"></i>';
    var head = '<div class="gamify-modal-head"><b>⚔️ ' + esc(b.opponent.name) + ' <small class="pvp-live-dot">● زنده</small></b><span class="pvp-count">' + fa(q.idx + 1) + " / " + fa(n) + ' · ⏱ <b id="pvp-tleft">' + fa(b.seconds) + '</b></span><button class="gamify-btn sm" data-exit="1">ترک ↩</button></div>' +
      '<div class="pvp-live-score"><span>تو: <b id="pvp-my-score">' + fa(q.myScore) + '</b></span><span id="pvp-opp-status">' + (q.oppAnswered[q.idx] ? "✅ حریف پاسخ داد" : "⏳ حریف در حال پاسخ…") + '</span><span>حریف: <b id="pvp-opp-score">' + fa(q.oppScore) + "</b></span></div>" +
      '<div class="pvp-progress">' + dots + "</div><div class=\"pvp-timerbar\"><i id=\"pvp-timer-fill\"></i></div>";
    if (!item) { ov.innerHTML = '<div class="gamify-modal pvp-quiz">' + head + '<div class="gamify-loading">در حال دریافت سؤال…</div></div>'; bindExit(); return; }
    ov.innerHTML = '<div class="gamify-modal pvp-quiz">' + head +
      '<h3 class="pvp-qtitle">' + esc(item.title) + "</h3>" +
      '<div class="pvp-opts">' + item.options.map(function (op, i) { return '<button class="pvp-opt" data-i="' + i + '"><span class="pvp-opt-key">' + ["۱", "۲", "۳", "۴", "۵", "۶"][i] + "</span>" + esc(op) + "</button>"; }).join("") + "</div>" +
      '<div class="pvp-feedback" id="pvp-feedback"></div></div>';
    ov.querySelectorAll(".pvp-opt").forEach(function (btn) { btn.addEventListener("click", function () { pick(parseInt(btn.getAttribute("data-i"), 10)); }); });
    bindExit();
    if (q.myAnswered[q.idx] || q.picked[q.idx] != null) { q.locked = true; ov.querySelectorAll(".pvp-opt").forEach(function (b2) { b2.disabled = true; }); if (q.picked[q.idx] >= 0) { var pb = ov.querySelector('.pvp-opt[data-i="' + q.picked[q.idx] + '"]'); if (pb) pb.classList.add("picked"); } }
    if (q.reveal[q.idx]) applyReveal(q.idx);
  }
  function bindExit() {
    var ex = S.quizOv.querySelector("[data-exit]");
    if (ex) ex.addEventListener("click", function () {
      if (!confirm("ترک نبرد = باخت فنی. مطمئنی؟")) return;
      var id = S.quiz.battle.id; closeQuiz();
      api("/api/pvp?action=forfeit", "POST", { id: id }).then(function () { refreshInbox(true); });
    });
  }
  function pick(i) {
    var q = S.quiz; if (!q || q.locked) return;
    q.locked = true; q.picked[q.idx] = i;
    var ov = S.quizOv, k = q.idx;
    ov.querySelectorAll(".pvp-opt").forEach(function (b2) { b2.disabled = true; });
    var btn = ov.querySelector('.pvp-opt[data-i="' + i + '"]'); if (btn) btn.classList.add("picked");
    var sendT = Date.now();
    api("/api/pvp?action=answer", "POST", { id: q.battle.id, q: k, i: i }).then(function (r) {
      if (!S.quiz || S.quiz.idx !== k) return;
      var fb = document.getElementById("pvp-feedback");
      if (!r.body || r.body.error) { if (fb) fb.innerHTML = '<span class="no">⚠️ ' + esc((r.body && (r.body.message || r.body.error)) || "ارسال نشد") + "</span>"; return; }
      if (r.body.late) { if (fb) fb.innerHTML = '<span class="no">⏰ دیر رسید!</span>'; return; }
      if (btn) btn.classList.add(r.body.correct ? "ok" : "no");
      if (fb) fb.innerHTML = r.body.correct ? '<span class="ok">✅ درست! ' + (Date.now() - sendT < 400 ? "" : "") + "</span>" : '<span class="no">❌ نادرست</span>';
      if (r.body.correct) { var limit = q.battle.seconds * 1000; var el = srvNow() - qStart(k); q.myScore += 100 + Math.max(0, Math.round(50 * (1 - Math.min(limit, el) / limit))); var ms = document.getElementById("pvp-my-score"); if (ms) ms.textContent = fa(q.myScore); }
    });
  }
  function markTimeout() {
    var q = S.quiz; if (!q) return;
    if (q.picked[q.idx] == null && !q.myAnswered[q.idx]) {
      q.picked[q.idx] = -1;
      var ov = S.quizOv; ov.querySelectorAll(".pvp-opt").forEach(function (b2) { b2.disabled = true; });
      var fb = document.getElementById("pvp-feedback"); if (fb) fb.innerHTML = '<span class="no">⏰ وقت تمام شد</span>';
      api("/api/pvp?action=answer", "POST", { id: q.battle.id, q: q.idx, i: -1 });
    }
  }
  function applyReveal(k) {
    var q = S.quiz; if (!q || q.idx !== k) return;
    var rv = q.reveal[k]; var ov = S.quizOv;
    var c = ov.querySelector('.pvp-opt[data-i="' + rv.correct + '"]'); if (c) c.classList.add("ok");
    var myPick = q.picked[k] != null ? q.picked[k] : rv.myPick;
    if (myPick >= 0 && myPick !== rv.correct) { var w = ov.querySelector('.pvp-opt[data-i="' + myPick + '"]'); if (w) w.classList.add("no"); }
    var fb = document.getElementById("pvp-feedback");
    if (fb && !fb.innerHTML) fb.innerHTML = '<span class="corr">پاسخ درست: ' + esc(q.qs[k] ? q.qs[k].options[rv.correct] : "") + "</span>";
    if (rv.oppPick != null) { var os = document.getElementById("pvp-opp-status"); if (os) os.textContent = rv.oppPick === rv.correct ? "✅ حریف درست زد" : (rv.oppPick < 0 ? "⏰ حریف پاسخ نداد" : "❌ حریف اشتباه زد"); }
    if (rv.explanation && fb) fb.insertAdjacentHTML("beforeend", '<div class="pvp-expl">💡 ' + esc(rv.explanation) + "</div>");
  }
  function renderLiveWaiting() {
    var q = S.quiz; if (!q) return;
    S.quizOv.setAttribute("data-mode", "w");
    S.quizOv.innerHTML = '<div class="gamify-modal pvp-quiz"><div class="gamify-loading">🏁 نبرد تمام شد؛ در حال محاسبهٔ نتیجه در سرور…</div></div>';
  }
  function pollWaitingResult(id) {
    api("/api/pvp?action=state&id=" + encodeURIComponent(id)).then(function (r) {
      if (!r.body || r.body.error) return;
      if (r.body.status === "finished" && r.body.result) { closeQuiz(); showResult(r.body); refreshInbox(true); }
      else if (S.quiz && S.quiz.waitingResult) setTimeout(function () { pollWaitingResult(id); }, 2500);
    });
  }
  function submitAnswers() {}

  // ---- انتظار نتیجه (برای نبردهای از پنل) ----
  function watchResult(id, fromPanel) {
    S.watching = id; if (fromPanel) closePanel();
    renderWatching();
    if (S.stateInt) clearInterval(S.stateInt);
    S.stateInt = setInterval(function () {
      api("/api/pvp?action=state&id=" + encodeURIComponent(id)).then(function (r) {
        if (!r.body || r.body.error) return;
        if (r.body.status === "finished" && r.body.result) { clearInterval(S.stateInt); S.stateInt = null; S.watching = null; closeWatching(); showResult(r.body); refreshInbox(true); }
        else if (r.body.status === "accepted") { clearInterval(S.stateInt); S.stateInt = null; S.watching = null; closeWatching(); openLive(r.body); }
      });
    }, 3000);
  }
  function renderWatching() {
    closeWatching();
    var d = document.createElement("div"); d.className = "pvp-mini-overlay"; d.id = "pvp-watching-modal";
    d.innerHTML = '<div class="gamify-modal pvp-mini"><div class="gamify-loading">⏳ منتظر پایان نبرد…</div><div class="pvp-acts center"><button class="gamify-btn sm" data-x="1">بستن</button></div></div>';
    document.body.appendChild(d);
    d.querySelector("[data-x]").addEventListener("click", function () { clearInterval(S.stateInt); S.stateInt = null; S.watching = null; closeWatching(); });
  }
  function closeWatching() { var d = document.getElementById("pvp-watching-modal"); if (d) d.remove(); }

  function showResultById(id) {
    api("/api/pvp?action=state&id=" + encodeURIComponent(id)).then(function (r) {
      if (!r.body || r.body.error || !r.body.result) { toast("⚠️ نتیجه هنوز آماده نیست."); return null; }
      showResult(r.body);
      return null;
    });
  }
  function showResult(b) {
    closeWatching();
    closeWaiting();
    var res = b.result;
    var iWon = res.winnerId && res.winnerId === S.me;
    var draw = !res.winnerId;
    var title = draw ? "مساوی شدید! ⚖️" : iWon ? "بردی! 🏆" : "این دور را باختی 💪";
    var cls = draw ? "draw" : iWon ? "win" : "lose";
    if (S.overlay && S.overlay.classList.contains("open")) S.overlay.classList.remove("open");
    var old = document.getElementById("pvp-result-modal");
    if (old) old.remove();
    var d = document.createElement("div");
    d.id = "pvp-result-modal";
    d.className = "pvp-mini-overlay";
    var per = res.perQ.map(function (q, i) {
      var myOk = q.myPick === q.correct;
      var opOk = q.oppPick === q.correct;
      return '<div class="pvp-perq">' +
        '<div class="t">' + esc(q.title) + "</div>" +
        '<div class="r"><span class="' + (myOk ? "ok" : "no") + '">' + (myOk ? "✅" : "❌") + " تو: " + (q.myPick >= 0 ? esc(q.options[q.myPick]) : "—") + " (+" + fa(q.myPts) + ')</span>' +
        '<span class="' + (opOk ? "ok" : "no") + '">' + (opOk ? "✅" : "❌") + " حریف: " + (q.oppPick >= 0 ? esc(q.options[q.oppPick]) : "—") + " (+" + fa(q.oppPts) + ")</span></div>" +
        (!myOk ? '<div class="corr">پاسخ درست: ' + esc(q.options[q.correct]) + (q.explanation ? " — " + esc(q.explanation) : "") + "</div>" : "") +
        "</div>";
    }).join("");
    d.innerHTML = '<div class="gamify-modal pvp-result ' + cls + '">' +
      '<div class="gamify-modal-head"><b>' + title + '</b><button data-x="1" class="gamify-btn sm">✕</button></div>' +
      '<div class="pvp-score-row">' +
        '<div class="pvp-side me"><div class="lbl">تو</div><div class="sc">' + fa(res.myScore) + '</div><div class="cc">✅ ' + fa(res.myCorrect) + " از " + fa(res.perQ.length) + "</div></div>" +
        '<div class="pvp-vs">VS</div>' +
        '<div class="pvp-side op"><div class="lbl">' + esc(b.opponent.name) + '</div><div class="sc">' + fa(res.oppScore) + '</div><div class="cc">✅ ' + fa(res.oppCorrect) + " از " + fa(res.perQ.length) + "</div></div>" +
      "</div>" +
      '<div class="pvp-hint center">+ امتیاز تجربه و سکهٔ نبرد به حسابت اضافه شد 🎁</div>' +
      '<div class="pvp-scroll">' + per + "</div>" +
      '<div class="pvp-acts center">' +
        '<button class="gamify-btn primary sm" data-rematch="' + b.id + '">🔁 مبارزهٔ مجدد</button>' +
        '<button class="gamify-btn sm" data-x="1">بستن</button>' +
      "</div></div>";
    document.body.appendChild(d);
    if (iWon) jingle();
    api("/api/pvp?action=ack", "POST", { id: b.id });
    d.querySelectorAll("[data-x]").forEach(function (el) { el.addEventListener("click", function () { closeResultModal(); }); });
    var rm = d.querySelector("[data-rematch]");
    if (rm) rm.addEventListener("click", function () { doRematch(b.id); });
    refreshInbox(true);
  }
  function closeResultModal() { var d = document.getElementById("pvp-result-modal"); if (d) d.remove(); }

  // ================= دعوت ورودی (مودال فوری) =================
  function showIncoming(b) {
    if (S.openInviteIds[b.id]) return;
    S.openInviteIds[b.id] = 1;
    var d = document.createElement("div");
    d.className = "pvp-mini-overlay";
    d.id = "pvp-invite-modal";
    d.innerHTML = '<div class="gamify-modal pvp-mini pvp-invite-in">' +
      '<div class="pvp-versus">' + avatarHtml(b.opponent.avatar, b.opponent.name, 84) + '<div class="pvp-swords">⚔️</div></div>' +
      "<h3>" + (b.byAdmin ? "🏟️ مسابقهٔ ویژه: " : "") + esc(b.opponent.name) + " تو را به نبرد زنده دعوت کرد!</h3>" +
      '<p class="pvp-sub">📚 دسته: ' + esc(catName(b.category)) + " · ۵ سؤال هم‌زمان · ۱۵ ثانیه هر سؤال</p>" +
      '<div class="pvp-acts center"><button class="gamify-btn primary" data-a="1">✅ قبول نبرد</button><button class="gamify-btn" data-d="1">❌ رد</button></div></div>';
    document.body.appendChild(d);
    jingle();
    d.querySelector("[data-a]").addEventListener("click", function () {
      d.remove(); delete S.openInviteIds[b.id];
      doAccept(b.id);
    });
    d.querySelector("[data-d]").addEventListener("click", function () {
      doSimple(b.id, "decline", "دعوت رد شد.");
    });
    setTimeout(function () { if (document.body.contains(d)) { d.remove(); delete S.openInviteIds[b.id]; refreshInbox(true); } }, 60000);
  }

  // ================= حلقهٔ نظارت =================
  function refreshInbox(silent) {
    if (!loggedIn()) return;
    api("/api/pvp?action=inbox").then(function (r) {
      if (!r.body || r.body.error || Array.isArray(r.body)) return;
      var prev = S.inbox;
      S.inbox = r.body;
      S.me = r.body.me;
      updateFabBadge();
      (r.body.incoming || []).forEach(function (b) { showIncoming(b); });
      // دعوت‌های من که تازه پذیرفته شده‌اند (اگر در حال انتظار نباشم: مثلاً پس از رفرش صفحه)
      (r.body.active || []).forEach(function (b) {
        if (!b.myDone && !S.quiz && !S.waiting && !S.promptedActive[b.id]) {
          var wasPending = prev && (prev.outgoing || []).some(function (o) { return o.id === b.id; });
          if (wasPending) toast("✅ " + (b.opponent.name || "حریف") + " پذیرفت — از پنل ⚔️ نبرد را شروع کن!");
          S.promptedActive[b.id] = 1;
        }
      });
      // نتایج دیده‌نشدهٔ جدید → تست
      (r.body.results || []).forEach(function (b) {
        if (!b.seen && !S.watching && !document.getElementById("pvp-result-modal")) {
          var seenBefore = prev && (prev.results || []).some(function (o) { return o.id === b.id && !o.seen; });
          if (!seenBefore && prev) toast("🏁 نتیجهٔ نبرد با " + (b.opponent.name || "حریف") + " آمد — پنل ⚔️");
        }
      });
      if (!silent && S.overlay && S.overlay.classList.contains("open")) renderPanel();
      else if (S.overlay && S.overlay.classList.contains("open")) renderPanel();
    });
  }

  function loadPlayers() {
    if (Date.now() - S.playersAt < 20000 && S.playersCache.length) { renderPanel(); return; }
    api("/api/players?limit=150&real=1").then(function (r) {
      if (Array.isArray(r.body)) {
        S.playersCache = r.body.filter(function (p) { return p && !p.isDemo; }).map(function (p) {
          return { id: p.id, name: p.name, avatar: p.avatar, xp: p.xp, wins: p.wins, online: p.online };
        });
        S.playersAt = Date.now();
        if (S.tab === "players") renderPanel();
      }
    });
  }

  function mountFab() {
    if (document.getElementById("gamify-pvp-fab")) return;
    var b = document.createElement("button");
    b.id = "gamify-pvp-fab";
    b.textContent = "⚔️";
    b.title = "نبرد واقعی بازیکن‌به‌بازیکن";
    b.addEventListener("click", openPanel);
    document.body.appendChild(b);
  }

  function onRt(type, data) {
    if (type === "pvp:invite" && data && data.battle) { syncClock(data.battle); refreshInbox(true); showIncoming(data.battle); }
    else if (type === "pvp:outgoing" && data && data.battle) { if (data.battle.byAdmin && !S.waiting) { toast("🏟️ مدیر برای تو مسابقه ترتیب داد!"); startWaiting(data.battle); } }
    else if (type === "pvp:accepted" && data && data.battle) { handleStateChange(data.battle); }
    else if (type === "pvp:q" && data && S.quiz && S.quiz.battle.id === data.id) { if (typeof data.serverNow === "number") clockOffset = data.serverNow - Date.now(); S.quiz.qs[data.q] = data.question; if (S.quiz.idx === data.q) renderLiveQ(); }
    else if (type === "pvp:reveal" && data && S.quiz && S.quiz.battle.id === data.id) { var ia = S.quiz.battle.iAmA; S.quiz.reveal[data.q] = { correct: data.correct, myPick: ia ? data.aPick : data.bPick, oppPick: ia ? data.bPick : data.aPick, explanation: data.explanation }; if (S.quiz.idx === data.q) applyReveal(data.q); }
    else if (type === "pvp:opp-answered" && data && S.quiz && S.quiz.battle.id === data.id) { S.quiz.oppAnswered[data.q] = true; if (S.quiz.idx === data.q) { var os = document.getElementById("pvp-opp-status"); if (os) os.textContent = "✅ حریف پاسخ داد"; } }
    else if (type === "pvp:finished" && data && data.battle) { if (S.quiz && S.quiz.battle.id === data.battle.id) closeQuiz(); stopWaiting(); if (S.watching === data.battle.id) { clearInterval(S.stateInt); S.stateInt = null; S.watching = null; closeWatching(); } showResult(data.battle); }
    else if (type === "pvp:update" && data) { if (S.waiting && S.waiting.id === data.id) handleStateChange({ id: data.id, status: data.status, opponent: S.waiting.opponent }); var inv = document.getElementById("pvp-invite-modal"); if (inv && (data.status === "cancelled" || data.status === "expired")) { inv.remove(); delete S.openInviteIds[data.id]; } refreshInbox(true); }
    else if (type === "connected") { refreshInbox(true); }
  }
  function boot() {
    mountFab();
    setTimeout(function () { refreshInbox(true); }, 2500);
    // رویدادهای زنده؛ polling فقط پشتیبان کم‌تکرار
    window.addEventListener("gamify:rt", function (e) { try { onRt(e.detail.type, e.detail.data); } catch (err) {} });
    S.pollInt = setInterval(function () { if (!document.hidden && !(window.__gamifyRT && window.__gamifyRT.connected())) refreshInbox(true); }, 12000);
    setInterval(function () { if (!document.hidden) refreshInbox(true); }, 45000);
    setInterval(function () { if (S.overlay && S.overlay.classList.contains("open") && S.tab === "players") { S.playersAt = 0; loadPlayers(); } }, 30000);
    document.addEventListener("visibilitychange", function () { if (!document.hidden) refreshInbox(true); });
    window.addEventListener("gamify:players", function () { S.playersAt = 0; });
    window.__gamifyPvpOpen = openPanel;
    window.__gamifyPvP = { open: openPanel, openBattle: openQuizFromState };
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot); else boot();
})();
