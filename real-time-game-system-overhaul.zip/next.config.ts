import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // تنظیمات بازی اصلی از پایگاه‌داده می‌آید تا مدیر همه‌چیز را آنلاین عوض کند
  async rewrites() {
    return { beforeFiles: [{ source: "/admin-config.json", destination: "/api/site-config" }] };
  },
  async headers() {
    return [{ source: "/api/events", headers: [{ key: "X-Accel-Buffering", value: "no" }] }];
  },
};

export default nextConfig;
