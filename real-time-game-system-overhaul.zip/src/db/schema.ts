import {
  pgTable, text, integer, bigint, boolean, jsonb, primaryKey, index,
} from "drizzle-orm/pg-core";

// ---------- کاربران (همگام با localStorage بازی اصلی) ----------
export const users = pgTable("users", {
  id: text("id").primaryKey(),
  localId: text("local_id"),
  name: text("name").notNull().default("میهمان"),
  avatar: jsonb("avatar").$type<unknown>().default({}),
  bio: text("bio").default(""),
  email: text("email").default(""),
  phone: text("phone").default(""),
  provider: text("provider").default("guest"),
  googleSub: text("google_sub").default(""),
  role: text("role").default("player"),
  orgId: text("org_id").default(""),
  xp: integer("xp").default(0),
  coins: integer("coins").default(50),
  cups: integer("cups").default(0),
  streak: integer("streak").default(0),
  wins: integer("wins").default(0),
  played: integer("played").default(0),
  rating: integer("rating").default(1000),
  weekXp: integer("week_xp").default(0),
  level: integer("level").default(1),
  interests: jsonb("interests").$type<string[]>().default([]),
  friends: jsonb("friends").$type<string[]>().default([]),
  isPrivate: boolean("is_private").default(false),
  banned: boolean("banned").default(false),
  isDemo: boolean("is_demo").default(false),
  lastSeen: bigint("last_seen", { mode: "number" }).default(0),
  lastDaily: text("last_daily").default(""),
  createdAt: bigint("created_at", { mode: "number" }).notNull(),
  extra: jsonb("extra").$type<Record<string, unknown>>().default({}),
}, (t) => [
  index("users_xp_idx").on(t.xp),
  index("users_org_idx").on(t.orgId),
  index("users_local_idx").on(t.localId),
  index("users_last_seen_idx").on(t.isDemo, t.lastSeen),
  index("users_role_idx").on(t.role),
]);

export const sessions = pgTable("sessions", {
  token: text("token").primaryKey(),
  userId: text("user_id").notNull(),
  csrf: text("csrf").notNull().default(""),
  expires: bigint("expires", { mode: "number" }).notNull(),
});

// ---------- سازمان‌ها ----------
export const organizations = pgTable("organizations", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull().default(""),
  description: text("description").default(""),
  logo: text("logo").default("⚡"),
  color: text("color").default("#f8c56c"),
  autoTournament: boolean("auto_tournament").default(true),
  memberCount: integer("member_count").default(0),
  createdAt: bigint("created_at", { mode: "number" }).notNull(),
});

export const orgMembers = pgTable("org_members", {
  orgId: text("org_id").notNull(),
  userId: text("user_id").notNull(),
  status: text("status").default("approved"),
  joinedAt: bigint("joined_at", { mode: "number" }).notNull(),
}, (t) => [primaryKey({ columns: [t.orgId, t.userId] })]);

// ---------- پیام‌ها ----------
export const messages = pgTable("messages", {
  id: text("id").primaryKey(),
  sender: text("sender").notNull(),
  recipient: text("recipient").notNull(),
  body: text("body").default(""),
  media: text("media").default(""),
  createdAt: bigint("created_at", { mode: "number" }).notNull(),
  seen: integer("seen").default(0),
}, (t) => [index("msg_pair_idx").on(t.sender, t.recipient), index("msg_recipient_idx").on(t.recipient, t.createdAt)]);

// ---------- دسته‌ها و سؤال‌ها ----------
export const categories = pgTable("categories", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  subtitle: text("subtitle").default(""),
  icon: text("icon").default("globe"),
  color: text("color").default("#a98cf7"),
  tag: text("tag").default(""),
  safety: integer("safety").default(0),
  active: integer("active").default(1),
});

export const questions = pgTable("questions", {
  id: text("id").primaryKey(),
  category: text("category").notNull(),
  title: text("title").notNull(),
  options: jsonb("options").$type<string[]>().notNull(),
  correct: integer("correct").notNull(),
  explanation: text("explanation").default(""),
  source: text("source").default(""),
  seconds: integer("seconds").default(25),
  kind: text("kind").default("text"),
  media: text("media").default(""),
  status: text("status").default("approved"),
  author: text("author").default(""),
});

// ---------- قبیله‌ها ----------
export const tribes = pgTable("tribes", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  tag: text("tag").notNull().default(""),
  description: text("description").default(""),
  motto: text("motto").default(""),
  logoEmoji: text("logo_emoji").default("🛡️"),
  logoColor: text("logo_color").default("#a98cf7"),
  ownerId: text("owner_id").notNull(),
  maxMembers: integer("max_members").default(30),
  wins: integer("wins").default(0),
  losses: integer("losses").default(0),
  xp: integer("xp").default(0),
  rating: integer("rating").default(1000),
  isPublic: boolean("is_public").default(true),
  inviteCode: text("invite_code").default(""),
  createdAt: bigint("created_at", { mode: "number" }).notNull(),
}, (t) => [index("tribes_xp_idx").on(t.xp)]);

export const tribeMembers = pgTable("tribe_members", {
  tribeId: text("tribe_id").notNull(),
  userId: text("user_id").notNull(),
  role: text("role").default("member"),
  contributedXp: integer("contributed_xp").default(0),
  joinedAt: bigint("joined_at", { mode: "number" }).notNull(),
}, (t) => [primaryKey({ columns: [t.tribeId, t.userId] })]);

export const tribeInvites = pgTable("tribe_invites", {
  id: text("id").primaryKey(),
  tribeId: text("tribe_id").notNull(),
  userId: text("user_id").notNull(),
  inviterId: text("inviter_id").notNull(),
  status: text("status").default("pending"),
  createdAt: bigint("created_at", { mode: "number" }).notNull(),
});

export const tribeBattles = pgTable("tribe_battles", {
  id: text("id").primaryKey(),
  tribeA: text("tribe_a").notNull(),
  tribeB: text("tribe_b").notNull(),
  category: text("category").default("general"),
  status: text("status").default("pending"),
  questions: jsonb("questions").$type<unknown[]>().default([]),
  scoreA: integer("score_a").default(0),
  scoreB: integer("score_b").default(0),
  winnerId: text("winner_id").default(""),
  createdBy: text("created_by").default(""),
  startsAt: bigint("starts_at", { mode: "number" }).default(0),
  endsAt: bigint("ends_at", { mode: "number" }).default(0),
  createdAt: bigint("created_at", { mode: "number" }).notNull(),
});

export const tribeBattleScores = pgTable("tribe_battle_scores", {
  battleId: text("battle_id").notNull(),
  userId: text("user_id").notNull(),
  tribeId: text("tribe_id").notNull(),
  score: integer("score").default(0),
  correct: integer("correct").default(0),
  answers: jsonb("answers").$type<unknown[]>().default([]),
  createdAt: bigint("created_at", { mode: "number" }).notNull(),
}, (t) => [primaryKey({ columns: [t.battleId, t.userId] })]);

// ---------- نبرد واقعی بازیکن‌به‌بازیکن (PvP) ----------
export const pvpBattles = pgTable("pvp_battles", {
  id: text("id").primaryKey(),
  aId: text("a_id").notNull(), // چالش‌گر
  bId: text("b_id").notNull(), // حریف
  aName: text("a_name").default(""),
  bName: text("b_name").default(""),
  category: text("category").default("general"),
  questions: jsonb("questions").$type<unknown[]>().default([]), // کامل با پاسخ صحیح — فقط سرور
  status: text("status").default("pending"), // pending | accepted | declined | finished | expired | cancelled
  aAnswers: jsonb("a_answers").$type<unknown[]>().default([]),
  bAnswers: jsonb("b_answers").$type<unknown[]>().default([]),
  aScore: integer("a_score").default(0),
  bScore: integer("b_score").default(0),
  aCorrect: integer("a_correct").default(0),
  bCorrect: integer("b_correct").default(0),
  aMs: integer("a_ms").default(0),
  bMs: integer("b_ms").default(0),
  aDoneAt: bigint("a_done_at", { mode: "number" }).default(0),
  bDoneAt: bigint("b_done_at", { mode: "number" }).default(0),
  aSeen: integer("a_seen").default(0),
  bSeen: integer("b_seen").default(0),
  winnerId: text("winner_id").default(""),
  rematchOf: text("rematch_of").default(""),
  createdAt: bigint("created_at", { mode: "number" }).notNull(),
  expiresAt: bigint("expires_at", { mode: "number" }).default(0),
  finishedAt: bigint("finished_at", { mode: "number" }).default(0),
  startedAt: bigint("started_at", { mode: "number" }).default(0), // لحظهٔ شروع هم‌زمان (سرور)
  byAdmin: text("by_admin").default(""), // اگر مدیر این نبرد را ترتیب داده باشد
  mode: text("mode").default("live"), // live = هم‌زمان | async = نوبتی
}, (t) => [
  index("pvp_status_idx").on(t.status, t.expiresAt),
  index("pvp_a_idx").on(t.aId, t.status),
  index("pvp_b_idx").on(t.bId, t.status),
]);

// ---------- تورنمنت‌ها ----------
export const tournaments = pgTable("tournaments", {
  id: text("id").primaryKey(),
  title: text("title").notNull(),
  category: text("category").default("general"),
  startsAt: bigint("starts_at", { mode: "number" }).notNull(),
  endsAt: bigint("ends_at", { mode: "number" }).notNull(),
  description: text("description").default(""),
  orgId: text("org_id").default(""),
  tribeOnly: boolean("tribe_only").default(false),
  maxPlayers: integer("max_players").default(500),
  questions: jsonb("questions").$type<unknown[]>().default([]),
  active: boolean("active").default(true),
  createdBy: text("created_by").default(""),
  createdAt: bigint("created_at", { mode: "number" }).notNull(),
});

export const tournamentPlayers = pgTable("tournament_players", {
  tournamentId: text("tournament_id").notNull(),
  userId: text("user_id").notNull(),
  score: integer("score").default(0),
  rank: integer("rank").default(0),
  joinedAt: bigint("joined_at", { mode: "number" }).notNull(),
}, (t) => [primaryKey({ columns: [t.tournamentId, t.userId] })]);

// ---------- پست و استوری (بکاپ سرور + صف تأیید) ----------
export const posts = pgTable("posts", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull(),
  userName: text("user_name").default(""),
  category: text("category").default("work"),
  body: text("body").notNull(),
  media: text("media").default(""),
  audio: text("audio").default(""),
  status: text("status").default("pending"),
  likes: integer("likes").default(0),
  autoApproved: boolean("auto_approved").default(false),
  moderatedBy: text("moderated_by").default(""),
  moderatedAt: bigint("moderated_at", { mode: "number" }).default(0),
  createdAt: bigint("created_at", { mode: "number" }).notNull(),
}, (t) => [index("posts_status_idx").on(t.status)]);

export const stories = pgTable("stories", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull(),
  userName: text("user_name").default(""),
  category: text("category").default("general"),
  title: text("title").notNull(),
  options: jsonb("options").$type<string[]>().default([]),
  correct: integer("correct").default(0),
  explanation: text("explanation").default(""),
  media: text("media").default(""),
  status: text("status").default("pending"),
  autoApproved: boolean("auto_approved").default(false),
  moderatedBy: text("moderated_by").default(""),
  createdAt: bigint("created_at", { mode: "number" }).notNull(),
  expiresAt: bigint("expires_at", { mode: "number" }).notNull(),
}, (t) => [index("stories_status_idx").on(t.status)]);

// ---------- اجتماعی ----------
export const follows = pgTable("follows", {
  userId: text("user_id").notNull(),
  targetId: text("target_id").notNull(),
  status: text("status").default("approved"),
}, (t) => [primaryKey({ columns: [t.userId, t.targetId] })]);

export const notifications = pgTable("notifications", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull(),
  title: text("title").notNull(),
  body: text("body").default(""),
  link: text("link").default(""),
  createdAt: bigint("created_at", { mode: "number" }).notNull(),
  seen: integer("seen").default(0),
}, (t) => [index("notif_user_idx").on(t.userId, t.seen)]);

// ---------- دستاوردها و پاداش روزانه ----------
export const achievements = pgTable("achievements", {
  id: text("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").default(""),
  icon: text("icon").default("🏆"),
  xpReward: integer("xp_reward").default(50),
  coinReward: integer("coin_reward").default(25),
});

export const userAchievements = pgTable("user_achievements", {
  userId: text("user_id").notNull(),
  achievementId: text("achievement_id").notNull(),
  unlockedAt: bigint("unlocked_at", { mode: "number" }).notNull(),
}, (t) => [primaryKey({ columns: [t.userId, t.achievementId] })]);

export const dailyClaims = pgTable("daily_claims", {
  userId: text("user_id").notNull(),
  day: text("day").notNull(),
  coins: integer("coins").default(25),
  streak: integer("streak").default(1),
  createdAt: bigint("created_at", { mode: "number" }).notNull(),
}, (t) => [primaryKey({ columns: [t.userId, t.day] })]);

// ---------- آپلود و تنظیمات و لاگ ----------
export const uploads = pgTable("uploads", {
  id: text("id").primaryKey(),
  owner: text("owner").notNull(),
  path: text("path").notNull(),
  mime: text("mime").notNull(),
  size: integer("size").notNull(),
  createdAt: bigint("created_at", { mode: "number" }).notNull(),
});

export const settings = pgTable("settings", {
  key: text("key").primaryKey(),
  value: text("value").notNull(),
});

export const auditLog = pgTable("audit_log", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  actor: text("actor").default(""),
  action: text("action").default(""),
  target: text("target").default(""),
  createdAt: bigint("created_at", { mode: "number" }).notNull(),
});

// ---------- اعلان سراسری مدیر (پنجرهٔ پاپ‌آپ) ----------
export const broadcasts = pgTable("broadcasts", {
  id: text("id").primaryKey(),
  title: text("title").notNull(),
  body: text("body").default(""),
  image: text("image").default(""),
  link: text("link").default(""), // بخش داخلی بازی مثل feed / tribes / tournaments یا URL
  target: text("target").default("all"), // all | real | org:<id> | tribe:<id> | user:<id>
  active: boolean("active").default(true),
  createdBy: text("created_by").default(""),
  createdAt: bigint("created_at", { mode: "number" }).notNull(),
  expiresAt: bigint("expires_at", { mode: "number" }).default(0),
}, (t) => [index("broadcasts_active_idx").on(t.active, t.createdAt)]);

export type UserRow = typeof users.$inferSelect;
