import { eq, desc, or } from "drizzle-orm";
import { db } from "@/db";
import { posts, stories, notifications, auditLog } from "@/db/schema";
import { uid, now, json, getSessionUser } from "@/lib/auth";
import { ensureSeed } from "@/lib/ensure-seed";
import { requireAdmin } from "@/lib/admin";
import { publish } from "@/lib/realtime";

function isAdmin(role: string | null | undefined) {
  return role === "admin";
}

// GET: صف زندهٔ تأیید (پست‌ها + استوری‌های pending)
export async function GET(req: Request) {
  await ensureSeed();
  const adm = await requireAdmin(req);
  if (!adm) return json({ error: "forbidden", message: "برای این بخش باید با کد مدیریت وارد شوی." }, 403);
  const me = adm.me;
  const p = await db.select().from(posts).where(eq(posts.status, "pending")).orderBy(desc(posts.createdAt)).limit(100);
  const s = await db.select().from(stories).where(eq(stories.status, "pending")).orderBy(desc(stories.createdAt)).limit(100);
  const recent = await db.select().from(posts).where(or(eq(posts.status, "approved"), eq(posts.status, "rejected"))).orderBy(desc(posts.createdAt)).limit(20);
  return json({ posts: p, stories: s, recent });
}

// POST ?action=decide|edit — تأیید/رد/ویرایش (بدون اخلال در اتوماسیون: autoApproved حفظ می‌شود)
export async function POST(req: Request) {
  await ensureSeed();
  const adm = await requireAdmin(req);
  if (!adm) return json({ error: "forbidden", message: "برای این بخش باید با کد مدیریت وارد شوی." }, 403);
  const me = adm.me;
  const actor = adm.name || me?.name || "مدیر";
  const action = new URL(req.url).searchParams.get("action") || "decide";
  let b: Record<string, unknown> = {};
  try { b = await req.json(); } catch { b = {}; }
  const kind = String(b.kind || "post");
  const id = String(b.id || "");
  const status = String(b.status || "");
  if (!["approved", "rejected"].includes(status)) return json({ error: "وضعیت نامعتبر" }, 400);

  if (action === "edit") {
    if (kind === "story") {
      const patch: Record<string, unknown> = { moderatedBy: actor };
      if (typeof b.title === "string") patch.title = (b.title as string).slice(0, 500);
      if (typeof b.explanation === "string") patch.explanation = (b.explanation as string).slice(0, 1000);
      if (Array.isArray(b.options)) patch.options = (b.options as string[]).slice(0, 4);
      await db.update(stories).set(patch).where(eq(stories.id, id));
    } else {
      const patch: Record<string, unknown> = { moderatedBy: actor, moderatedAt: now() };
      if (typeof b.body === "string") patch.body = (b.body as string).slice(0, 4000);
      await db.update(posts).set(patch).where(eq(posts.id, id));
    }
    try { await db.insert(auditLog).values({ actor, action: `edit-${kind}`, target: id, createdAt: now() }); } catch { /* ignore */ }
    return json({ ok: true });
  }

  // decide
  if (kind === "story") {
    const row = (await db.select().from(stories).where(eq(stories.id, id)).limit(1))[0];
    if (!row) return json({ error: "not-found" }, 404);
    await db.update(stories).set({ status, moderatedBy: actor }).where(eq(stories.id, id));
    if (status === "approved" && row) publish("*", "feed:story", { id: row.id, authorId: row.userId, author: row.userName, category: row.category, title: row.title, options: row.options, correct: row.correct, explanation: row.explanation, media: row.media, at: row.createdAt, expiresAt: row.expiresAt });
    try {
      await db.insert(notifications).values({ id: uid("n"), userId: row.userId, title: status === "approved" ? "✅ استوری‌ات منتشر شد!" : "⚠️ استوری‌ات نیاز به اصلاح دارد", body: status === "approved" ? "مدیر استوری‌ات را تأیید کرد." : "مدیر استوری‌ات را رد کرد؛ ویرایشش کن و دوباره بفرست.", link: "#feed", createdAt: now(), seen: 0 });
      await db.insert(auditLog).values({ actor, action: `${status}-story`, target: id, createdAt: now() });
    } catch { /* ignore */ }
  } else {
    const row = (await db.select().from(posts).where(eq(posts.id, id)).limit(1))[0];
    if (!row) return json({ error: "not-found" }, 404);
    await db.update(posts).set({ status, moderatedBy: actor, moderatedAt: now() }).where(eq(posts.id, id));
    if (status === "approved" && row) publish("*", "feed:post", { id: row.id, authorId: row.userId, author: row.userName, category: row.category, body: row.body, media: row.media, audio: row.audio, at: row.createdAt });
    try {
      await db.insert(notifications).values({ id: uid("n"), userId: row.userId, title: status === "approved" ? "✅ پستت منتشر شد!" : "⚠️ پستت نیاز به اصلاح دارد", body: status === "approved" ? "مدیر پستت را تأیید کرد." : "مدیر پستت را رد کرد؛ ویرایشش کن و دوباره بفرست.", link: "#feed", createdAt: now(), seen: 0 });
      await db.insert(auditLog).values({ actor, action: `${status}-post`, target: id, createdAt: now() });
    } catch { /* ignore */ }
  }
  return json({ ok: true });
}
