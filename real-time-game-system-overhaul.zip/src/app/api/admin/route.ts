import { desc, count, gte, eq, asc, and, or, ilike, sql, ne, inArray } from "drizzle-orm";
import { db } from "@/db";
import { users, tribes, tribeMembers, posts, stories, auditLog, tournaments, tribeBattles, pvpBattles, broadcasts, categories, organizations, notifications } from "@/db/schema";
import { json, pub, getSessionUser, now, uid } from "@/lib/auth";
import { ensureSeed } from "@/lib/ensure-seed";
import { requireAdmin, adminCode, safeEqual, signAdminToken, setSetting, getJsonSetting, getSetting, maskPhone, maskEmail } from "@/lib/admin";
import { publish, connectionCount, isConnected } from "@/lib/realtime";

/**
 * 🛠️ پنل مدیریت — همهٔ عملیات سمت سرور با کنترل نقش مدیر
 * GET  ?view=overview | users | user&id= | broadcasts | settings | tribes | orgs | categories
 * POST ?action=login | ban | unban | make-admin | remove-admin | set-avatar | set-name | set-org | set-role |
 *               add-to-tribe | remove-from-tribe | broadcast | delete-broadcast | publish-settings | set-moderation |
 *               reveal-contact | delete-user | set-category | notify-user
 */

const ONLINE_MS = 2 * 60000;

function userKind(u: typeof users.$inferSelect) {
  if (u.isDemo) return "bot";
  if (u.role === "admin") return "admin";
  if (u.provider && u.provider !== "guest") return "real";
  if ((u.phone || "").trim() || (u.email || "").trim()) return "real";
  return "guest";
}

function adminRow(u: typeof users.$inferSelect, reveal = false) {
  return {
    ...pub(u),
    kind: userKind(u),
    online: isConnected(u.id) || (u.lastSeen ?? 0) > now() - ONLINE_MS,
    live: isConnected(u.id),
    phone: reveal ? (u.phone || "") : maskPhone(u.phone || ""),
    email: reveal ? (u.email || "") : maskEmail(u.email || ""),
    hasPhone: !!(u.phone || "").trim(),
    hasEmail: !!(u.email || "").trim(),
    banned: !!u.banned,
  };
}

async function audit(actor: string, action: string, target: string) {
  try { await db.insert(auditLog).values({ actor, action, target, createdAt: now() }); } catch { /* ignore */ }
}

export async function GET(req: Request) {
  await ensureSeed();
  const adm = await requireAdmin(req);
  if (!adm) return json({ error: "forbidden", message: "برای این بخش باید با کد مدیریت وارد شوی." }, 403);
  const url = new URL(req.url);
  const view = url.searchParams.get("view") || "overview";

  if (view === "users") {
    const q = (url.searchParams.get("q") || "").trim().slice(0, 60);
    const kind = url.searchParams.get("kind") || "real"; // real | guest | bot | admin | all | online
    const page = Math.max(1, Number(url.searchParams.get("page") || 1));
    const size = Math.min(100, Math.max(10, Number(url.searchParams.get("size") || 30)));
    const conds = [];
    if (kind === "bot") conds.push(eq(users.isDemo, true));
    else if (kind === "admin") conds.push(and(eq(users.isDemo, false), eq(users.role, "admin")));
    else if (kind === "real") conds.push(and(eq(users.isDemo, false), or(ne(users.provider, "guest"), ne(users.phone, ""), ne(users.email, ""))));
    else if (kind === "guest") conds.push(and(eq(users.isDemo, false), eq(users.provider, "guest"), eq(users.phone, ""), eq(users.email, "")));
    else if (kind === "online") conds.push(and(eq(users.isDemo, false), gte(users.lastSeen, now() - ONLINE_MS)));
    if (q) {
      const like = `%${q}%`;
      conds.push(or(ilike(users.name, like), ilike(users.phone, like), ilike(users.email, like), ilike(users.orgId, like), eq(users.id, q)));
    }
    const where = conds.length ? and(...conds) : undefined;
    const total = await db.select({ c: count() }).from(users).where(where);
    const rows = await db.select().from(users).where(where)
      .orderBy(asc(users.isDemo), desc(users.lastSeen)).limit(size).offset((page - 1) * size);
    // عضویت قبیله برای همین صفحه
    const ids = rows.map((r) => r.id);
    const tm = ids.length ? await db.select({ userId: tribeMembers.userId, tribeId: tribeMembers.tribeId, name: tribes.name }).from(tribeMembers).leftJoin(tribes, eq(tribes.id, tribeMembers.tribeId)).where(inArray(tribeMembers.userId, ids)) : [];
    const tribeOf = new Map(tm.map((x) => [x.userId, { id: x.tribeId, name: x.name || "" }]));
    const counts = await db.select({
      real: sql<number>`count(*) filter (where is_demo = false and (provider <> 'guest' or phone <> '' or email <> ''))`,
      guest: sql<number>`count(*) filter (where is_demo = false and provider = 'guest' and phone = '' and email = '')`,
      bot: sql<number>`count(*) filter (where is_demo = true)`,
      admin: sql<number>`count(*) filter (where is_demo = false and role = 'admin')`,
      online: sql<number>`count(*) filter (where is_demo = false and last_seen > ${now() - ONLINE_MS})`,
    }).from(users);
    return json({
      page, size, total: Number(total[0]?.c ?? 0),
      users: rows.map((u) => ({ ...adminRow(u), tribe: tribeOf.get(u.id) || null })),
      counts: { real: Number(counts[0]?.real ?? 0), guest: Number(counts[0]?.guest ?? 0), bot: Number(counts[0]?.bot ?? 0), admin: Number(counts[0]?.admin ?? 0), online: Number(counts[0]?.online ?? 0), live: connectionCount() },
    });
  }

  if (view === "user") {
    const id = url.searchParams.get("id") || "";
    const u = (await db.select().from(users).where(eq(users.id, id)).limit(1))[0];
    if (!u) return json({ error: "not-found" }, 404);
    const tm = (await db.select({ tribeId: tribeMembers.tribeId, name: tribes.name, role: tribeMembers.role }).from(tribeMembers).leftJoin(tribes, eq(tribes.id, tribeMembers.tribeId)).where(eq(tribeMembers.userId, id)).limit(1))[0];
    const org = u.orgId ? (await db.select().from(organizations).where(eq(organizations.id, u.orgId)).limit(1))[0] : null;
    const battles = await db.select().from(pvpBattles).where(and(eq(pvpBattles.status, "finished"), or(eq(pvpBattles.aId, id), eq(pvpBattles.bId, id)))).orderBy(desc(pvpBattles.finishedAt)).limit(10);
    return json({
      user: adminRow(u, false),
      tribe: tm ? { id: tm.tribeId, name: tm.name, role: tm.role } : null,
      org: org ? { id: org.id, name: org.name } : null,
      battles: battles.map((b) => ({ id: b.id, at: b.finishedAt, opp: b.aId === id ? b.bName : b.aName, my: b.aId === id ? b.aScore : b.bScore, their: b.aId === id ? b.bScore : b.aScore, won: b.winnerId === id })),
    });
  }

  if (view === "tribes") {
    const rows = await db.select().from(tribes).orderBy(desc(tribes.xp)).limit(200);
    return json(rows.map((t) => ({ id: t.id, name: t.name, tag: t.tag, logo: t.logoEmoji, members: 0, xp: t.xp })));
  }
  if (view === "orgs") {
    return json(await db.select().from(organizations).orderBy(asc(organizations.name)));
  }
  if (view === "categories") {
    return json(await db.select().from(categories).orderBy(asc(categories.name)));
  }
  if (view === "broadcasts") {
    return json(await db.select().from(broadcasts).orderBy(desc(broadcasts.createdAt)).limit(50));
  }
  if (view === "settings") {
    const site = await getJsonSetting<Record<string, unknown>>("site-config", {});
    const textOverrides = await getJsonSetting<Record<string, string>>("text-overrides", {});
    const assetOverrides = await getJsonSetting<Record<string, string>>("asset-overrides", {});
    return json({
      site, textOverrides, assetOverrides,
      moderatePosts: (await getSetting("moderatePosts", "false")) === "true",
      moderateStories: (await getSetting("moderateStories", "false")) === "true",
      hasEnvAdminCode: !!process.env.ADMIN_CODE,
    });
  }
  if (view === "logs") {
    return json(await db.select().from(auditLog).orderBy(desc(auditLog.id)).limit(100));
  }

  // overview
  const [totalUsers, realUsers, onlineUsers, totalTribes, pendingPosts, pendingStories, totalTournaments, activeBattles, liveDuels] = await Promise.all([
    db.select({ c: count() }).from(users),
    db.select({ c: count() }).from(users).where(and(eq(users.isDemo, false), or(ne(users.provider, "guest"), ne(users.phone, ""), ne(users.email, "")))),
    db.select({ c: count() }).from(users).where(and(eq(users.isDemo, false), gte(users.lastSeen, now() - ONLINE_MS))),
    db.select({ c: count() }).from(tribes),
    db.select({ c: count() }).from(posts).where(eq(posts.status, "pending")),
    db.select({ c: count() }).from(stories).where(eq(stories.status, "pending")),
    db.select({ c: count() }).from(tournaments),
    db.select({ c: count() }).from(tribeBattles).where(eq(tribeBattles.status, "active")),
    db.select({ c: count() }).from(pvpBattles).where(eq(pvpBattles.status, "accepted")),
  ]);
  const recentRealUsers = await db.select().from(users).where(eq(users.isDemo, false)).orderBy(desc(users.lastSeen)).limit(15);
  const logs = await db.select().from(auditLog).orderBy(desc(auditLog.id)).limit(20);
  return json({
    admin: { name: adm.name, via: adm.via },
    stats: {
      totalUsers: Number(totalUsers[0]?.c ?? 0),
      realUsers: Number(realUsers[0]?.c ?? 0),
      onlineUsers: Number(onlineUsers[0]?.c ?? 0),
      liveConnections: connectionCount(),
      totalTribes: Number(totalTribes[0]?.c ?? 0),
      pendingPosts: Number(pendingPosts[0]?.c ?? 0),
      pendingStories: Number(pendingStories[0]?.c ?? 0),
      totalTournaments: Number(totalTournaments[0]?.c ?? 0),
      activeBattles: Number(activeBattles[0]?.c ?? 0),
      liveDuels: Number(liveDuels[0]?.c ?? 0),
    },
    recentUsers: recentRealUsers.map((u) => adminRow(u)),
    logs,
  });
}

export async function POST(req: Request) {
  await ensureSeed();
  const url = new URL(req.url);
  const action = url.searchParams.get("action") || "";
  let b: Record<string, unknown> = {};
  try { b = await req.json(); } catch { b = {}; }

  // ---- ورود مدیر با کد مدیریت (سمت سرور) ----
  if (action === "login") {
    const code = String(b.code || "");
    if (!code || !safeEqual(code, adminCode())) {
      await new Promise((r) => setTimeout(r, 400)); // کند کردن brute-force
      return json({ error: "کد مدیریت نادرست است." }, 401);
    }
    const me = await getSessionUser();
    const name = String(b.name || me?.name || "مدیر").slice(0, 40);
    if (me && me.role !== "admin") {
      await db.update(users).set({ role: "admin" }).where(eq(users.id, me.id));
    }
    await audit(name, "admin-login", me?.id || "");
    return json({ ok: true, token: signAdminToken(name), name, userId: me?.id || "" });
  }

  const adm = await requireAdmin(req);
  if (!adm) return json({ error: "forbidden", message: "برای این بخش باید با کد مدیریت وارد شوی." }, 403);
  const actor = adm.name;
  const userId = String(b.userId || "");

  const needUser = async () => {
    if (!userId) return null;
    return (await db.select().from(users).where(eq(users.id, userId)).limit(1))[0] || null;
  };

  switch (action) {
    case "ban": case "unban": {
      if (!userId) return json({ error: "bad-request" }, 400);
      await db.update(users).set({ banned: action === "ban" }).where(eq(users.id, userId));
      break;
    }
    case "make-admin": case "remove-admin": {
      if (!userId) return json({ error: "bad-request" }, 400);
      await db.update(users).set({ role: action === "make-admin" ? "admin" : "player" }).where(eq(users.id, userId));
      break;
    }
    case "set-avatar": {
      if (!userId) return json({ error: "bad-request" }, 400);
      const img = Number(b.img);
      const avatar = Number.isInteger(img) && img >= 1 && img <= 20 ? { img } : (b.avatar && typeof b.avatar === "object" ? b.avatar : null);
      if (!avatar) return json({ error: "آواتار نامعتبر" }, 400);
      await db.update(users).set({ avatar }).where(eq(users.id, userId));
      publish([userId], "profile:avatar", { avatar });
      break;
    }
    case "set-name": {
      const u = await needUser(); if (!u) return json({ error: "not-found" }, 404);
      const name = String(b.name || "").trim().slice(0, 40);
      if (name.length < 2) return json({ error: "نام کوتاه است" }, 400);
      await db.update(users).set({ name }).where(eq(users.id, userId));
      break;
    }
    case "set-org": {
      const u = await needUser(); if (!u) return json({ error: "not-found" }, 404);
      await db.update(users).set({ orgId: String(b.orgId || "").slice(0, 40) }).where(eq(users.id, userId));
      break;
    }
    case "set-coins": {
      const u = await needUser(); if (!u) return json({ error: "not-found" }, 404);
      const delta = Math.max(-100000, Math.min(100000, Number(b.delta) || 0));
      await db.update(users).set({ coins: sql`GREATEST(0, ${users.coins} + ${delta})` }).where(eq(users.id, userId));
      publish([userId], "profile:coins", { delta });
      break;
    }
    case "add-to-tribe": {
      const u = await needUser(); if (!u) return json({ error: "not-found" }, 404);
      const tribeId = String(b.tribeId || "");
      const t = (await db.select().from(tribes).where(eq(tribes.id, tribeId)).limit(1))[0];
      if (!t) return json({ error: "قبیله پیدا نشد" }, 404);
      await db.delete(tribeMembers).where(eq(tribeMembers.userId, userId));
      await db.insert(tribeMembers).values({ tribeId, userId, role: "member", contributedXp: 0, joinedAt: now() }).onConflictDoNothing();
      await db.insert(notifications).values({ id: uid("n"), userId, title: "🛡️ عضو قبیله شدی", body: `مدیر تو را به قبیلهٔ «${t.name}» اضافه کرد.`, link: "tribes", createdAt: now(), seen: 0 });
      publish([userId], "tribe:joined", { tribeId, name: t.name });
      break;
    }
    case "remove-from-tribe": {
      if (!userId) return json({ error: "bad-request" }, 400);
      await db.delete(tribeMembers).where(eq(tribeMembers.userId, userId));
      publish([userId], "tribe:left", {});
      break;
    }
    case "reveal-contact": {
      const u = await needUser(); if (!u) return json({ error: "not-found" }, 404);
      await audit(actor, "reveal-contact", userId);
      return json({ ok: true, phone: u.phone || "", email: u.email || "", provider: u.provider, registered: { phone: !!(u.phone || "").trim(), email: !!(u.email || "").trim() } });
    }
    case "delete-user": {
      const u = await needUser(); if (!u) return json({ error: "not-found" }, 404);
      if (u.role === "admin") return json({ error: "مدیر را نمی‌توان حذف کرد؛ اول نقش را بردار." }, 400);
      await db.delete(tribeMembers).where(eq(tribeMembers.userId, userId));
      await db.delete(users).where(eq(users.id, userId));
      break;
    }
    case "notify-user": {
      const u = await needUser(); if (!u) return json({ error: "not-found" }, 404);
      const title = String(b.title || "🔔 پیام مدیر").slice(0, 120);
      const body = String(b.body || "").slice(0, 500);
      await db.insert(notifications).values({ id: uid("n"), userId, title, body, link: String(b.link || "").slice(0, 60), createdAt: now(), seen: 0 });
      publish([userId], "notice", { title, body, link: String(b.link || "") });
      break;
    }
    case "broadcast": {
      const title = String(b.title || "").trim().slice(0, 120);
      if (!title) return json({ error: "عنوان لازم است" }, 400);
      const row = {
        id: uid("bc"), title,
        body: String(b.body || "").slice(0, 600),
        image: String(b.image || "").slice(0, 2000),
        link: String(b.link || "").slice(0, 300),
        target: String(b.target || "all").slice(0, 80),
        active: true, createdBy: actor, createdAt: now(),
        expiresAt: Number(b.hours) > 0 ? now() + Number(b.hours) * 3600000 : 0,
      };
      await db.insert(broadcasts).values(row);
      // ارسال زنده
      const payload = { id: row.id, title: row.title, body: row.body, image: row.image, link: row.link, target: row.target };
      if (row.target.startsWith("user:")) publish([row.target.slice(5)], "broadcast", payload);
      else publish("*", "broadcast", payload);
      await audit(actor, "broadcast", row.id);
      return json({ ok: true, id: row.id });
    }
    case "delete-broadcast": {
      const id = String(b.id || "");
      await db.update(broadcasts).set({ active: false }).where(eq(broadcasts.id, id));
      publish("*", "broadcast:remove", { id });
      break;
    }
    case "publish-settings": {
      // تنظیمات بازی اصلی (siteTitle, tagline, logo, banners, hiddenSections, ...) + متن‌ها + دارایی‌ها
      const site = b.settings && typeof b.settings === "object" ? (b.settings as Record<string, unknown>) : null;
      if (site) {
        const prev = await getJsonSetting<Record<string, unknown>>("site-config", {});
        const next = { ...prev, ...site };
        if (JSON.stringify(next).length > 200000) return json({ error: "تنظیمات خیلی بزرگ است (لوگو را به‌صورت لینک بگذارید)." }, 400);
        await setSetting("site-config", JSON.stringify(next));
        if (typeof next.moderatePosts === "boolean") await setSetting("moderatePosts", String(next.moderatePosts));
        if (typeof next.moderateStories === "boolean") await setSetting("moderateStories", String(next.moderateStories));
      }
      if (b.textOverrides && typeof b.textOverrides === "object") await setSetting("text-overrides", JSON.stringify(b.textOverrides).slice(0, 100000));
      if (b.assetOverrides && typeof b.assetOverrides === "object") await setSetting("asset-overrides", JSON.stringify(b.assetOverrides).slice(0, 200000));
      publish("*", "config", { at: now() });
      await audit(actor, "publish-settings", "");
      break;
    }
    case "set-moderation": {
      if (typeof b.moderatePosts === "boolean") await setSetting("moderatePosts", String(b.moderatePosts));
      if (typeof b.moderateStories === "boolean") await setSetting("moderateStories", String(b.moderateStories));
      const site = await getJsonSetting<Record<string, unknown>>("site-config", {});
      await setSetting("site-config", JSON.stringify({ ...site, moderatePosts: (await getSetting("moderatePosts", "false")) === "true", moderateStories: (await getSetting("moderateStories", "false")) === "true" }));
      publish("*", "config", { at: now() });
      break;
    }
    case "set-category": {
      const id = String(b.id || "").slice(0, 40);
      if (!id) return json({ error: "bad-request" }, 400);
      const set: Record<string, unknown> = {};
      if (typeof b.name === "string") set.name = b.name.slice(0, 60);
      if (typeof b.icon === "string") set.icon = b.icon.slice(0, 2000);
      if (typeof b.color === "string") set.color = b.color.slice(0, 20);
      if (typeof b.subtitle === "string") set.subtitle = b.subtitle.slice(0, 120);
      if (typeof b.active === "boolean") set.active = b.active ? 1 : 0;
      const ex = (await db.select().from(categories).where(eq(categories.id, id)).limit(1))[0];
      if (ex) await db.update(categories).set(set).where(eq(categories.id, id));
      else await db.insert(categories).values({ id, name: String(set.name || id), subtitle: String(set.subtitle || ""), icon: String(set.icon || "globe"), color: String(set.color || "#a98cf7"), tag: "", safety: 0, active: 1 });
      publish("*", "config", { at: now() });
      break;
    }
    default:
      return json({ error: "unknown-action" }, 400);
  }
  await audit(actor, action, userId || String(b.id || ""));
  return json({ ok: true });
}
