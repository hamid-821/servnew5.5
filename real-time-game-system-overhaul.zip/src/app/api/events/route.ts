import { getSessionUser } from "@/lib/auth";
import { subscribe, type RtEvent } from "@/lib/realtime";
import { db } from "@/db";
import { sessions, users } from "@/db/schema";
import { and, eq, or } from "drizzle-orm";

/**
 * 📡 /api/events — جریان رویداد زنده (Server-Sent Events)
 * چرا SSE و نه WebSocket؟ `next start` بدون سرور سفارشی WebSocket را پشتیبانی نمی‌کند، اما SSE روی همان HTTP
 * و پشت Nginx (با proxy_buffering off) کاملاً پایدار است و برای ۱۰۰۰ اتصال هم‌زمان با یک پردازهٔ Node سبک است.
 * - احراز هویت: همان نشست/هدرهای بازی
 * - heartbeat هر ۲۰ ثانیه تا اتصال پشت proxy بسته نشود
 * - با بسته‌شدن تب، اشتراک آزاد می‌شود
 */
export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  let me = await getSessionUser();
  if (!me) {
    // EventSource نمی‌تواند هدر بفرستد؛ اگر کوکی بلاک باشد از توکن/شناسهٔ محلی در query استفاده می‌کنیم
    const url = new URL(req.url);
    const tok = url.searchParams.get("token") || "";
    const uidq = url.searchParams.get("uid") || "";
    if (tok) {
      const s = (await db.select().from(sessions).where(eq(sessions.token, tok)).limit(1))[0];
      if (s && s.expires > Date.now()) me = (await db.select().from(users).where(and(eq(users.id, s.userId), eq(users.banned, false))).limit(1))[0] || null;
    }
    if (!me && uidq) {
      me = (await db.select().from(users).where(and(or(eq(users.id, uidq), eq(users.localId, uidq)), eq(users.banned, false))).limit(1))[0] || null;
    }
    if (!me) return new Response("not-authed", { status: 401 });
  }
  const meId = me.id;
  db.update(users).set({ lastSeen: Date.now() }).where(eq(users.id, meId)).catch(() => { /* ignore */ });
  const enc = new TextEncoder();
  let unsub: (() => void) | null = null;
  let hb: ReturnType<typeof setInterval> | null = null;
  let closed = false;

  const stream = new ReadableStream({
    start(controller) {
      const send = (ev: RtEvent) => {
        if (closed) return;
        try {
          controller.enqueue(enc.encode(`event: ${ev.type}\ndata: ${JSON.stringify(ev.data)}\n\n`));
        } catch { /* stream closed */ }
      };
      controller.enqueue(enc.encode(`retry: 2000\nevent: hello\ndata: ${JSON.stringify({ me: meId, at: Date.now() })}\n\n`));
      unsub = subscribe(meId, send);
      hb = setInterval(() => {
        if (closed) return;
        try { controller.enqueue(enc.encode("event: ping\ndata: " + Date.now() + "\n\n")); } catch { /* ignore */ }
        db.update(users).set({ lastSeen: Date.now() }).where(eq(users.id, meId)).catch(() => { /* ignore */ });
      }, 20000);
      const cleanup = () => {
        if (closed) return;
        closed = true;
        if (hb) clearInterval(hb);
        if (unsub) unsub();
        try { controller.close(); } catch { /* ignore */ }
      };
      req.signal.addEventListener("abort", cleanup);
    },
    cancel() {
      closed = true;
      if (hb) clearInterval(hb);
      if (unsub) unsub();
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no", // Nginx: بدون بافر
    },
  });
}
