import { desc, eq, and, or, gt } from "drizzle-orm";
import { db } from "@/db";
import { broadcasts, categories } from "@/db/schema";
import { json } from "@/lib/auth";
import { ensureSeed } from "@/lib/ensure-seed";
import { getJsonSetting, getSetting } from "@/lib/admin";

/**
 * 🌐 /admin-config.json (rewrite → این مسیر)
 * بازی اصلی این فایل را هنگام شروع می‌خواند و روی تنظیمات محلی می‌نشاند.
 * حالا به‌جای فایل ثابت، از پایگاه‌داده می‌آید تا مدیر همه‌چیز را آنلاین عوض کند.
 */
export const dynamic = "force-dynamic";

export async function GET() {
  await ensureSeed();
  const site = await getJsonSetting<Record<string, unknown>>("site-config", {});
  const textOverrides = await getJsonSetting<Record<string, string>>("text-overrides", {});
  const assetOverrides = await getJsonSetting<Record<string, string>>("asset-overrides", {});
  const moderatePosts = (await getSetting("moderatePosts", "false")) === "true";
  const moderateStories = (await getSetting("moderateStories", "false")) === "true";
  const t = Date.now();
  let active: unknown[] = [];
  try {
    active = (await db.select().from(broadcasts)
      .where(and(eq(broadcasts.active, true), or(eq(broadcasts.expiresAt, 0), gt(broadcasts.expiresAt, t))))
      .orderBy(desc(broadcasts.createdAt)).limit(5))
      .map((b) => ({ id: b.id, title: b.title, body: b.body, image: b.image, link: b.link, target: b.target, at: b.createdAt }));
  } catch { active = []; }
  let cats: unknown[] = [];
  try { cats = await db.select().from(categories).where(eq(categories.active, 1)); } catch { cats = []; }
  return json({
    settings: { ...site, moderatePosts, moderateStories, autoAdmin: false },
    textOverrides, assetOverrides, broadcasts: active, categories: cats,
    serverNow: t,
  }, 200);
}
