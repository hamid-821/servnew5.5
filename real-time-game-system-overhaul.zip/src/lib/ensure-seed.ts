import { db } from "@/db";
import { eq, sql } from "drizzle-orm";
import { categories, organizations, questions, achievements, settings, tournaments } from "@/db/schema";
import { CATEGORIES, ORGS, QUESTIONS, ACHIEVEMENTS } from "./seed-data";
import { uid, now } from "./auth";
import { seedTribes } from "./seed-tribes";
import barq from "./barq-questions.json";

let seeded = false;
let barqDone = false;

type BarqItem = { id: string; category: string; topic: string; title: string; options: string[]; correct: number; explanation: string; source: string; status: string };

/** واردکردن بانک سؤال برق (idempotent؛ کلید = شناسهٔ پایدار hash) */
async function seedBarq() {
  if (barqDone) return;
  try {
    const stamp = (barq as { generatedAt: string }).generatedAt;
    const existing = await db.select({ value: settings.value }).from(settings).where(eq(settings.key, "barq-import")).limit(1);
    if (existing[0]?.value === stamp) { barqDone = true; return; }
    const items = (barq as { items: BarqItem[] }).items;
    const CHUNK = 100;
    for (let i = 0; i < items.length; i += CHUNK) {
      const rows = items.slice(i, i + CHUNK).map((q) => {
        const ok = q.status === "approved" && q.options.length === 4 && q.correct >= 0 && q.correct < 4;
        return {
          id: q.id, category: q.category, title: q.title, options: q.options, correct: ok ? q.correct : 0,
          explanation: q.explanation || "", source: `برق | ${q.topic ? q.topic + " | " : ""}${q.source}`,
          seconds: 25, kind: "text", media: "", status: ok ? "approved" : "review", author: "import-barq",
        };
      });
      await db.insert(questions).values(rows).onConflictDoUpdate({
        target: questions.id,
        set: { title: sql`excluded.title`, options: sql`excluded.options`, correct: sql`excluded.correct`, status: sql`excluded.status`, source: sql`excluded.source`, explanation: sql`excluded.explanation` },
      });
    }
    if (existing[0]) await db.update(settings).set({ value: stamp }).where(eq(settings.key, "barq-import"));
    else await db.insert(settings).values({ key: "barq-import", value: stamp });
    barqDone = true;
  } catch { /* بعداً تلاش می‌شود */ }
}

export async function ensureSeed() {
  if (seeded) return;
  try {
    const flag = await db.select().from(settings).limit(1).then(() => null).catch(() => "missing");
    if (flag === "missing") return; // جدول‌ها هنوز ساخته نشده‌اند
    const existing = await db.select({ key: settings.key }).from(settings);
    if (existing.some((s) => s.key === "seed-v1")) { await seedTribes(); await seedBarq(); seeded = true; return; }

    for (const c of CATEGORIES) {
      await db.insert(categories).values({ ...c }).onConflictDoNothing();
    }
    for (const o of ORGS) {
      await db.insert(organizations).values({ ...o, memberCount: 0, createdAt: now() }).onConflictDoNothing();
    }
    for (const q of QUESTIONS) {
      await db.insert(questions).values({ id: uid("q"), ...q, seconds: 25, kind: "text", media: "", status: "approved", author: "" }).onConflictDoNothing();
    }
    for (const a of ACHIEVEMENTS) {
      await db.insert(achievements).values(a).onConflictDoNothing();
    }
    // تورنمنت‌های پیش‌فرض: عمومی + ویژه برق
    const t = now(), day = 86400000;
    const defaults = [
      { id: "tour-public-weekly", title: "🏆 جام هفتگی گیمیفای", category: "general", startsAt: t - day, endsAt: t + 6 * day, description: "رقابت آزاد هفتگی برای همهٔ بازیکنان", orgId: "", tribeOnly: false, maxPlayers: 2000, active: true, createdBy: "system", createdAt: t },
      { id: "tour-barq-cup", title: "⚡ جام تخصصی برق", category: "electric", startsAt: t - day, endsAt: t + 13 * day, description: "ویژهٔ اعضای سازمان برق — به‌صورت خودکار برای اعضای برق باز است.", orgId: "barq", tribeOnly: false, maxPlayers: 1000, active: true, createdBy: "system", createdAt: t },
      { id: "tour-safety", title: "🦺 چالش ایمنی", category: "safety", startsAt: t - day, endsAt: t + 6 * day, description: "ویژهٔ فعالان ایمنی و HSE", orgId: "safety-org", tribeOnly: false, maxPlayers: 1000, active: true, createdBy: "system", createdAt: t },
      { id: "tour-tribe-wars", title: "⚔️ نبرد قبیله‌ها", category: "general", startsAt: t - day, endsAt: t + 30 * day, description: "ویژهٔ قبیله‌ها — امتیاز قبیله‌ات را بالا ببر!", orgId: "", tribeOnly: true, maxPlayers: 5000, active: true, createdBy: "system", createdAt: t },
    ];
    for (const d of defaults) {
      await db.insert(tournaments).values({ ...d, questions: [] }).onConflictDoNothing();
    }
    await db.insert(settings).values([
      { key: "seed-v1", value: JSON.stringify({ at: t }) },
      { key: "moderatePosts", value: "false" },
      { key: "moderateStories", value: "false" },
      { key: "autoApproveMinutes", value: "15" },
    ]).onConflictDoNothing();
    await seedTribes();
    await seedBarq();
    seeded = true;
  } catch { /* دیتابیس آماده نیست؛ بعداً تلاش می‌شود */ }
}
