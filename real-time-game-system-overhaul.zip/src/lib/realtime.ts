/**
 * 🔴 گذرگاه رویداد زنده (SSE)
 * - هر تب مرورگر یک اتصال EventSource به /api/events دارد
 * - رویدادها در حافظهٔ همین پردازه پخش می‌شوند و از طریق Postgres NOTIFY به پردازه‌های دیگر (PM2 cluster / چند instance) هم می‌رسند
 * - هدف: رساندن دعوت نبرد، پاسخ حریف، پست/استوری تازه، پیام چت و اعلان مدیر در کمتر از ۱ ثانیه
 */
import { pool } from "@/db";
import type { PoolClient } from "pg";

export type RtEvent = { type: string; data: unknown; at: number };
type Listener = (ev: RtEvent) => void;

type Bus = {
  byUser: Map<string, Set<Listener>>;
  all: Set<Listener>;
  listening: boolean;
  client: PoolClient | null;
  instance: string;
};

const g = globalThis as typeof globalThis & { __gamifyRtBus?: Bus };
const bus: Bus = g.__gamifyRtBus ?? {
  byUser: new Map(),
  all: new Set(),
  listening: false,
  client: null,
  instance: Math.random().toString(36).slice(2, 10),
};
g.__gamifyRtBus = bus;

const CHANNEL = "gamify_rt";

function deliverLocal(targets: string[] | "*", ev: RtEvent) {
  if (targets === "*") {
    bus.all.forEach((fn) => { try { fn(ev); } catch { /* ignore */ } });
    bus.byUser.forEach((set) => set.forEach((fn) => { try { fn(ev); } catch { /* ignore */ } }));
    return;
  }
  for (const id of targets) {
    const set = bus.byUser.get(id);
    if (set) set.forEach((fn) => { try { fn(ev); } catch { /* ignore */ } });
  }
}

/** اتصال LISTEN یک‌باره برای دریافت رویداد پردازه‌های دیگر */
async function ensureListening() {
  if (bus.listening) return;
  bus.listening = true;
  try {
    const client = await pool.connect();
    bus.client = client;
    client.on("notification", (msg) => {
      if (msg.channel !== CHANNEL || !msg.payload) return;
      try {
        const parsed = JSON.parse(msg.payload) as { from: string; targets: string[] | "*"; ev: RtEvent };
        if (parsed.from === bus.instance) return; // خودمان قبلاً محلی تحویل داده‌ایم
        deliverLocal(parsed.targets, parsed.ev);
      } catch { /* ignore */ }
    });
    client.on("error", () => { bus.listening = false; bus.client = null; });
    await client.query(`LISTEN ${CHANNEL}`);
  } catch {
    bus.listening = false;
    bus.client = null;
  }
}

/** انتشار رویداد برای کاربران مشخص یا همه ("*") */
export function publish(targets: string[] | "*", type: string, data: unknown) {
  const ev: RtEvent = { type, data, at: Date.now() };
  deliverLocal(targets, ev);
  // عبور از مرز پردازه (بدون انتظار؛ خطا نادیده گرفته می‌شود)
  const payload = JSON.stringify({ from: bus.instance, targets, ev });
  if (payload.length < 7000) {
    pool.query("SELECT pg_notify($1, $2)", [CHANNEL, payload]).catch(() => { /* ignore */ });
  }
}

/** اشتراک یک اتصال SSE؛ خروجی تابع لغو اشتراک است */
export function subscribe(userId: string, fn: Listener): () => void {
  void ensureListening();
  let set = bus.byUser.get(userId);
  if (!set) { set = new Set(); bus.byUser.set(userId, set); }
  set.add(fn);
  return () => {
    const s = bus.byUser.get(userId);
    if (!s) return;
    s.delete(fn);
    if (!s.size) bus.byUser.delete(userId);
  };
}

/** آیا کاربر هم‌اکنون اتصال زنده دارد؟ (برای نمایش آنلاین واقعی) */
export function isConnected(userId: string) {
  return (bus.byUser.get(userId)?.size ?? 0) > 0;
}

export function connectedIds(): string[] {
  return Array.from(bus.byUser.keys());
}

export function connectionCount(): number {
  let n = 0;
  bus.byUser.forEach((s) => { n += s.size; });
  return n;
}
