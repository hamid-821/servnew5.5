/**
 * 🛡️ احراز هویت مدیر — سمت سرور
 * دو راه معتبر:
 *  ۱) نشست کاربری با role = admin
 *  ۲) توکن مدیریتی امضاشده (HMAC) که با کد مدیریت (ADMIN_CODE در .env) گرفته می‌شود
 * هدر قدیمی x-local-admin دیگر پذیرفته نمی‌شود (حفرهٔ امنیتی بود).
 */
import { createHmac, timingSafeEqual } from "node:crypto";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { settings, users, type UserRow } from "@/db/schema";
import { getSessionUser } from "./auth";

const TOKEN_TTL = 12 * 60 * 60 * 1000; // ۱۲ ساعت

function secret() {
  return process.env.ADMIN_TOKEN_SECRET || process.env.ADMIN_CODE || "gamify-dev-secret";
}

export function adminCode() {
  // کد پیش‌فرض بازی اصلی «gamify» است؛ در سرور حتماً ADMIN_CODE را در .env تغییر بدهید
  return process.env.ADMIN_CODE || "gamify";
}

export function signAdminToken(name: string) {
  const exp = Date.now() + TOKEN_TTL;
  const base = `${encodeURIComponent(name.slice(0, 40))}.${exp}`;
  const sig = createHmac("sha256", secret()).update(base).digest("base64url");
  return `${base}.${sig}`;
}

export function verifyAdminToken(tok: string): { name: string } | null {
  try {
    const parts = tok.split(".");
    if (parts.length !== 3) return null;
    const [name, expStr, sig] = parts;
    if (Number(expStr) < Date.now()) return null;
    const expect = createHmac("sha256", secret()).update(`${name}.${expStr}`).digest("base64url");
    const a = Buffer.from(sig), b = Buffer.from(expect);
    if (a.length !== b.length || !timingSafeEqual(a, b)) return null;
    return { name: decodeURIComponent(name) };
  } catch {
    return null;
  }
}

export function safeEqual(a: string, b: string) {
  const x = Buffer.from(a), y = Buffer.from(b);
  return x.length === y.length && timingSafeEqual(x, y);
}

export type AdminCtx = { me: UserRow | null; name: string; via: "session" | "token" };

/** مدیر معتبر را برمی‌گرداند یا null */
export async function requireAdmin(req: Request): Promise<AdminCtx | null> {
  const me = await getSessionUser();
  if (me && me.role === "admin") return { me, name: me.name, via: "session" };
  const tok = req.headers.get("x-admin-token") || "";
  if (tok) {
    const v = verifyAdminToken(tok);
    if (v) return { me, name: v.name || me?.name || "مدیر", via: "token" };
  }
  return null;
}

// ---------- تنظیمات کلید-مقدار ----------
export async function getSetting(key: string, fallback = ""): Promise<string> {
  try {
    const row = await db.select().from(settings).where(eq(settings.key, key)).limit(1);
    return row[0]?.value ?? fallback;
  } catch {
    return fallback;
  }
}

export async function setSetting(key: string, value: string) {
  const existing = await db.select({ key: settings.key }).from(settings).where(eq(settings.key, key)).limit(1);
  if (existing[0]) await db.update(settings).set({ value }).where(eq(settings.key, key));
  else await db.insert(settings).values({ key, value });
}

export async function getJsonSetting<T>(key: string, fallback: T): Promise<T> {
  const raw = await getSetting(key, "");
  if (!raw) return fallback;
  try { return JSON.parse(raw) as T; } catch { return fallback; }
}

/** آیا پست‌ها/استوری‌ها نیاز به تأیید مدیر دارند؟ (پیش‌فرض: خیر — انتشار فوری) */
export async function moderationFlags() {
  const posts = (await getSetting("moderatePosts", "false")) === "true";
  const stories = (await getSetting("moderateStories", "false")) === "true";
  return { moderatePosts: posts, moderateStories: stories };
}

/** ماسک‌کردن شماره/ایمیل برای جدول عمومی مدیر */
export function maskPhone(p: string) {
  if (!p) return "";
  const d = p.replace(/\D/g, "");
  if (d.length < 6) return "•••";
  return d.slice(0, 4) + "•••" + d.slice(-3);
}
export function maskEmail(e: string) {
  if (!e || !e.includes("@")) return e ? "•••" : "";
  const [u, d] = e.split("@");
  return (u.slice(0, 2) || "•") + "•••@" + d;
}

export async function findUser(id: string) {
  return (await db.select().from(users).where(eq(users.id, id)).limit(1))[0];
}
