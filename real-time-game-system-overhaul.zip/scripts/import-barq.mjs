#!/usr/bin/env node
/**
 * استخراج بانک سؤال برق از فایل‌های Excel/Word (برق.zip) → src/lib/barq-questions.json
 * اجرا:  node scripts/import-barq.mjs "<مسیر پوشهٔ استخراج‌شدهٔ برق>"
 * - Excel: ستون option1 پاسخ صحیح است (طبق اعلام کارفرما) → گزینه‌ها به‌صورت قطعی (hash) جابه‌جا می‌شوند تا همه «گزینهٔ ۱» نباشند
 * - Word: فقط سؤال‌هایی که پاسخ صحیح با علامت ☑ / √ / ✓ مشخص شده «تأییدشده» هستند؛ بقیه status=review (در بازی استفاده نمی‌شوند)
 * - .doc قدیمی (باینری) پردازش نمی‌شود و گزارش می‌شود
 * - شناسهٔ پایدار: barq-<sha1(متن نرمال‌شده)> → اجرای مجدد تکراری نمی‌سازد
 */
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import XLSX from "xlsx";
import mammoth from "mammoth";

const root = process.argv[2];
if (!root || !fs.existsSync(root)) { console.error("مسیر پوشهٔ برق را بده"); process.exit(1); }
const out = path.join(process.cwd(), "src/lib/barq-questions.json");

const walk = (d) => fs.readdirSync(d, { withFileTypes: true }).flatMap((e) => e.isDirectory() ? walk(path.join(d, e.name)) : [path.join(d, e.name)]);
const norm = (s) => String(s || "").replace(/[\u200c\u200f\u202a-\u202e]/g, " ").replace(/[يى]/g, "ی").replace(/ك/g, "ک").replace(/\s+/g, " ").replace(/^\s*\d+\s*[-–.)]\s*/, "").trim();
const sha = (s) => crypto.createHash("sha1").update(s).digest("hex").slice(0, 16);
const catOf = (rel) => /ایمنی/.test(rel) ? "safety" : "electric";

const items = [], report = { files: [], skipped: [], duplicates: 0, incomplete: 0, review: 0, verified: 0 };
const seen = new Map();

function push(q) {
  const title = norm(q.title);
  const options = q.options.map(norm).filter(Boolean);
  if (title.length < 6 || options.length < 2) { report.incomplete++; return; }
  const key = sha(title + "|" + options.slice().sort().join("|"));
  if (seen.has(key)) { report.duplicates++; const first = seen.get(key); if (first.status === "review" && q.status === "approved") { Object.assign(first, { options, correct: q.correct, status: "approved", source: first.source + " ; " + q.source }); report.review--; report.verified++; } return; }
  // جابه‌جایی قطعی گزینه‌ها بر اساس hash تا پاسخ صحیح در جایگاه‌های مختلف پخش شود
  let correct = q.correct;
  if (q.status === "approved" && correct >= 0) {
    const h = parseInt(key.slice(0, 4), 16);
    const rot = h % options.length;
    const rotated = options.map((_, i) => options[(i + rot) % options.length]);
    correct = (correct - rot + options.length) % options.length;
    q = { ...q, options: rotated, correct };
    seen.set(key, q);
    report.verified++;
  } else { q = { ...q, options, correct: -1, status: "review" }; seen.set(key, q); report.review++; }
  items.push({ id: "barq-" + key, category: catOf(q.source), topic: q.topic || "", title, options: q.options, correct: q.correct, explanation: q.explanation || "", source: q.source, status: q.status, points: q.points || 1 });
}

for (const f of walk(root)) {
  const rel = path.relative(root, f).replace(/\\/g, "/");
  const base = path.basename(f);
  if (base.startsWith("~$")) continue;
  if (/\.xlsx?$/.test(f)) {
    const wb = XLSX.readFile(f); let n = 0;
    for (const sn of wb.SheetNames) {
      const rows = XLSX.utils.sheet_to_json(wb.Sheets[sn], { header: 1, defval: "" });
      if (!rows.length) continue;
      const hdr = rows[0].map((h) => String(h).trim());
      const ix = (name) => hdr.indexOf(name);
      if (ix("question_text") < 0) continue;
      rows.slice(1).forEach((r, i) => {
        const title = r[ix("question_text")];
        if (!String(title).trim()) return;
        const opts = [r[ix("option1")], r[ix("option2")], r[ix("option3")], r[ix("option4")]].map((x) => String(x ?? ""));
        const correct = opts.filter(Boolean).length ? 0 : -1; // option1 = پاسخ صحیح (اعلام کارفرما)
        push({ title, options: opts, correct, status: correct >= 0 ? "approved" : "review", topic: String(r[ix("question_category")] || ""), points: Number(r[ix("question_point")]) || 1, explanation: String(r[ix("correct_msg")] || ""), source: `${rel}#${sn}:row${i + 2}` });
        n++;
      });
    }
    report.files.push({ file: rel, type: "excel", questions: n });
  } else if (/\.docx$/.test(f)) {
    const txt = (await mammoth.extractRawText({ path: f })).value;
    const lines = txt.split(/\r?\n/).map((s) => s.replace(/\t/g, "  ").trim()).filter(Boolean);
    const MARK = /[☑√✓■●]/;
    const OPT = /(?:^|\s{2,}|\t)(?:\(?(?:الف|ب|ج|د)\s*[-–:)]\s*)/g;
    const isOptLine = (l) => /^\(?(?:الف|ب|ج|د)\s*[-–:)]/.test(l);
    let cur = null, n = 0;
    const flush = () => {
      if (!cur) return;
      const opts = cur.opts.map((o) => o.replace(/[□☐]/g, "").trim());
      const correct = cur.opts.findIndex((o) => MARK.test(o));
      push({ title: cur.title, options: opts.map((o) => o.replace(MARK, "").trim()), correct: correct >= 0 ? correct : -1, status: correct >= 0 ? "approved" : "review", topic: cur.topic, source: `${rel}#line${cur.line}` });
      n++; cur = null;
    };
    const topic = lines[0] && lines[0].length < 80 ? lines[0] : "";
    lines.forEach((l, li) => {
      if (/^(بسمه تعالی|تعداد سوال|نمونه سوالات|سوالات )/.test(l) && !/\?|؟/.test(l)) return;
      if (isOptLine(l)) {
        if (!cur) return;
        // چند گزینه در یک خط
        const parts = l.split(/(?=(?:^|\s)\(?(?:الف|ب|ج|د)\s*[-–:)])/).map((s) => s.trim()).filter((s) => isOptLine(s));
        parts.forEach((p) => cur.opts.push(p.replace(/^\(?(?:الف|ب|ج|د)\s*[-–:)]\s*/, "")));
      } else {
        if (cur && cur.opts.length >= 2) flush();
        if (cur && cur.opts.length < 2 && cur.opts.length > 0) { cur = null; report.incomplete++; }
        cur = { title: l, opts: [], line: li + 1, topic };
      }
    });
    flush();
    report.files.push({ file: rel, type: "docx", questions: n });
  } else if (/\.doc$/.test(f)) {
    report.skipped.push({ file: rel, reason: "فرمت .doc باینری قدیمی؛ به .docx تبدیل و دوباره import شود" });
  } else report.skipped.push({ file: rel, reason: "فرمت پشتیبانی‌نشده" });
}

fs.writeFileSync(out, JSON.stringify({ generatedAt: new Date().toISOString(), report, items }, null, 0));
const byStatus = items.reduce((a, q) => { a[q.status] = (a[q.status] || 0) + 1; return a; }, {});
const dist = items.filter((q) => q.status === "approved").reduce((a, q) => { a[q.correct] = (a[q.correct] || 0) + 1; return a; }, {});
console.log(JSON.stringify({ total: items.length, byStatus, correctDistribution: dist, duplicates: report.duplicates, incomplete: report.incomplete, skipped: report.skipped.length, files: report.files }, null, 1));
