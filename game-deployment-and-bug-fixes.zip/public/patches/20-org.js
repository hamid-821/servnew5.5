/* 🏢 انتخاب سازمان هنگام ثبت‌نام (مثلاً صنعت برق) + بازگشایی خودکار تورنمنت‌ها */
(function () {
  "use strict";
  if (window.__gamifyOrg) return;
  window.__gamifyOrg = true;

  var LS_KEY = "gamify2-store-v2";
  var META_KEY = "gamify2-server";
  var orgsCache = null;
  var selectedOrg = "";
  try { selectedOrg = (JSON.parse(localStorage.getItem(META_KEY) || "{}").orgId) || ""; } catch (e) {}

  function readStore() { try { return JSON.parse(localStorage.getItem(LS_KEY) || "null"); } catch (e) { return null; } }
  function readMeta() { try { return JSON.parse(localStorage.getItem(META_KEY) || "{}"); } catch (e) { return {}; } }
  function writeMeta(m) { try { localStorage.setItem(META_KEY, JSON.stringify(m)); } catch (e) {} }

  function fetchOrgs() {
    if (orgsCache) return Promise.resolve(orgsCache);
    return fetch("/api/orgs", { credentials: "include" }).then(function (r) { return r.json(); }).then(function (rows) {
      if (Array.isArray(rows) && rows.length) orgsCache = rows;
      else orgsCache = [
        { id: "barq", name: "⚡ صنعت برق", description: "ویژهٔ کارکنان صنعت برق" },
        { id: "free", name: "🌍 آزاد", description: "بازی آزاد برای همه" }
      ];
      return orgsCache;
    }).catch(function () {
      orgsCache = [
        { id: "barq", name: "⚡ صنعت برق", description: "ویژهٔ کارکنان صنعت برق" },
        { id: "free", name: "🌍 آزاد", description: "بازی آزاد برای همه" }
      ];
      return orgsCache;
    });
  }

  function toast(msg) {
    try {
      var d = document.createElement("div");
      d.textContent = msg;
      d.style.cssText = "position:fixed;bottom:86px;right:16px;z-index:99999;background:#241a33;color:#fff;padding:10px 16px;border-radius:14px;font-size:13px;box-shadow:0 8px 30px rgba(0,0,0,.4);border:1px solid #f8c56c;font-family:Vazirmatn,sans-serif;max-width:min(92vw,380px);";
      document.body.appendChild(d);
      setTimeout(function () { d.style.transition = "opacity .4s"; d.style.opacity = "0"; setTimeout(function(){ d.remove(); }, 450); }, 3200);
    } catch (e) {}
  }

  // ---- تزریق انتخاب سازمان در مودال ثبت‌نام ----
  function injectOrgField(container) {
    if (!container || container.querySelector("[data-gamify-org]")) return;
    fetchOrgs().then(function (orgs) {
      if (container.querySelector("[data-gamify-org]")) return;
      var wrap = document.createElement("div");
      wrap.setAttribute("data-gamify-org", "1");
      wrap.style.cssText = "margin:12px 0;padding:12px;border-radius:14px;background:rgba(248,197,108,.08);border:1px dashed rgba(248,197,108,.5);";
      var label = document.createElement("label");
      label.style.cssText = "display:block;font-size:13px;font-weight:700;margin-bottom:8px;color:inherit;";
      label.textContent = "🏢 عضو سازمانی هستی؟ (مثلاً صنعت برق)";
      var sel = document.createElement("select");
      sel.setAttribute("data-gamify-org-select", "1");
      sel.style.cssText = "width:100%;padding:10px 12px;border-radius:10px;background:#17111f;color:#fff;border:1px solid rgba(255,255,255,.2);font-family:inherit;font-size:14px;";
      var opts = [{ id: "", name: "— عضو سازمانی نیستم / آزاد —" }].concat(orgs);
      opts.forEach(function (o) {
        var op = document.createElement("option");
        op.value = o.id; op.textContent = o.name;
        if (selectedOrg === o.id) op.selected = true;
        sel.appendChild(op);
      });
      var hint = document.createElement("div");
      hint.style.cssText = "font-size:11px;opacity:.75;margin-top:6px;line-height:1.8;";
      hint.textContent = "اگر عضو برق یا سازمان دیگری هستی انتخاب کن تا تورنمنت‌های ویژه‌اش خودکار برایت باز شود. ⚡";
      sel.addEventListener("change", function () {
        selectedOrg = sel.value;
        var m = readMeta(); m.orgId = selectedOrg; writeMeta(m);
        // اگر پروفایل از قبل ساخته شده، همان لحظه به سرور بفرست
        try {
          var st = readStore();
          if (st && st.profile) {
            st.profile.org = selectedOrg;
            localStorage.setItem(LS_KEY, JSON.stringify(st));
            if (window.__gamifyServer) window.__gamifyServer.syncNow();
            if (selectedOrg) {
              fetch("/api/orgs", { method: "POST", headers: { "Content-Type": "application/json" }, credentials: "include", body: JSON.stringify({ orgId: selectedOrg }) })
                .then(function (r) { return r.json(); }).then(function (j) { if (j && j.message) toast(j.message); }).catch(function(){});
            }
          }
        } catch (e) {}
        updateHint();
      });
      function updateHint() {
        var o = orgs.filter(function (x) { return x.id === selectedOrg; })[0];
        hint.textContent = o && o.description ? ("✅ " + o.description) : "اگر عضو برق یا سازمان دیگری هستی انتخاب کن تا تورنمنت‌های ویژه‌اش خودکار برایت باز شود. ⚡";
      }
      updateHint();
      wrap.appendChild(label); wrap.appendChild(sel); wrap.appendChild(hint);
      // درج در بهترین نقطه: قبل از دکمهٔ ثبت/ادامه
      var btns = Array.from(container.querySelectorAll("button")).filter(function (x) { return /ثبت|ادامه|ورود|شروع|تأیید|ذخیره/.test(x.textContent || ""); });
      if (btns.length) btns[0].parentElement.insertBefore(wrap, btns[0]);
      else container.appendChild(wrap);
    });
  }

  // رصد مودال‌های ثبت‌نام
  var modalObserver = null;
  function scanForRegister() {
    try {
      // هر دیالوگ/مودالی که متن ثبت‌نام/علاقه‌مندی دارد
      var candidates = Array.from(document.querySelectorAll('[role="dialog"], dialog, div[class*="modal"], div[class*="Modal"]'));
      // اگر چیزی پیدا نشد، کل بادی را برای متن خاص بگرد (باندل ممکن است مودال سفارشی داشته باشد)
      if (!candidates.length) {
        var all = document.body ? document.body.innerText || "" : "";
        if (/به چه چیزهایی علاقه داری/.test(all)) {
          // پیدا کردن نزدیک‌ترین کانتینر
          var els = Array.from(document.querySelectorAll("div")).filter(function (el) {
            return (el.textContent || "").indexOf("به چه چیزهایی علاقه داری") !== -1 && el.querySelectorAll("button").length >= 2;
          });
          if (els.length) {
            // کوچک‌ترین کانتینر
            els.sort(function (a, b) { return (a.innerHTML.length - b.innerHTML.length); });
            injectOrgField(els[0]);
          }
        }
        return;
      }
      candidates.forEach(function (c) {
        var t = c.innerText || "";
        if (/ورود \/ ثبت‌نام|به چه چیزهایی علاقه داری|آواتارت را بساز/.test(t)) injectOrgField(c);
      });
    } catch (e) {}
  }

  // وقتی پروفایل ساخته شد، org انتخاب‌شده را به آن بچسبان
  function stickOrgToProfile() {
    try {
      var m = readMeta();
      var org = selectedOrg || m.orgId;
      if (!org) return;
      var st = readStore();
      if (st && st.profile && !st.profile.org) {
        st.profile.org = org;
        localStorage.setItem(LS_KEY, JSON.stringify(st));
        if (window.__gamifyServer) window.__gamifyServer.syncNow();
      }
    } catch (e) {}
  }

  // ---- بنر تورنمنت ویژهٔ سازمان در صفحهٔ رویدادها ----
  var lastEventsBanner = 0;
  function eventsBanner() {
    try {
      if ((location.hash || "") .indexOf("#events") !== 0 && (location.hash || "").indexOf("#leagues") !== 0) return;
      if (Date.now() - lastEventsBanner < 10000) return;
      var st = readStore();
      var org = (st && st.profile && st.profile.org) || readMeta().orgId;
      if (!org) return;
      lastEventsBanner = Date.now();
      fetch("/api/tournaments", { credentials: "include" }).then(function (r) { return r.json(); }).then(function (rows) {
        if (!Array.isArray(rows)) return;
        var mine = rows.filter(function (t) { return t.orgId === org && t.open && !t.orgLocked; });
        if (!mine.length) return;
        // اگر بنر از قبل هست، رد کن
        if (document.querySelector("[data-gamify-org-banner]")) return;
        var root = document.getElementById("root");
        if (!root) return;
        var banner = document.createElement("div");
        banner.setAttribute("data-gamify-org-banner", "1");
        banner.style.cssText = "margin:12px;padding:14px 16px;border-radius:16px;background:linear-gradient(135deg,rgba(248,197,108,.16),rgba(169,140,247,.12));border:1px solid rgba(248,197,108,.45);font-family:Vazirmatn,sans-serif;";
        banner.innerHTML = "<div style='font-weight:800;margin-bottom:6px;'>🏢 تورنمنت ویژهٔ سازمان شما باز است!</div>" +
          mine.slice(0, 3).map(function (t) { return "<div style='font-size:13px;opacity:.9;'>⚡ " + String(t.title).replace(/</g, "&lt;") + "</div>"; }).join("") +
          "<div style='font-size:12px;opacity:.75;margin-top:6px;'>از بخش «🛡️ قبیله‌ها ← تورنمنت‌ها» وارد شو و رقابت کن.</div>";
        var first = root.firstElementChild;
        if (first) first.insertBefore(banner, first.firstChild);
        else root.appendChild(banner);
        setTimeout(function () { try { banner.remove(); } catch (e) {} }, 20000);
      }).catch(function(){});
    } catch (e) {}
  }

  // ---- دکمهٔ شناور «سازمان من» ----
  function mountOrgFab() {
    if (document.getElementById("gamify-org-fab")) return;
    var b = document.createElement("button");
    b.id = "gamify-org-fab";
    b.textContent = "🏢";
    b.title = "سازمان من";
    b.style.cssText = "position:fixed;left:14px;bottom:150px;z-index:99990;width:46px;height:46px;border-radius:50%;background:#241a33;border:1px solid #f8c56c;font-size:20px;cursor:pointer;box-shadow:0 8px 24px rgba(0,0,0,.4);";
    b.addEventListener("click", openOrgModal);
    document.body.appendChild(b);
  }

  function openOrgModal() {
    if (window.__gamifyFeatureOn && !window.__gamifyFeatureOn("org")) return;
    var signed = false;
    try { signed = !!(window.__gamifySession && window.__gamifySession.isLoggedIn()); } catch (e) {}
    if (!signed) {
      try { signed = !!(window.__gamifyLiveGet && window.__gamifyLiveGet().profile); } catch (e) {}
    }
    if (!signed) {
      try { var st0 = readStore(); signed = !!(st0 && st0.profile); } catch (e) {}
    }
    if (!signed) { toast("🌱 اول از دکمهٔ ورود بالای صفحه وارد بازی شو"); return; }
    fetchOrgs().then(function (orgs) {
      var overlay = document.createElement("div");
      overlay.style.cssText = "position:fixed;inset:0;z-index:99995;background:rgba(10,6,16,.72);display:grid;place-items:center;padding:16px;font-family:Vazirmatn,sans-serif;";
      overlay.innerHTML = "<div style='width:min(480px,94vw);max-height:86vh;overflow:auto;background:#1d1527;border:1px solid rgba(248,197,108,.4);border-radius:20px;padding:20px;'>" +
        "<div style='display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;'><b style='font-size:17px;'>🏢 سازمان من</b><button data-close style='background:none;border:none;color:#fff;font-size:20px;cursor:pointer;'>✕</button></div>" +
        "<p style='font-size:13px;opacity:.8;line-height:2;margin-bottom:12px;'>اگر عضو سازمانی (مثلاً صنعت برق) هستی انتخاب کن تا تورنمنت‌ها و لیگ‌های ویژه‌اش خودکار برایت باز شود.</p>" +
        "<div data-list style='display:grid;gap:10px;'></div></div>";
      var list = overlay.querySelector("[data-list]");
      [{ id: "", name: "🌍 آزاد (بدون سازمان)", description: "بازی آزاد برای همه", members: 0 }].concat(orgs).forEach(function (o) {
        var item = document.createElement("button");
        var active = (selectedOrg || readMeta().orgId || "") === o.id;
        item.style.cssText = "text-align:right;padding:12px 14px;border-radius:14px;cursor:pointer;background:" + (active ? "rgba(248,197,108,.16)" : "rgba(255,255,255,.04)") + ";border:1px solid " + (active ? "#f8c56c" : "rgba(255,255,255,.12)") + ";color:#fff;font-family:inherit;";
        item.innerHTML = "<div style='font-weight:800;'>" + String(o.name).replace(/</g, "&lt;") + (active ? " ✅" : "") + "</div>" +
          "<div style='font-size:12px;opacity:.75;margin-top:4px;'>" + String(o.description || "").replace(/</g, "&lt;") + (o.members ? " · 👥 " + o.members + " عضو" : "") + "</div>";
        item.addEventListener("click", function () {
          selectedOrg = o.id;
          var m = readMeta(); m.orgId = o.id; writeMeta(m);
          try {
            var st = readStore();
            if ((!st || !st.profile) && window.__gamifyLiveGet) st = window.__gamifyLiveGet();
            if (st && st.profile) {
              st.profile.org = o.id;
              if (window.__gamifyLiveSet) window.__gamifyLiveSet(function () { return st; });
              else localStorage.setItem(LS_KEY, JSON.stringify(st));
            }
          } catch (e) {}
          var ready = window.__gamifyServer && window.__gamifyServer.ensureSynced ? window.__gamifyServer.ensureSynced() : Promise.resolve();
          ready.then(function () {
            if (!o.id) { toast("✅ حالت آزاد انتخاب شد"); overlay.remove(); return; }
            return fetch("/api/orgs", { method: "POST", headers: { "Content-Type": "application/json" }, credentials: "include", body: JSON.stringify({ orgId: o.id }) })
              .then(function (r) { return r.json(); }).then(function (j) {
                if (j && j.error === "not-authed" && window.__gamifyServer && window.__gamifyServer.syncNow) {
                  return window.__gamifyServer.syncNow().then(function () {
                    return fetch("/api/orgs", { method: "POST", headers: { "Content-Type": "application/json" }, credentials: "include", body: JSON.stringify({ orgId: o.id }) }).then(function (r2) { return r2.json(); });
                  });
                }
                return j;
              }).then(function (j) {
                if (j && j.ok) toast(j.message || "✅ ثبت شد");
                else if (j && j.error === "not-authed") toast("سازمان روی حسابت ذخیره شد و با وصل شدن سرور ثبت می‌شود");
                else toast((j && (j.message || j.error)) || "✅ ثبت شد");
                overlay.remove();
              });
          }).catch(function () { toast("سازمان روی دستگاهت ذخیره شد"); overlay.remove(); });
        });
        list.appendChild(item);
      });
      overlay.querySelector("[data-close]").addEventListener("click", function () { overlay.remove(); });
      overlay.addEventListener("click", function (e) { if (e.target === overlay) overlay.remove(); });
      document.body.appendChild(overlay);
    });
  }

  window.__gamifyOrgOpen = openOrgModal;

  function boot() {
    fetchOrgs().catch(function(){});
    try {
      modalObserver = new MutationObserver(function () { scanForRegister(); });
      modalObserver.observe(document.documentElement, { childList: true, subtree: true });
    } catch (e) {}
    setInterval(scanForRegister, 2500);
    setInterval(stickOrgToProfile, 3000);
    setInterval(eventsBanner, 4000);
    window.addEventListener("hashchange", function () { setTimeout(eventsBanner, 800); });
    // دکمه شناور با تأخیر (تا با رابط اصلی تداخل نکند)
    setTimeout(mountOrgFab, 4000);
    // اگر کاربر قدیمی بدون سازمان است، یک‌بار یادآوری کن
    setTimeout(function () {
      try {
        var st = readStore();
        var m = readMeta();
        if (st && st.profile && !st.profile.org && !m.orgId && !m.orgAsked) {
          m.orgAsked = 1; writeMeta(m);
          toast("🏢 عضو سازمانی هستی؟ (مثل برق) — دکمهٔ 🏢 پایین صفحه را بزن!");
        }
      } catch (e) {}
    }, 12000);
    console.log("%c[gamify] org فعال شد ✅", "color:#f8c56c");
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();
})();
