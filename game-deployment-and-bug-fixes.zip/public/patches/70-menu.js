/* منوی راست: قبیله‌ها، سازمان من، مرکز پاداش، جوایز روزانه
   نمایش هر کدام با تیک پنل مدیریت خاموش/روشن می‌شود. مدیر همیشه همه را می‌بیند. */
(function () {
  "use strict";
  if (window.__gamifyMenu) return;
  window.__gamifyMenu = true;

  var ITEMS = [
    { id: "tribes", label: "قبیله‌ها", hash: "#tribes", icon: "🛡️" },
    { id: "org", label: "سازمان من", hash: "#myorg", icon: "🏢" },
    { id: "arena", label: "مرکز پاداش", hash: "#arena", icon: "🎡" },
    { id: "daily", label: "جوایز روزانه", hash: "#daily", icon: "🎁" }
  ];
  var FABS = { tribes: "gamify-tribes-fab", org: "gamify-org-fab", arena: "gamify-arena-fab", daily: "gamify-gift-fab" };
  var flags = { tribes: true, org: true, arena: true, daily: true };
  var saveTimer = null;

  function isAdmin() {
    try {
      var st = window.__gamifyLiveGet ? window.__gamifyLiveGet() : null;
      if (!st) st = JSON.parse(localStorage.getItem("gamify2-store-v2") || "null");
      return !!(st && (st.admin === true || (st.profile && st.profile.role === "admin")));
    } catch (e) { return false; }
  }
  function visible(id) { return isAdmin() || flags[id] !== false; }
  window.__gamifyFeatureOn = function (id) { return visible(id); };
  window.__gamifyIsAdmin = isAdmin;

  function toast(msg) {
    if (window.__gamifyToast) window.__gamifyToast(msg);
  }
  function closeDrawer() {
    var btn = document.querySelector('button[aria-label="بستن منو"]');
    if (btn) btn.click();
  }
  function openItem(item) {
    if (!visible(item.id)) { toast("این بخش توسط مدیر غیرفعال شده است."); return; }
    if (item.id === "org" && window.__gamifyOrgOpen) { window.__gamifyOrgOpen(); closeDrawer(); return; }
    if (item.id === "arena" && window.__gamifyArenaOpen) { window.__gamifyArenaOpen(); closeDrawer(); return; }
    if (item.id === "daily" && window.__gamifyDailyOpen) { window.__gamifyDailyOpen(); closeDrawer(); return; }
    if (location.hash !== item.hash) location.hash = item.hash;
    else window.dispatchEvent(new HashChangeEvent("hashchange"));
    closeDrawer();
  }

  function navAnchor() {
    var buttons = Array.from(document.querySelectorAll("button.gm-nav-item")).filter(function (b) {
      return !b.getAttribute("data-gamify-nav");
    });
    return buttons.filter(function (b) { return /لیگ‌ها/.test(b.textContent || ""); })[0]
      || buttons.filter(function (b) { return /صفحه‌های سازمانی/.test(b.textContent || ""); })[0]
      || buttons[buttons.length - 1]
      || null;
  }
  function syncNav() {
    var anchor = navAnchor();
    if (!anchor || !anchor.parentElement) return;
    var after = anchor;
    ITEMS.forEach(function (item) {
      var existing = document.querySelector('button[data-gamify-nav="' + item.id + '"]');
      if (!visible(item.id)) { if (existing) existing.remove(); return; }
      var active = (location.hash || "").indexOf(item.hash) === 0;
      if (!existing) {
        existing = anchor.cloneNode(true);
        existing.setAttribute("data-gamify-nav", item.id);
        existing.setAttribute("type", "button");
        var label = existing.querySelector("span");
        if (label) label.textContent = item.label;
        else existing.textContent = item.icon + " " + item.label;
        existing.addEventListener("click", function (e) {
          e.preventDefault();
          e.stopPropagation();
          openItem(item);
        });
        after.parentElement.insertBefore(existing, after.nextSibling);
      }
      after = existing;
      existing.setAttribute("data-active", active ? "true" : "false");
      existing.style.opacity = isAdmin() && flags[item.id] === false ? "0.55" : "";
      existing.title = isAdmin() && flags[item.id] === false ? "برای کاربران مخفی است" : item.label;
    });
  }
  function syncFabs() {
    Object.keys(FABS).forEach(function (id) {
      var el = document.getElementById(FABS[id]);
      if (!el) return;
      el.style.display = visible(id) ? "" : "none";
    });
    var hideOrg = !visible("org");
    Array.from(document.querySelectorAll("button")).forEach(function (b) {
      if (b.getAttribute("data-gamify-nav")) return;
      if ((b.textContent || "").trim() === "سازمان من") b.style.display = hideOrg ? "none" : "";
    });
  }
  function toggleHtml() {
    return '<div data-gamify-feature-toggles style="margin-top:12px;padding-top:10px;border-top:1px dashed rgba(242,202,124,.35)">' +
      '<p style="margin:0 0 8px;font-size:11px;line-height:1.8;opacity:.8">تیک را بردار تا این بخش از منوی راست کاربران غیب شود. خودِ مدیر همیشه می‌بیند.</p>' +
      '<div style="display:grid;gap:6px;grid-template-columns:1fr 1fr">' +
      ITEMS.map(function (item) {
        return '<label style="display:flex;align-items:center;gap:8px;background:#221a2d;border-radius:10px;padding:8px 10px;font-size:12px;cursor:pointer">' +
          '<input type="checkbox" data-feature-flag="' + item.id + '"' + (flags[item.id] !== false ? " checked" : "") + '> ' +
          item.icon + " " + item.label + "</label>";
      }).join("") + "</div></div>";
  }
  function bindToggles(root) {
    root.querySelectorAll("[data-feature-flag]").forEach(function (input) {
      input.addEventListener("change", function () {
        flags[input.getAttribute("data-feature-flag")] = input.checked;
        scheduleSave();
        syncNav();
        syncFabs();
      });
    });
  }
  function injectAdmin() {
    if (!isAdmin()) return;
    var heads = Array.from(document.querySelectorAll("h3")).filter(function (el) {
      return (el.textContent || "").indexOf("نمایش بخش‌ها به کاربران") !== -1;
    });
    heads.forEach(function (h) {
      var card = h.closest("section") || h.parentElement;
      if (!card || card.querySelector("[data-gamify-feature-toggles]")) return;
      var box = document.createElement("div");
      box.innerHTML = toggleHtml();
      var node = box.firstChild;
      card.appendChild(node);
      bindToggles(node);
    });
    var live = document.querySelector("#gamify-mod-overlay .gamify-body, #gamify-mod-overlay");
    if (live && !live.querySelector("[data-gamify-feature-toggles]")) {
      var holder = document.createElement("div");
      holder.innerHTML = '<div class="gamify-mod-card">' + toggleHtml() + "</div>";
      var node2 = holder.firstChild;
      var body = live.querySelector(".gamify-body") || live;
      body.insertBefore(node2, body.firstChild);
      bindToggles(node2);
    }
  }
  function scheduleSave() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(saveFlags, 250);
  }
  function saveFlags() {
    var headers = { "Content-Type": "application/json" };
    if (isAdmin()) headers["x-local-admin"] = "1";
    fetch("/api/features", { method: "POST", credentials: "include", headers: headers, body: JSON.stringify(flags) })
      .then(function (r) { return r.json(); })
      .then(function (j) {
        if (j && j.error) toast("تیک ذخیره نشد: " + (j.message || "وارد پنل مدیریت شو"));
        else toast("نمایش بخش‌ها ذخیره شد");
      }).catch(function () { toast("ذخیرهٔ تیک‌ها ناموفق بود"); });
  }
  function loadFlags() {
    fetch("/api/features", { credentials: "include" }).then(function (r) { return r.json(); }).then(function (j) {
      if (!j || j.error) return;
      ["tribes", "org", "arena", "daily"].forEach(function (k) { if (typeof j[k] === "boolean") flags[k] = j[k]; });
      syncNav(); syncFabs();
    }).catch(function () {});
  }
  function onHash() {
    var h = location.hash || "";
    ITEMS.forEach(function (item) {
      if (h.indexOf(item.hash) !== 0) return;
      if (!visible(item.id)) {
        toast("این بخش توسط مدیر غیرفعال شده است.");
        if (!isAdmin()) location.hash = "#home";
        return;
      }
      if (item.id === "arena" && window.__gamifyArenaOpen) window.__gamifyArenaOpen();
      if (item.id === "daily" && window.__gamifyDailyOpen) window.__gamifyDailyOpen();
      if (item.id === "org" && window.__gamifyOrgOpen) window.__gamifyOrgOpen();
    });
    syncNav();
  }

  function boot() {
    loadFlags();
    syncNav();
    syncFabs();
    setInterval(function () { syncNav(); syncFabs(); injectAdmin(); }, 800);
    window.addEventListener("hashchange", onHash);
    console.log("%c[gamify] منوی قبیله و تیک مدیریت فعال شد ✅", "color:#f2ca7c");
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();
})();
