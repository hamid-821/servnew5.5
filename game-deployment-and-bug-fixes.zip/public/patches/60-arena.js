/* 🎡 مرکز پاداش گیمیفای: ماموریت‌های روزانه + چرخ شانس + تالار افتخار (همه با پاداش سمت سرور) */
(function () {
  "use strict";
  if (window.__gamifyArena) return;
  window.__gamifyArena = true;

  var LS_KEY = "gamify2-store-v2";
  var overlay = null;
  var state = { tab: "quests", data: null, spinning: false, rotation: 0, prize: null, error: "" };
  var COLORS = ["#3a2a52", "#2c2140", "#4a3566", "#34264b", "#3f2e5c", "#2a1f3d", "#4b3a2a", "#352547"];

  function readStore() { try { return JSON.parse(localStorage.getItem(LS_KEY) || "null"); } catch (e) { return null; } }
  function esc(s) { return String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }
  function fa(n) { try { return Number(n || 0).toLocaleString("fa-IR"); } catch (e) { return String(n || 0); } }
  function toast(m) { if (window.__gamifyToast) window.__gamifyToast(m); }
  function api(path, method, body) {
    var ready = window.__gamifyServer && window.__gamifyServer.ensureSynced ? window.__gamifyServer.ensureSynced() : Promise.resolve();
    return ready.then(function () {
      return fetch(path, { method: method || "GET", credentials: "include", headers: { "Content-Type": "application/json" }, body: body ? JSON.stringify(body) : undefined })
        .then(function (r) { return r.json().then(function (j) { return { status: r.status, body: j }; }); });
    });
  }
  function resync() { try { if (window.__gamifyServer) window.__gamifyServer.syncNow(); } catch (e) {} }

  function ensureOverlay() {
    if (overlay) return overlay;
    overlay = document.createElement("div");
    overlay.className = "gamify-overlay";
    overlay.id = "gamify-arena-overlay";
    overlay.addEventListener("click", function (e) { if (e.target === overlay) close(); });
    document.body.appendChild(overlay);
    return overlay;
  }
  function close() { if (overlay) overlay.classList.remove("open"); }

  function loggedIn() {
    try { if (window.__gamifySession && window.__gamifySession.isLoggedIn()) return true; } catch (e) {}
    try { if (window.__gamifyLiveGet && window.__gamifyLiveGet().profile) return true; } catch (e) {}
    var st = readStore();
    return !!(st && st.profile);
  }
  function load(retried) {
    return api("/api/arena").then(function (r) {
      if (r.status === 401 && !retried && window.__gamifyServer && window.__gamifyServer.syncNow) {
        return window.__gamifyServer.syncNow().then(function () { return load(true); });
      }
      if (r.status === 200) { state.data = r.body; state.error = ""; }
      else {
        state.data = null;
        state.error = loggedIn()
          ? "حسابت وصل است؛ اتصال سرور لحظه‌ای قطع بود. دوباره باز کن."
          : ((r.body && (r.body.message || r.body.error)) || "خطا");
      }
      updateBadge();
      render();
    }).catch(function () { state.error = "ارتباط با سرور برقرار نشد."; render(); });
  }

  function updateBadge() {
    var b = document.getElementById("gamify-arena-fab");
    if (!b) return;
    var old = b.querySelector(".gamify-fab-badge");
    if (old) old.remove();
    var n = 0;
    if (state.data) {
      n = state.data.quests.filter(function (q) { return q.ready && !q.claimed; }).length;
      if (state.data.wheel.canSpin) n++;
    }
    if (n > 0) { var s = document.createElement("span"); s.className = "gamify-fab-badge"; s.textContent = fa(n); b.appendChild(s); }
  }

  function wheelHtml(d) {
    var n = d.wheel.prizes.length, seg = 360 / n, grad = [];
    for (var i = 0; i < n; i++) grad.push(COLORS[i % COLORS.length] + " " + (i * seg) + "deg " + ((i + 1) * seg) + "deg");
    var segs = d.wheel.prizes.map(function (p, i) {
      return '<div class="seg" style="transform:rotate(' + (i * seg + seg / 2) + 'deg)"><span>' + p.icon + "</span></div>";
    }).join("");
    var pop = state.prize ? '<div class="gamify-prize-pop"><div class="big">' + state.prize.icon + "</div><h3>تبریک! " + esc(state.prize.label) + "</h3></div>" : "";
    return '<div class="gamify-wheel-wrap"><div class="gamify-wheel-pin">🔻</div>' +
      '<div class="gamify-wheel" id="gm-wheel" style="background:conic-gradient(' + grad.join(",") + ");transform:rotate(" + state.rotation + 'deg)">' + segs + "</div>" +
      '<div class="gamify-wheel-hub">⚡</div></div>' + pop +
      '<div class="gamify-row" style="justify-content:center;margin-top:10px;">' +
      (d.wheel.canSpin
        ? '<button class="gamify-btn primary" data-act="spin"' + (state.spinning ? " disabled" : "") + ">🎡 بچرخان!</button>"
        : '<span class="gamify-hint">✅ چرخ امروز را چرخاندی' + (d.wheel.lastPrize ? " (" + esc(d.wheel.lastPrize) + ")" : "") + " — فردا دوباره!</span>") + "</div>";
  }

  function questsHtml(d) {
    return d.quests.map(function (q, i) {
      var pct = Math.round(q.progress / q.target * 100);
      var btn = q.claimed ? '<span class="gamify-joined">✅ دریافت شد</span>'
        : q.ready ? '<button class="gamify-btn primary sm" data-act="claim" data-id="' + q.id + '">🎁 دریافت</button>'
        : '<span class="gamify-hint">' + fa(q.progress) + "/" + fa(q.target) + "</span>";
      return '<div class="gamify-quest ' + (q.claimed ? "done" : "") + '" style="animation-delay:' + (i * 60) + 'ms"><div class="ic">' + q.icon + '</div><div><div class="tt">' + esc(q.title) +
        '</div><div class="rw">🪙 ' + fa(q.coins) + " سکه · ⭐ " + fa(q.xp) + ' امتیاز</div><div class="bar"><i style="width:' + pct + '%"></i></div></div>' + btn + "</div>";
    }).join("");
  }

  function hallHtml(d) {
    var medals = ["🥇", "🥈", "🥉", "4️⃣", "5️⃣"];
    var h = '<h4 style="margin:0 0 6px;">👑 برترین‌های این هفته</h4><div class="gamify-hall">' + d.hall.map(function (u, i) {
      return '<div class="row" style="animation-delay:' + (i * 70) + 'ms"><span>' + medals[i] + "</span><b>" + esc(u.name) + "</b><span>⭐ " + fa(u.weekXp) + "</span></div>";
    }).join("") + "</div>";
    if (d.tribes && d.tribes.length) {
      h += '<h4 style="margin:14px 0 6px;">🛡️ قبیله‌های برتر</h4><div class="gamify-hall">' + d.tribes.map(function (t, i) {
        return '<div class="row" style="animation-delay:' + (i * 70) + 'ms"><span>' + esc(t.emoji) + "</span><b>" + esc(t.name) + "</b><span>⭐ " + fa(t.xp) + "</span></div>";
      }).join("") + "</div>";
    }
    return h;
  }

  function render() {
    var ov = ensureOverlay();
    if (!ov.classList.contains("open")) return;
    var st = readStore();
    var head = '<div class="gamify-modal-head"><b>⚡ مرکز پاداش</b><button data-act="close" class="gamify-btn sm">✕</button></div>';
    if (!loggedIn()) {
      ov.innerHTML = '<div class="gamify-modal">' + head + '<div class="gamify-empty"><div style="font-size:52px;">🌱</div><h3>ابتدا وارد بازی شو</h3><p>برای ماموریت‌ها و چرخ شانس باید وارد شده باشی.</p></div></div>';
      bind(ov); return;
    }
    if (!state.data) {
      ov.innerHTML = '<div class="gamify-modal">' + head + '<div class="gamify-loading">' + esc(state.error || "در حال دریافت…") + "</div></div>";
      bind(ov); return;
    }
    var d = state.data;
    var hero = '<div class="gamify-hero"><div class="bolt">⚡</div><div style="flex:1"><div class="lv">سطح ' + fa(d.level.level) + " · رتبهٔ " + fa(d.rank) + " در بین بازیکنان</div>" +
      '<div class="gamify-hint">' + fa(d.level.into) + " / " + fa(d.level.need) + ' امتیاز تا سطح بعد</div><div class="gamify-xpbar"><i style="width:' + Math.round(d.level.into / d.level.need * 100) + '%"></i></div></div></div>';
    var tabs = '<div class="gamify-tabs">' + [["quests", "🎯 ماموریت‌ها"], ["wheel", "🎡 چرخ شانس"], ["hall", "👑 تالار افتخار"]].map(function (t) {
      return '<button class="gamify-btn sm ' + (state.tab === t[0] ? "primary" : "") + '" data-act="tab" data-tab="' + t[0] + '">' + t[1] + "</button>";
    }).join("") + "</div>";
    var body = state.tab === "quests" ? '<div class="gamify-body">' + questsHtml(d) + "</div>" : state.tab === "wheel" ? wheelHtml(d) : hallHtml(d);
    ov.innerHTML = '<div class="gamify-modal">' + head + hero + '<div style="height:10px"></div>' + tabs + body + "</div>";
    bind(ov);
  }

  function bind(ov) {
    ov.querySelectorAll("[data-act]").forEach(function (el) {
      el.addEventListener("click", function () {
        var act = el.getAttribute("data-act");
        if (act === "close") return close();
        if (act === "tab") { state.tab = el.getAttribute("data-tab"); state.prize = null; return render(); }
        if (act === "claim") return claim(el.getAttribute("data-id"));
        if (act === "spin") return spin();
      });
    });
  }

  function claim(id) {
    api("/api/arena?action=claim", "POST", { id: id }).then(function (r) {
      if (r.body && r.body.ok) {
        toast("🎁 +" + fa(r.body.coins) + " سکه و +" + fa(r.body.xp) + " امتیاز");
        if (window.__gamifyConfetti) window.__gamifyConfetti();
        resync(); load();
      } else toast("⚠️ " + ((r.body && (r.body.error || r.body.message)) || "خطا"));
    });
  }

  function spin() {
    if (state.spinning) return;
    state.spinning = true;
    api("/api/arena?action=spin", "POST", {}).then(function (r) {
      if (!r.body || !r.body.ok) { state.spinning = false; toast("⚠️ " + ((r.body && (r.body.error || r.body.message)) || "خطا")); return load(); }
      var n = state.data.wheel.prizes.length, seg = 360 / n;
      // جایزه باید زیر نشانگر (بالا) بایستد
      var target = 360 * 6 + (360 - (r.body.index * seg + seg / 2));
      state.rotation = state.rotation - (state.rotation % 360) + target;
      var w = document.getElementById("gm-wheel");
      if (w) w.style.transform = "rotate(" + state.rotation + "deg)";
      setTimeout(function () {
        state.spinning = false; state.prize = r.body.prize;
        if (window.__gamifyConfetti) window.__gamifyConfetti();
        toast("🎉 " + r.body.prize.label);
        resync();
        api("/api/arena").then(function (rr) { if (rr.status === 200) { state.data = rr.body; updateBadge(); render(); } });
      }, 5200);
    });
  }

  function open() {
    if (window.__gamifyFeatureOn && !window.__gamifyFeatureOn("arena")) return;
    var ov = ensureOverlay();
    ov.classList.add("open");
    state.prize = null;
    render();
    load();
  }

  function mountFab() {
    if (document.getElementById("gamify-arena-fab")) return;
    var b = document.createElement("button");
    b.id = "gamify-arena-fab";
    b.textContent = "🎡";
    b.title = "مرکز پاداش: ماموریت‌ها و چرخ شانس";
    b.addEventListener("click", open);
    document.body.appendChild(b);
  }

  function boot() {
    setTimeout(mountFab, 5000);
    setTimeout(function () { var st = readStore(); if (st && st.profile) load(); }, 9000);
    setInterval(function () { var st = readStore(); if (st && st.profile && !(overlay && overlay.classList.contains("open"))) load(); }, 90000);
    window.__gamifyArenaOpen = open;
    console.log("%c[gamify] مرکز پاداش فعال شد ✅", "color:#7cd7b6");
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot); else boot();
})();
