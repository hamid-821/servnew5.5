import { eq, and, desc, sql, or } from "drizzle-orm";
import { db } from "@/db";
import { dailyClaims, users, notifications, achievements, userAchievements } from "@/db/schema";
import { uid, now, json, getSessionUser, createSession, setAuthCookie } from "@/lib/auth";
import { ensureSeed } from "@/lib/ensure-seed";

// GET: وضعیت امروز + دستاوردها + اعلان‌ها
export async function GET(req: Request) {
  await ensureSeed();
  const me = await getSessionUser();
  if (!me) return json({ error: "not-authed", message: "ابتدا وارد بازی شو 🌱" }, 401);
  const kind = new URL(req.url).searchParams.get("kind") || "daily";
  if (kind === "notifications") {
    const rows = await db.select().from(notifications).where(eq(notifications.userId, me.id)).orderBy(desc(notifications.createdAt)).limit(30);
    return json(rows);
  }
  if (kind === "achievements") {
    const all = await db.select().from(achievements);
    const mine = await db.select().from(userAchievements).where(eq(userAchievements.userId, me.id));
    const owned = new Set(mine.map((x) => x.achievementId));
    return json(all.map((a) => ({ ...a, unlocked: owned.has(a.id), unlockedAt: mine.find((x) => x.achievementId === a.id)?.unlockedAt ?? 0 })));
  }
  const today = new Date().toISOString().slice(0, 10);
  const claimed = (await db.select().from(dailyClaims).where(and(eq(dailyClaims.userId, me.id), eq(dailyClaims.day, today))).limit(1))[0];
  return json({ claimed: !!claimed, streak: me.streak ?? 0, coins: me.coins ?? 0 });
}

// POST: دریافت پاداش روزانه
export async function POST(req: Request) {
  await ensureSeed();
  let b: Record<string, unknown> = {};
  try { b = await req.json(); } catch { b = {}; }
  let me = await getSessionUser();

  if (!me && b.profile && typeof b.profile === "object") {
    const prof = b.profile as Record<string, unknown>;
    const pLocalId = String(prof.id || prof.localId || "");
    if (pLocalId) {
      me = (await db.select().from(users).where(or(eq(users.id, pLocalId), eq(users.localId, pLocalId))).limit(1))[0] || null;
    }
  }

  if (!me) return json({ error: "not-authed", message: "ابتدا وارد بازی شو 🌱" }, 401);
  const today = new Date().toISOString().slice(0, 10);
  const yesterday = new Date(now() - 86400000).toISOString().slice(0, 10);
  const claimed = (await db.select().from(dailyClaims).where(and(eq(dailyClaims.userId, me.id), eq(dailyClaims.day, today))).limit(1))[0];
  if (claimed) return json({ error: "امروز قبلاً جایزه‌ات را گرفتی! فردا برگرد 🎁" }, 400);
  const hadYesterday = (await db.select().from(dailyClaims).where(and(eq(dailyClaims.userId, me.id), eq(dailyClaims.day, yesterday))).limit(1))[0];
  const streak = hadYesterday ? (me.streak ?? 0) + 1 : 1;
  const coins = 25 + Math.min(100, streak * 5);
  await db.insert(dailyClaims).values({ userId: me.id, day: today, coins, streak, createdAt: now() });
  await db.update(users).set({ coins: sql`${users.coins} + ${coins}`, streak, lastDaily: today, xp: sql`${users.xp} + 20` }).where(eq(users.id, me.id));
  if (streak >= 3) {
    try { await db.insert(userAchievements).values({ userId: me.id, achievementId: "streak-3", unlockedAt: now() }).onConflictDoNothing(); } catch { /* ignore */ }
  }
  const { token } = await createSession(me.id);
  const res = json({ ok: true, coins, streak, message: `🎁 +${coins} سکه! (${streak} روز پیاپی)`, serverToken: token });
  return setAuthCookie(res, token);
}
