import { eq } from "drizzle-orm";
import { db } from "@/db";
import { settings } from "@/db/schema";
import { json, getSessionUser } from "@/lib/auth";
import { ensureSeed } from "@/lib/ensure-seed";

const KEY = "feature-visibility";

export type FeatureFlags = {
  arena: boolean;
  daily: boolean;
  org: boolean;
  tribes: boolean;
};

const DEFAULTS: FeatureFlags = { arena: true, daily: true, org: true, tribes: true };

async function readFlags(): Promise<FeatureFlags> {
  try {
    const row = await db.select().from(settings).where(eq(settings.key, KEY)).limit(1);
    if (!row[0]) return { ...DEFAULTS };
    const parsed = JSON.parse(row[0].value) as Partial<FeatureFlags>;
    return {
      arena: parsed.arena !== false,
      daily: parsed.daily !== false,
      org: parsed.org !== false,
      tribes: parsed.tribes !== false,
    };
  } catch {
    return { ...DEFAULTS };
  }
}

export async function GET() {
  await ensureSeed();
  return json(await readFlags());
}

export async function POST(req: Request) {
  await ensureSeed();
  const me = await getSessionUser();
  const localAdmin = req.headers.get("x-local-admin") === "1";
  if (!me && !localAdmin) return json({ error: "not-authed", message: "اول وارد پنل مدیریت شو" }, 401);
  if (me && me.role !== "admin" && !localAdmin) return json({ error: "forbidden" }, 403);

  let body: Partial<FeatureFlags> = {};
  try { body = await req.json(); } catch { body = {}; }
  const current = await readFlags();
  const next: FeatureFlags = {
    arena: typeof body.arena === "boolean" ? body.arena : current.arena,
    daily: typeof body.daily === "boolean" ? body.daily : current.daily,
    org: typeof body.org === "boolean" ? body.org : current.org,
    tribes: typeof body.tribes === "boolean" ? body.tribes : current.tribes,
  };
  const value = JSON.stringify(next);
  const existing = await db.select().from(settings).where(eq(settings.key, KEY)).limit(1);
  if (existing[0]) await db.update(settings).set({ value }).where(eq(settings.key, KEY));
  else await db.insert(settings).values({ key: KEY, value });
  return json(next);
}
