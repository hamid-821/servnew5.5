import { json } from "@/lib/auth";
import { ensureSeed } from "@/lib/ensure-seed";

export async function GET() {
  await ensureSeed();
  return json({ ok: true, app: "gamify2", ts: Date.now() });
}
