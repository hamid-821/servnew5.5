import { eq, count } from "drizzle-orm";
import { db } from "@/db";
import { organizations, orgMembers, users } from "@/db/schema";
import { json, getSessionUser, now } from "@/lib/auth";
import { ensureSeed } from "@/lib/ensure-seed";

export async function GET() {
  await ensureSeed();
  const me = await getSessionUser();
  const orgs = await db.select().from(organizations);
  const out = [];
  for (const o of orgs) {
    const members = await db.select({ c: count() }).from(orgMembers).where(eq(orgMembers.orgId, o.id));
    out.push({ ...o, members: Number(members[0]?.c ?? 0), mine: me?.orgId === o.id });
  }
  return json(out);
}

export async function POST(req: Request) {
  await ensureSeed();
  const me = await getSessionUser();
  if (!me) return json({ error: "not-authed", message: "ابتدا وارد بازی شو" }, 401);
  let b: Record<string, unknown> = {};
  try { b = await req.json(); } catch { b = {}; }
  const orgId = String(b.orgId || b.org || "");
  const org = (await db.select().from(organizations).where(eq(organizations.id, orgId)).limit(1))[0];
  if (!org) return json({ error: "org-not-found" }, 404);
  await db.update(users).set({ orgId, lastSeen: now() }).where(eq(users.id, me.id));
  await db.insert(orgMembers).values({ orgId, userId: me.id, status: "approved", joinedAt: now() }).onConflictDoNothing();
  return json({ ok: true, orgId, message: `عضویت در ${org.name} ثبت شد ✅ تورنمنت‌های ویژه‌اش برایت باز است.` });
}
