import { desc, count, gte, eq, asc } from "drizzle-orm";
import { db } from "@/db";
import { users, tribes, posts, stories, auditLog, tournaments, tribeBattles } from "@/db/schema";
import { json, pub, getSessionUser, now } from "@/lib/auth";
import { ensureSeed } from "@/lib/ensure-seed";

// GET ?view=overview|users — نمای زندهٔ مدیر
export async function GET(req: Request) {
  await ensureSeed();
  const me = await getSessionUser();
  const localAdmin = req.headers.get("x-local-admin") === "1";
  if (!me && !localAdmin) return json({ error: "not-authed" }, 401);
  if (me && me.role !== "admin" && !localAdmin) return json({ error: "forbidden" }, 403);
  const view = new URL(req.url).searchParams.get("view") || "overview";

  if (view === "users") {
    const q = new URL(req.url).searchParams.get("q") || "";
    const filter = new URL(req.url).searchParams.get("filter") || ""; // 'real' | 'all' | 'demo'
    
    // مرتب‌سازی با اولویت کاربران حقیقی و آخرین فعالیت
    const rows = await db.select().from(users).orderBy(asc(users.isDemo), desc(users.lastSeen)).limit(200);
    
    let filtered = rows;
    if (filter === "real") {
      filtered = filtered.filter((u) => !u.isDemo);
    } else if (filter === "demo") {
      filtered = filtered.filter((u) => !!u.isDemo);
    }
    
    if (q) {
      filtered = filtered.filter((u) =>
        u.name.includes(q) ||
        (u.phone || "").includes(q) ||
        (u.email || "").includes(q) ||
        (u.orgId || "").includes(q)
      );
    }

    return json({
      users: filtered.map((u) => ({
        ...pub(u),
        online: (u.lastSeen ?? 0) > now() - 5 * 60000,
        isReal: !u.isDemo,
      })),
      counts: {
        total: rows.length,
        real: rows.filter((u) => !u.isDemo).length,
        demo: rows.filter((u) => !!u.isDemo).length,
      }
    });
  }

  const totalUsers = await db.select({ c: count() }).from(users);
  const realUsers = await db.select({ c: count() }).from(users).where(eq(users.isDemo, false));
  const onlineUsers = await db.select({ c: count() }).from(users).where(gte(users.lastSeen, now() - 5 * 60000));
  const totalTribes = await db.select({ c: count() }).from(tribes);
  const pendingPosts = await db.select({ c: count() }).from(posts).where(eq(posts.status, "pending"));
  const pendingStories = await db.select({ c: count() }).from(stories).where(eq(stories.status, "pending"));
  const totalTournaments = await db.select({ c: count() }).from(tournaments);
  const activeBattles = await db.select({ c: count() }).from(tribeBattles).where(eq(tribeBattles.status, "active"));
  
  // آخرین کاربران حقیقی
  const recentRealUsers = await db.select().from(users).where(eq(users.isDemo, false)).orderBy(desc(users.lastSeen)).limit(15);
  const recentAllUsers = await db.select().from(users).orderBy(desc(users.lastSeen)).limit(12);
  const logs = await db.select().from(auditLog).orderBy(desc(auditLog.id)).limit(20);

  return json({
    stats: {
      totalUsers: Number(totalUsers[0]?.c ?? 0),
      realUsers: Number(realUsers[0]?.c ?? 0),
      onlineUsers: Number(onlineUsers[0]?.c ?? 0),
      totalTribes: Number(totalTribes[0]?.c ?? 0),
      pendingPosts: Number(pendingPosts[0]?.c ?? 0),
      pendingStories: Number(pendingStories[0]?.c ?? 0),
      totalTournaments: Number(totalTournaments[0]?.c ?? 0),
      activeBattles: Number(activeBattles[0]?.c ?? 0),
    },
    recentUsers: (recentRealUsers.length ? recentRealUsers : recentAllUsers).map((u) => ({
      ...pub(u),
      online: (u.lastSeen ?? 0) > now() - 5 * 60000,
      isReal: !u.isDemo,
    })),
    logs,
  });
}

// POST ?action=ban|unban|make-admin — مدیریت کاربر
export async function POST(req: Request) {
  await ensureSeed();
  const me = await getSessionUser();
  const localAdmin = req.headers.get("x-local-admin") === "1";
  if (!me && !localAdmin) return json({ error: "not-authed" }, 401);
  if (me && me.role !== "admin" && !localAdmin) return json({ error: "forbidden" }, 403);
  const action = new URL(req.url).searchParams.get("action") || "";
  let b: Record<string, unknown> = {};
  try { b = await req.json(); } catch { b = {}; }
  const userId = String(b.userId || "");
  if (!userId) return json({ error: "bad-request" }, 400);
  if (action === "ban") await db.update(users).set({ banned: true }).where(eq(users.id, userId));
  else if (action === "unban") await db.update(users).set({ banned: false }).where(eq(users.id, userId));
  else if (action === "make-admin") await db.update(users).set({ role: "admin" }).where(eq(users.id, userId));
  else return json({ error: "unknown-action" }, 400);
  try { await db.insert(auditLog).values({ actor: me?.name || "local-admin", action, target: userId, createdAt: now() }); } catch { /* ignore */ }
  return json({ ok: true });
}
