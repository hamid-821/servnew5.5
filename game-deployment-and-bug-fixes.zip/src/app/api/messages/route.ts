import { and, or, eq, asc } from "drizzle-orm";
import { db } from "@/db";
import { messages, users } from "@/db/schema";
import { uid, now, json, getSessionUser } from "@/lib/auth";
import { ensureSeed } from "@/lib/ensure-seed";

// سازگار با قرارداد server.cjs: GET ?with= / POST {to,text}
export async function GET(req: Request) {
  await ensureSeed();
  const u = await getSessionUser();
  if (!u) return json({ error: "not-authed" }, 401);
  const withId = new URL(req.url).searchParams.get("with") || "";
  if (!withId) return json([]);
  const rows = await db.select().from(messages)
    .where(or(
      and(eq(messages.sender, u.id), eq(messages.recipient, withId)),
      and(eq(messages.sender, withId), eq(messages.recipient, u.id)),
    ))
    .orderBy(asc(messages.createdAt)).limit(200);
  // علامت خوانده‌شده
  await db.update(messages).set({ seen: 1 }).where(and(eq(messages.sender, withId), eq(messages.recipient, u.id)));
  return json(rows.map((m) => ({ id: m.id, from_id: m.sender, to_id: m.recipient, text: m.body, at: m.createdAt, read: m.seen, from: m.sender === u.id ? "me" : "them" })));
}

export async function POST(req: Request) {
  await ensureSeed();
  const u = await getSessionUser();
  if (!u) return json({ error: "not-authed" }, 401);
  let b: Record<string, unknown> = {};
  try { b = await req.json(); } catch { b = {}; }
  const to = String(b.to || b.recipient || "");
  const text = String(b.text || b.body || "").slice(0, 1000);
  if (!to || !text) return json({ error: "bad-request" }, 400);
  const target = await db.select({ id: users.id }).from(users).where(eq(users.id, to)).limit(1);
  if (!target[0]) return json({ error: "user-not-found" }, 404);
  const id = uid("m");
  const at = now();
  await db.insert(messages).values({ id, sender: u.id, recipient: to, body: text, media: String(b.media || ""), createdAt: at, seen: 0 });
  return json({ id, at });
}
