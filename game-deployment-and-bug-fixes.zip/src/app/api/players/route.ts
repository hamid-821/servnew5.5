import { and, desc, eq, gte } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { pub, json, getSessionUser, now } from "@/lib/auth";
import { ensureSeed } from "@/lib/ensure-seed";

export async function GET(req: Request) {
  await ensureSeed();
  await getSessionUser(); // به‌روزرسانی last_seen
  const url = new URL(req.url);
  const onlineOnly = url.searchParams.get("online") === "1";
  const limit = Math.min(200, Math.max(10, Number(url.searchParams.get("limit") || 200)));
  const rows = onlineOnly
    ? await db.select().from(users).where(and(gte(users.lastSeen, now() - 5 * 60000), eq(users.isDemo, false))).orderBy(desc(users.xp)).limit(limit)
    : await db.select().from(users).orderBy(desc(users.xp)).limit(limit);
  return json(rows.map((u) => ({ ...pub(u), online: (u.lastSeen ?? 0) > now() - 5 * 60000 })));
}
