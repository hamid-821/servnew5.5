import { eq } from "drizzle-orm";
import { db } from "@/db";
import { questions, categories } from "@/db/schema";
import { json } from "@/lib/auth";
import { ensureSeed } from "@/lib/ensure-seed";

// GET ?category=general&count=5 — سؤال برای نبرد قبیله‌ای/تورنمنت (بدون پاسخ!)
export async function GET(req: Request) {
  await ensureSeed();
  const url = new URL(req.url).searchParams.get("category") || "general";
  const countN = Math.min(10, Math.max(1, Number(new URL(req.url).searchParams.get("count") || 5)));
  if (url === "_categories") {
    const rows = await db.select().from(categories);
    const out = [];
    for (const c of rows) {
      const n = await db.select().from(questions).where(eq(questions.category, c.id)).limit(1000);
      out.push({ ...c, questionCount: n.length });
    }
    return json(out);
  }
  let bank = await db.select().from(questions).where(eq(questions.category, url)).limit(100);
  if (bank.length < countN) bank = await db.select().from(questions).limit(100);
  const picked = [...bank].sort(() => Math.random() - 0.5).slice(0, countN)
    .map((q) => ({ id: q.id, category: q.category, title: q.title, options: q.options, seconds: q.seconds ?? 25 }));
  return json(picked);
}
