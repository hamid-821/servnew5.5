import Script from "next/script";

export const dynamic = "force-dynamic";

/**
 * گیمیفای ۲ — نسخهٔ اصلی (appgame.zip) دقیقاً با همان گرافیک و امکانات.
 * باندل اصلی دست‌نخورده از /original/bundle.js اجرا می‌شود؛
 * پچ‌های زیر فقط: باگ پرش چت را می‌گیرند + همگام‌سازی سرور + قبیله + سازمان + پنل زنده + امکانات جهانی.
 */
export default function HomePage() {
  return (
    <>
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css" />
      {/* استایل اصلی بازی — دست‌نخورده */}
      <link rel="stylesheet" href="/original/bundle.css" />
      {/* استایل امکانات جدید (هم‌خانواده با تم اصلی) */}
      <link rel="stylesheet" href="/patches/patches.css" />

      <div id="root">
        <div style={{ display: "grid", placeItems: "center", minHeight: "100vh", background: "#17111f", color: "#f2ca7c", fontFamily: "Vazirmatn, sans-serif" }}>
          <div style={{ textAlign: "center" }}>
            <div style={{ fontSize: 56 }}>🎮</div>
            <h1 style={{ fontSize: 28, fontWeight: 800 }}>گیمیفای <span>۲</span></h1>
            <p style={{ opacity: 0.8 }}>یک بازی، هزار تجربه…</p>
          </div>
        </div>
      </div>

      {/* ۰) فیکس پرش چت — باید قبل از باندل اصلی اجرا شود */}
      <Script src="/patches/00-scroll-fix.js" strategy="beforeInteractive" />

      {/* باندل اصلی بازی — دقیقاً همان نسخهٔ سرور شما */}
      <Script src="/original/bundle.js" type="module" strategy="afterInteractive" />

      {/* ۱) ذخیرهٔ دوگانه: مرورگر + سرور */}
      <Script src="/patches/10-sync.js" strategy="afterInteractive" />
      {/* ۲) انتخاب سازمان هنگام ثبت‌نام */}
      <Script src="/patches/20-org.js" strategy="afterInteractive" />
      {/* ۳) قبیله‌ها + نبرد قبیله‌ای */}
      <Script src="/patches/30-tribes.js" strategy="afterInteractive" />
      {/* ۴) پنل زندهٔ تأیید پست/استوری برای مدیر */}
      <Script src="/patches/40-moderation.js" strategy="afterInteractive" />
      {/* ۵) امکانات درجه‌جهانی + انیمیشن */}
      <Script src="/patches/50-worldclass.js" strategy="afterInteractive" />
      {/* ۶) مرکز پاداش: ماموریت روزانه + چرخ شانس + تالار افتخار */}
      <Script src="/patches/60-arena.js" strategy="afterInteractive" />
      {/* ۷) منوی راست + تیک نمایش در پنل مدیریت */}
      <Script src="/patches/70-menu.js" strategy="afterInteractive" />
    </>
  );
}
