import { db } from "@/db";
import { categories, organizations, questions, achievements, settings, tournaments } from "@/db/schema";
import { CATEGORIES, ORGS, QUESTIONS, ACHIEVEMENTS } from "./seed-data";
import { uid, now } from "./auth";
import { seedTribes } from "./seed-tribes";

let seeded = false;

export async function ensureSeed() {
  if (seeded) return;
  try {
    const flag = await db.select().from(settings).limit(1).then(() => null).catch(() => "missing");
    if (flag === "missing") return; // جدول‌ها هنوز ساخته نشده‌اند
    const existing = await db.select({ key: settings.key }).from(settings);
    if (existing.some((s) => s.key === "seed-v1")) { await seedTribes(); seeded = true; return; }

    for (const c of CATEGORIES) {
      await db.insert(categories).values({ ...c }).onConflictDoNothing();
    }
    for (const o of ORGS) {
      await db.insert(organizations).values({ ...o, memberCount: 0, createdAt: now() }).onConflictDoNothing();
    }
    for (const q of QUESTIONS) {
      await db.insert(questions).values({ id: uid("q"), ...q, seconds: 25, kind: "text", media: "", status: "approved", author: "" }).onConflictDoNothing();
    }
    for (const a of ACHIEVEMENTS) {
      await db.insert(achievements).values(a).onConflictDoNothing();
    }
    // تورنمنت‌های پیش‌فرض: عمومی + ویژه برق
    const t = now(), day = 86400000;
    const defaults = [
      { id: "tour-public-weekly", title: "🏆 جام هفتگی گیمیفای", category: "general", startsAt: t - day, endsAt: t + 6 * day, description: "رقابت آزاد هفتگی برای همهٔ بازیکنان", orgId: "", tribeOnly: false, maxPlayers: 2000, active: true, createdBy: "system", createdAt: t },
      { id: "tour-barq-cup", title: "⚡ جام تخصصی برق", category: "electric", startsAt: t - day, endsAt: t + 13 * day, description: "ویژهٔ اعضای سازمان برق — به‌صورت خودکار برای اعضای برق باز است.", orgId: "barq", tribeOnly: false, maxPlayers: 1000, active: true, createdBy: "system", createdAt: t },
      { id: "tour-safety", title: "🦺 چالش ایمنی", category: "safety", startsAt: t - day, endsAt: t + 6 * day, description: "ویژهٔ فعالان ایمنی و HSE", orgId: "safety-org", tribeOnly: false, maxPlayers: 1000, active: true, createdBy: "system", createdAt: t },
      { id: "tour-tribe-wars", title: "⚔️ نبرد قبیله‌ها", category: "general", startsAt: t - day, endsAt: t + 30 * day, description: "ویژهٔ قبیله‌ها — امتیاز قبیله‌ات را بالا ببر!", orgId: "", tribeOnly: true, maxPlayers: 5000, active: true, createdBy: "system", createdAt: t },
    ];
    for (const d of defaults) {
      await db.insert(tournaments).values({ ...d, questions: [] }).onConflictDoNothing();
    }
    await db.insert(settings).values([
      { key: "seed-v1", value: JSON.stringify({ at: t }) },
      { key: "moderatePosts", value: "true" },
      { key: "moderateStories", value: "true" },
      { key: "autoApproveMinutes", value: "15" },
    ]).onConflictDoNothing();
    await seedTribes();
    seeded = true;
  } catch { /* دیتابیس آماده نیست؛ بعداً تلاش می‌شود */ }
}
