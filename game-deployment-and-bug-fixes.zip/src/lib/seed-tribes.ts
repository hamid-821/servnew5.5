import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users, tribes, tribeMembers, orgMembers, settings, tribeBattles, tournaments, tournamentPlayers, questions } from "@/db/schema";
import { now } from "./auth";

/** ده قبیله و ده بازیکنِ آمادهٔ مسابقه — هر بازیکن رهبر یک قبیله است و در تورنمنت و نبرد شرکت دارد. */
const TRIBES = [
  { id: "tribe-10-1", name: "صاعقه‌ها", tag: "صاعقه", emoji: "⚡", color: "#f8c56c", motto: "سریع‌تر از رعد، دقیق‌تر از ولت‌متر!", description: "رقابت شبکهٔ انتقال؛ عاشق سؤال‌های سخت برق." },
  { id: "tribe-10-2", name: "مدار بسته", tag: "مدار", emoji: "🔌", color: "#76bfec", motto: "جریان ما هیچ‌وقت قطع نمی‌شود.", description: "مهندسان مدار و الکترونیک قدرت." },
  { id: "tribe-10-3", name: "فشار قوی", tag: "HV", emoji: "🏭", color: "#a98cf7", motto: "۴۰۰ کیلوولت اراده!", description: "اپراتورهای پست‌های ۶۳ تا ۴۰۰ کیلوولت." },
  { id: "tribe-10-4", name: "روشن‌دلان", tag: "نور", emoji: "💡", color: "#f2ca7c", motto: "هر جا تاریکی هست، ما می‌رسیم.", description: "تیم توزیع و روشنایی تا خانهٔ مردم." },
  { id: "tribe-10-5", name: "انرژی سبز", tag: "سبز", emoji: "🌞", color: "#8cc993", motto: "خورشید، باد و آینده.", description: "نیروگاه خورشیدی و انرژی تجدیدپذیر." },
  { id: "tribe-10-6", name: "ارت و ایمنی", tag: "ایمن", emoji: "🦺", color: "#eda0b9", motto: "اول ایمنی، بعد برق!", description: "ارتینگ، قفل‌گذاری و تگ‌اوت." },
  { id: "tribe-10-7", name: "رله‌بانان", tag: "رله", emoji: "🎛️", color: "#7cd7b6", motto: "حفاظت، خط قرمز ماست.", description: "حفاظت شبکه و رله‌های دیجیتال." },
  { id: "tribe-10-8", name: "شین طلایی", tag: "شین", emoji: "🟨", color: "#e0a06b", motto: "شین داغ، ذهن خنک.", description: "تابلوسازان و شین‌کاران." },
  { id: "tribe-10-9", name: "توربین‌ها", tag: "توربین", emoji: "🌀", color: "#76bfec", motto: "چرخش بی‌وقفه.", description: "نیروگاه و تولید انرژی." },
  { id: "tribe-10-10", name: "نگهبانان شبکه", tag: "شبکه", emoji: "🛰️", color: "#c6a8da", motto: "اسکادا بیدار است.", description: "دیسپاچینگ و پایش شبکه." },
];

const PLAYERS = [
  "رضا صاعقه", "مینا مدار", "علی فشارقوی", "سارا روشن", "حسین خورشید",
  "نگین ایمنی", "امیر رله", "الهام شین", "کیان توربین", "مهسا شبکه",
];

export async function seedTribes() {
  const flag = await db.select().from(settings).where(eq(settings.key, "seed-tribes-v3")).limit(1);
  if (flag[0]) return;
  const t = now();
  const day = 86400000;
  const ids = PLAYERS.map((_, i) => `u-comp-${i + 1}`);

  for (let i = 0; i < PLAYERS.length; i++) {
    const xp = 5200 - i * 280;
    await db.insert(users).values({
      id: ids[i],
      localId: ids[i],
      name: PLAYERS[i],
      avatar: { seed: (i % 10) + 1 },
      bio: `رهبر قبیلهٔ «${TRIBES[i].name}» — آمادهٔ مسابقه ⚔️`,
      email: "",
      phone: "",
      provider: "competitor",
      googleSub: "",
      role: "player",
      orgId: "barq",
      xp,
      coins: 180 + i * 15,
      cups: 12 - i,
      streak: 6 + (i % 4),
      wins: 36 - i * 2,
      played: 70 - i * 3,
      rating: 1480 - i * 25,
      weekXp: 640 - i * 40,
      level: Math.floor(xp / 250) + 1,
      interests: ["electric", "safety"],
      friends: ids.filter((id) => id !== ids[i]),
      isPrivate: false,
      banned: false,
      isDemo: false,
      lastSeen: t - i * 40000,
      lastDaily: "",
      createdAt: t - day * (12 - i),
      extra: { competitor: true },
    }).onConflictDoNothing();
    await db.insert(orgMembers).values({ orgId: "barq", userId: ids[i], status: "approved", joinedAt: t }).onConflictDoNothing();
  }

  for (let i = 0; i < TRIBES.length; i++) {
    const T = TRIBES[i];
    await db.insert(tribes).values({
      id: T.id,
      name: T.name,
      tag: T.tag,
      description: T.description,
      motto: T.motto,
      logoEmoji: T.emoji,
      logoColor: T.color,
      ownerId: ids[i],
      maxMembers: 30,
      wins: 18 - i,
      losses: 2 + (i % 4),
      xp: 9000 - i * 520,
      rating: 1620 - i * 30,
      isPublic: true,
      inviteCode: `CUP${i + 1}0`,
      createdAt: t - day * (15 - i),
    }).onConflictDoNothing();
    await db.insert(tribeMembers).values({
      tribeId: T.id,
      userId: ids[i],
      role: "owner",
      contributedXp: 9000 - i * 520,
      joinedAt: t - day * 10,
    }).onConflictDoNothing();
  }

  const bank = await db.select().from(questions).limit(30);
  const packed = bank.slice(0, 5).map((q) => ({
    id: q.id,
    category: q.category,
    title: q.title,
    options: q.options,
    correct: q.correct,
    explanation: q.explanation || "",
    seconds: q.seconds || 25,
  }));

  await db.insert(tournaments).values({
    id: "tour-tribe-cup-10",
    title: "⚔️ جام ده قبیله",
    category: "electric",
    startsAt: t - day,
    endsAt: t + 14 * day,
    description: "مسابقهٔ زندهٔ ده قبیله. هر رهبر می‌تواند امتیاز قبیله‌اش را بالا ببرد.",
    orgId: "",
    tribeOnly: true,
    maxPlayers: 200,
    questions: packed,
    active: true,
    createdBy: "system",
    createdAt: t,
  }).onConflictDoNothing();

  for (let i = 0; i < ids.length; i++) {
    await db.insert(tournamentPlayers).values({
      tournamentId: "tour-tribe-cup-10",
      userId: ids[i],
      score: 980 - i * 55,
      rank: i + 1,
      joinedAt: t - day,
    }).onConflictDoNothing();
    await db.insert(tournamentPlayers).values({
      tournamentId: "tour-public-weekly",
      userId: ids[i],
      score: 760 - i * 40,
      rank: i + 1,
      joinedAt: t - day,
    }).onConflictDoNothing();
  }

  const pairs: Array<[number, number]> = [[0, 1], [2, 3], [4, 5], [6, 7], [8, 9]];
  for (let i = 0; i < pairs.length; i++) {
    const [a, b] = pairs[i];
    await db.insert(tribeBattles).values({
      id: `battle-10-${i + 1}`,
      tribeA: TRIBES[a].id,
      tribeB: TRIBES[b].id,
      category: "electric",
      status: i < 3 ? "active" : "finished",
      questions: packed,
      scoreA: i < 3 ? 220 + i * 30 : 640 - i * 20,
      scoreB: i < 3 ? 180 + i * 20 : 510 + i * 15,
      winnerId: i < 3 ? "" : TRIBES[a].id,
      createdBy: ids[a],
      startsAt: t - day,
      endsAt: t + 2 * day,
      createdAt: t - day,
    }).onConflictDoNothing();
  }

  await db.insert(settings).values({ key: "seed-tribes-v3", value: JSON.stringify({ at: t, tribes: 10, players: 10 }) }).onConflictDoNothing();
}
