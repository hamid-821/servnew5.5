import { cookies, headers } from "next/headers";
import { NextResponse } from "next/server";
import { randomBytes, randomUUID } from "node:crypto";
import { eq, and, lt, or } from "drizzle-orm";
import { db } from "@/db";
import { users, sessions, type UserRow } from "@/db/schema";

export const uid = (p = "") => p + randomUUID().replace(/-/g, "").slice(0, 12);
export const now = () => Date.now();

export function pub(u: UserRow) {
  return {
    id: u.id,
    name: u.name,
    avatar: u.avatar,
    bio: u.bio,
    role: u.role,
    email: u.email,
    phone: u.phone,
    provider: u.provider,
    orgId: u.orgId,
    xp: u.xp,
    coins: u.coins,
    cups: u.cups,
    streak: u.streak,
    wins: u.wins,
    played: u.played,
    rating: u.rating,
    weekXp: u.weekXp,
    level: u.level ?? Math.floor((u.xp ?? 0) / 250) + 1,
    interests: u.interests ?? [],
    friends: u.friends ?? [],
    private: !!u.isPrivate,
    isDemo: !!u.isDemo,
    isReal: !u.isDemo,
    last_seen: u.lastSeen,
    lastSeen: u.lastSeen,
    created_at: u.createdAt,
    createdAt: u.createdAt,
  };
}

export async function getCurrentToken(): Promise<string> {
  try {
    const jar = await cookies();
    const h = await headers();
    return jar.get("gtok")?.value || jar.get("gm_session")?.value || h.get("x-gamify-token") || "";
  } catch {
    return "";
  }
}

export async function getSessionUser(): Promise<UserRow | null> {
  try {
    let tok = "";
    let hdrUserId = "";
    let hdrLocalId = "";
    let hdrProfile = "";
    let hdrPhone = "";
    let hdrEmail = "";
    let hdrName = "";

    try {
      const jar = await cookies();
      tok = jar.get("gtok")?.value || jar.get("gm_session")?.value || "";
    } catch { /* ignore */ }

    try {
      const h = await headers();
      if (!tok) {
        tok = h.get("x-gamify-token") || (h.get("authorization") || "").replace(/^Bearer\s+/i, "");
      }
      hdrUserId = h.get("x-gamify-user-id") || "";
      hdrLocalId = h.get("x-gamify-local-id") || "";
      hdrProfile = h.get("x-gamify-profile") || "";
      hdrPhone = h.get("x-gamify-phone") || "";
      hdrEmail = h.get("x-gamify-email") || "";
      hdrName = h.get("x-gamify-name") || "";
    } catch { /* ignore */ }

    // ۱) بررسی نشست معتبر بر اساس توکن
    if (tok) {
      const s = await db.select().from(sessions).where(eq(sessions.token, tok)).limit(1);
      if (s[0] && s[0].expires > now()) {
        const rows = await db.select().from(users).where(and(eq(users.id, s[0].userId), eq(users.banned, false))).limit(1);
        if (rows[0]) {
          await db.update(users).set({ lastSeen: now() }).where(eq(users.id, rows[0].id));
          return { ...rows[0], lastSeen: now() };
        }
      }
    }

    // ۲) تطبیق شناسه یا localId
    const candidateIds: string[] = [];
    if (hdrUserId) candidateIds.push(hdrUserId);
    if (hdrLocalId && !candidateIds.includes(hdrLocalId)) candidateIds.push(hdrLocalId);

    for (const cid of candidateIds) {
      const matched = await db.select().from(users).where(and(or(eq(users.id, cid), eq(users.localId, cid)), eq(users.banned, false))).limit(1);
      if (matched[0]) {
        await db.update(users).set({ lastSeen: now() }).where(eq(users.id, matched[0].id));
        // ایجاد نشست سبک در صورت نیاز
        try { await createSession(matched[0].id); } catch { /* ignore */ }
        return { ...matched[0], lastSeen: now() };
      }
    }

    if (hdrPhone || hdrEmail) {
      const conds = [];
      if (hdrPhone) conds.push(eq(users.phone, hdrPhone));
      if (hdrEmail) conds.push(eq(users.email, hdrEmail));
      const matched = await db.select().from(users).where(and(or(...conds), eq(users.banned, false))).limit(1);
      if (matched[0]) {
        await db.update(users).set({ lastSeen: now() }).where(eq(users.id, matched[0].id));
        try { await createSession(matched[0].id); } catch { /* ignore */ }
        return { ...matched[0], lastSeen: now() };
      }
    }

    // ۳) ثبت و همگام‌سازی بلادرنگ کاربر از روی هدر پروفایل (جلوگیری قطعی از خطای «ابتدا وارد شو»)
    if (hdrProfile) {
      try {
        let parsed: Record<string, unknown> | null = null;
        const profileAttempts = [hdrProfile];
        try { profileAttempts.push(decodeURIComponent(hdrProfile)); } catch { /* already decoded */ }
        for (const attempt of profileAttempts) {
          try {
            const value = JSON.parse(attempt) as unknown;
            if (value && typeof value === "object") { parsed = value as Record<string, unknown>; break; }
          } catch { /* try next */ }
        }
        if (parsed && typeof parsed === "object") {
          const pLocalId = String(parsed.id || parsed.localId || "");
          const pName = String(parsed.name || "بازیکن").slice(0, 40) || "بازیکن";
          const pPhone = String(parsed.phone || "");
          const pEmail = String(parsed.email || "");
          const pOrg = String(parsed.org || parsed.orgId || "");
          const pAvatar = parsed.avatar || {};
          const pInterests = Array.isArray(parsed.interests) ? parsed.interests : [];
          const num = (v: unknown, d = 0) => (typeof v === "number" && Number.isFinite(v) ? Math.max(0, Math.round(v)) : d);
          const pXp = num(parsed.xp);
          const pCoins = num(parsed.coins, 50);
          const pCups = num(parsed.cups);
          const pStreak = num(parsed.streak);
          const pWins = num(parsed.wins);
          const pPlayed = num(parsed.played);
          const pRating = num(parsed.rating, 1000);

          const searchConds = [];
          if (pLocalId) {
            searchConds.push(eq(users.id, pLocalId));
            searchConds.push(eq(users.localId, pLocalId));
          }
          if (pPhone) searchConds.push(eq(users.phone, pPhone));
          if (pEmail) searchConds.push(eq(users.email, pEmail));

          if (searchConds.length) {
            const found = await db.select().from(users).where(and(or(...searchConds), eq(users.banned, false))).limit(1);
            if (found[0]) {
              await db.update(users).set({ lastSeen: now() }).where(eq(users.id, found[0].id));
              try { await createSession(found[0].id); } catch { /* ignore */ }
              return { ...found[0], lastSeen: now() };
            }
          }

          // ثبت کاربر حقیقی جدید در سرور اصلی
          const newId = pLocalId || uid("u");
          const newUserRow = {
            id: newId,
            localId: pLocalId || newId,
            name: pName,
            avatar: pAvatar,
            bio: String(parsed.bio || "").slice(0, 300),
            email: pEmail,
            phone: pPhone,
            provider: String(parsed.provider || "guest"),
            googleSub: "",
            role: "player",
            orgId: pOrg,
            xp: pXp,
            coins: pCoins,
            cups: pCups,
            streak: pStreak,
            wins: pWins,
            played: pPlayed,
            rating: pRating,
            weekXp: pXp,
            level: Math.floor(pXp / 250) + 1,
            interests: pInterests,
            friends: [],
            isPrivate: false,
            banned: false,
            isDemo: false, // ثبت قطعی کاربر به عنوان کاربر حقیقی
            lastSeen: now(),
            lastDaily: "",
            createdAt: now(),
            extra: {},
          };

          await db.insert(users).values(newUserRow).onConflictDoNothing();
          const inserted = await db.select().from(users).where(eq(users.id, newId)).limit(1);
          if (inserted[0]) {
            try { await createSession(inserted[0].id); } catch { /* ignore */ }
            return { ...inserted[0], lastSeen: now() };
          }
        }
      } catch {
        /* ignore parse error */
      }
    }

    // ۴) کاربر در بازی وارد شده ولی هنوز ردیف سرور ندارد — با شناسهٔ محلی بساز
    const fallbackId = (hdrUserId || hdrLocalId || "").slice(0, 80);
    if (fallbackId.length >= 3) {
      try {
        let name = "بازیکن";
        try { name = decodeURIComponent(hdrName || "").slice(0, 40) || "بازیکن"; } catch { name = (hdrName || "بازیکن").slice(0, 40); }
        await db.insert(users).values({
          id: fallbackId,
          localId: fallbackId,
          name,
          avatar: {},
          bio: "",
          email: hdrEmail,
          phone: hdrPhone,
          provider: "guest",
          googleSub: "",
          role: "player",
          orgId: "",
          xp: 0,
          coins: 50,
          cups: 0,
          streak: 0,
          wins: 0,
          played: 0,
          rating: 1000,
          weekXp: 0,
          level: 1,
          interests: [],
          friends: [],
          isPrivate: false,
          banned: false,
          isDemo: false,
          lastSeen: now(),
          lastDaily: "",
          createdAt: now(),
          extra: {},
        }).onConflictDoNothing();
        const inserted = await db.select().from(users).where(and(eq(users.id, fallbackId), eq(users.banned, false))).limit(1);
        if (!inserted[0]) {
          const byLocal = await db.select().from(users).where(and(eq(users.localId, fallbackId), eq(users.banned, false))).limit(1);
          if (byLocal[0]) {
            try { await createSession(byLocal[0].id); } catch { /* ignore */ }
            return { ...byLocal[0], lastSeen: now() };
          }
        } else {
          try { await createSession(inserted[0].id); } catch { /* ignore */ }
          return { ...inserted[0], lastSeen: now() };
        }
      } catch { /* ignore */ }
    }

    return null;
  } catch {
    return null;
  }
}

export async function getSessionUserFromToken(tok: string | undefined | null): Promise<UserRow | null> {
  if (!tok) return null;
  try {
    const s = await db.select().from(sessions).where(eq(sessions.token, tok)).limit(1);
    if (!s[0] || s[0].expires < now()) return null;
    const rows = await db.select().from(users).where(eq(users.id, s[0].userId)).limit(1);
    return rows[0] ?? null;
  } catch {
    return null;
  }
}

export function newToken() {
  return "t" + randomBytes(24).toString("hex");
}

export async function createSession(userId: string) {
  const token = newToken();
  const csrf = randomBytes(16).toString("hex");
  await db.insert(sessions).values({ token, userId, csrf, expires: now() + 30 * 86400000 });
  try { await db.delete(sessions).where(lt(sessions.expires, now())); } catch { /* ignore */ }
  return { token, csrf };
}

export function setAuthCookie(res: NextResponse, token: string) {
  const isSecure = (process.env.BASE_URL || "").startsWith("https");
  res.cookies.set("gtok", token, {
    path: "/",
    httpOnly: true,
    sameSite: isSecure ? "none" : "lax",
    secure: isSecure,
    maxAge: 30 * 86400,
  });
  res.cookies.set("gm_session", token, {
    path: "/",
    httpOnly: true,
    sameSite: isSecure ? "none" : "lax",
    secure: isSecure,
    maxAge: 30 * 86400,
  });
  res.headers.set("x-gamify-token", token);
  return res;
}

export function json(data: unknown, status = 200) {
  return NextResponse.json(data, { status, headers: { "Cache-Control": "no-store" } });
}
