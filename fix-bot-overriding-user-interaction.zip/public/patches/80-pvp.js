/* ⚔️ نبرد واقعی بازیکن‌به‌بازیکن (PvP) — دعوت/پذیرش/پاسخ/نتیجه همه از سرور
   - وقتی به یک بازیکن واقعی دعوت می‌فرستی، باندل اصلی `window.__gamifyPvpInvite` را صدا می‌زند (به‌جای شبیه‌سازی)
   - حریف واقعی از پنل ⚔️ دعوت را می‌بیند و می‌پذیرد؛ هر دو نفر همان سؤال‌ها را جداگانه جواب می‌دهند
   - امتیازدهی و نتیجه فقط سمت سرور محاسبه می‌شود */
(function () {
  "use strict";
  if (window.__gamifyPvp) return;
  window.__gamifyPvp = true;

  var LS_KEY = "gamify2-store-v2";
  var CATS = {
    safety: "ایمنی و نجات", electric: "دنیای برق", general: "اطلاعات عمومی", science: "علم و شگفتی",
    technology: "فناوری و آینده", work: "تجربه‌های کاری", nature: "زمین و زندگی", sport: "ورزش و سرگرمی",
    geography: "جغرافیا و سفر", history: "تاریخ و تمدن", literature: "ادبیات فارسی", math: "ریاضی و منطق",
    space: "نجوم و فضا", art: "هنر و طراحی", music: "موسیقی", cinema: "سینما و روایت", food: "آشپزی و خوراک",
    animals: "دنیای جانوران", english: "زبان انگلیسی", engineering: "مهندسی و ابزار"
  };
  function catName(id) { return CATS[id] || id || "اطلاعات عمومی"; }

  var S = {
    overlay: null, quizOv: null,
    inbox: null, me: null, badge: 0,
    waiting: null,        // نبردی که منتظر پذیرش حریفم
    watching: null,       // نبردی که منتظر جواب حریف پس از پاسخ منم
    quiz: null,           // { battle, qs, idx, answers, startedAt, locked, timerInt }
    result: null,
    openInviteIds: {},    // دعوت‌هایی که مودالشان باز است
    promptedActive: {},   // نبردهای فعالی که برایشان پیشنهاد شروع داده شده
    playersCache: [], playersAt: 0, tab: "invites",
    pollInt: null, stateInt: null
  };

  function readStore() { try { return JSON.parse(localStorage.getItem(LS_KEY) || "null"); } catch (e) { return null; } }
  function esc(s) { return String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }
  function fa(n) { try { return Number(n || 0).toLocaleString("fa-IR"); } catch (e) { return String(n || 0); } }
  function toast(m) {
    try { if (window.__gamifyToast) return window.__gamifyToast(m); } catch (e) {}
    try {
      var d = document.createElement("div");
      d.textContent = m;
      d.style.cssText = "position:fixed;bottom:86px;right:16px;z-index:99999;background:#241a33;color:#fff;padding:10px 16px;border-radius:14px;font-size:13px;box-shadow:0 8px 30px rgba(0,0,0,.4);border:1px solid #a98cf7;font-family:Vazirmatn,sans-serif;";
      document.body.appendChild(d);
      setTimeout(function () { d.style.transition = "opacity .4s"; d.style.opacity = "0"; setTimeout(function(){ d.remove(); }, 450); }, 3000);
    } catch (e) {}
  }
  function jingle() { try { if (window.__gamifyConfetti) window.__gamifyConfetti(); } catch (e) {} }
  function loggedIn() {
    try { if (window.__gamifySession && window.__gamifySession.isLoggedIn()) return true; } catch (e) {}
    var st = readStore(); return !!(st && st.profile && st.profile.id);
  }
  function api(path, method, body) {
    var ready = window.__gamifyServer && window.__gamifyServer.ensureSynced ? window.__gamifyServer.ensureSynced() : Promise.resolve();
    return ready.then(function () {
      return fetch(path, { method: method || "GET", credentials: "include", headers: { "Content-Type": "application/json" }, body: body ? JSON.stringify(body) : undefined })
        .then(function (r) { return r.json().then(function (j) { return { status: r.status, body: j }; }); });
    }).catch(function () { return { status: 0, body: { error: "network" } }; });
  }
  function avatarHtml(av, name, size) {
    var seed = 1;
    if (typeof av === "number") seed = av;
    else if (av && typeof av === "object" && av.seed) seed = av.seed;
    if (seed < 1 || seed > 10) seed = 1;
    var ini = esc(String(name || "؟").trim().slice(0, 1) || "؟");
    return '<div class="pvp-av" style="width:' + size + "px;height:" + size + 'px">' +
      '<img src="/assets/avatars/' + seed + '.svg" alt="" loading="lazy" onerror="this.remove()"><span>' + ini + "</span></div>";
  }

  // ================= پنل اصلی (ورودی‌ها / در جریان / نتایج / بازیکنان) =================
  function ensureOverlay() {
    if (S.overlay) return S.overlay;
    var ov = document.createElement("div");
    ov.className = "gamify-overlay pvp-overlay";
    ov.id = "gamify-pvp-overlay";
    ov.addEventListener("click", function (e) { if (e.target === ov) closePanel(); });
    document.body.appendChild(ov);
    S.overlay = ov;
    return ov;
  }
  function openPanel() {
    var ov = ensureOverlay();
    ov.classList.add("open");
    renderPanel();
    refreshInbox(true);
    loadPlayers();
  }
  function closePanel() { if (S.overlay) S.overlay.classList.remove("open"); }

  function badgeCount() {
    if (!S.inbox) return 0;
    var n = (S.inbox.incoming || []).length;
    (S.inbox.active || []).forEach(function (b) { if (!b.myDone) n++; });
    (S.inbox.results || []).forEach(function (b) { if (!b.seen) n++; });
    return n;
  }
  function updateFabBadge() {
    var b = document.getElementById("gamify-pvp-fab");
    if (!b) return;
    var old = b.querySelector(".gamify-fab-badge");
    if (old) old.remove();
    var n = badgeCount();
    if (n > 0) { var s = document.createElement("span"); s.className = "gamify-fab-badge"; s.textContent = fa(n); b.appendChild(s); }
  }

  function rowUser(u) {
    return '<div class="pvp-user">' + avatarHtml(u.avatar, u.name, 46) +
      '<div class="pvp-user-i"><b>' + esc(u.name) + '</b><span>' + (u.online ? "🟢 آنلاین" : "⚪ آفلاین") + ' · ⭐ ' + fa(u.xp || 0) + ' · 🏆 ' + fa(u.wins || 0) + "</span></div></div>";
  }

  function panelHtml() {
    var d = S.inbox || { incoming: [], outgoing: [], active: [], results: [] };
    var tabs = [["invites", "📨 دعوت‌ها (" + fa(d.incoming.length) + ")"], ["active", "⚔️ در جریان"], ["results", "🏁 نتایج"], ["players", "🧑‍🤝‍🧑 بازیکنان"]];
    var head = '<div class="gamify-modal-head"><b>⚔️ نبرد واقعی (بازیکن‌به‌بازیکن)</b><button data-act="close" class="gamify-btn sm">✕</button></div>';
    var tabsHtml = '<div class="gamify-tabs">' + tabs.map(function (t) {
      return '<button class="gamify-btn sm ' + (S.tab === t[0] ? "primary" : "") + '" data-act="tab" data-tab="' + t[0] + '">' + t[1] + "</button>";
    }).join("") + "</div>";
    var body = "";

    if (S.tab === "invites") {
      if (!d.incoming.length && !d.outgoing.length) body = '<div class="gamify-empty"><div style="font-size:44px;">🕊️</div><p>دعوت تازه‌ای نداری.<br>از تب «بازیکنان» یکی از بازیکنان واقعی را به نبرد بخوان!</p></div>';
      d.incoming.forEach(function (b) {
        body += '<div class="pvp-card">' + rowUser(b.opponent) +
          '<div class="pvp-cat">📚 دسته: ' + esc(catName(b.category)) + "</div>" +
          '<div class="pvp-acts"><button class="gamify-btn primary sm" data-act="accept" data-id="' + b.id + '">✅ قبول نبرد</button>' +
          '<button class="gamify-btn sm" data-act="decline" data-id="' + b.id + '">❌ رد</button></div></div>';
      });
      d.outgoing.forEach(function (b) {
        body += '<div class="pvp-card waiting-card">' + rowUser(b.opponent) +
          '<div class="pvp-cat">⏳ در انتظار پذیرش… 📚 ' + esc(catName(b.category)) + "</div>" +
          '<div class="pvp-acts"><button class="gamify-btn sm" data-act="cancel" data-id="' + b.id + '">لغو دعوت</button></div></div>';
      });
    } else if (S.tab === "active") {
      if (!d.active.length) body = '<div class="gamify-empty"><div style="font-size:44px;">⚔️</div><p>نبرد فعالی نداری.</p></div>';
      d.active.forEach(function (b) {
        var st = b.myDone ? (b.oppDone ? "در حال ثبت نتیجه…" : "⏳ منتظر پاسخ حریف…") : (b.oppDone ? "🔥 حریف تمام کرده — نوبت تو!" : "🎯 آماده برای شروع");
        body += '<div class="pvp-card">' + rowUser(b.opponent) +
          '<div class="pvp-cat">📚 ' + esc(catName(b.category)) + " · " + st + "</div>" +
          '<div class="pvp-acts">' +
          (!b.myDone ? '<button class="gamify-btn primary sm" data-act="play" data-id="' + b.id + '">🎮 شروع/ادامهٔ نبرد</button>' : '<button class="gamify-btn sm" data-act="watch" data-id="' + b.id + '">👀 پیگیری نتیجه</button>') +
          "</div></div>";
      });
    } else if (S.tab === "results") {
      if (!d.results.length) body = '<div class="gamify-empty"><div style="font-size:44px;">🏁</div><p>هنوز نتیجه‌ای ثبت نشده.</p></div>';
      d.results.forEach(function (b) {
        var r = !b.winnerId ? "مساوی ⚖️" : (b.winnerId === S.me ? "بردی 🏆" : "باختی 💪");
        body += '<div class="pvp-card ' + (!b.seen ? "unseen" : "") + '">' + rowUser(b.opponent) +
          '<div class="pvp-cat">' + r + " · " + fa(b.myScore || 0) + " برابر " + fa(b.oppScore || 0) + " · 📚 " + esc(catName(b.category)) + "</div>" +
          '<div class="pvp-acts"><button class="gamify-btn primary sm" data-act="show-result" data-id="' + b.id + '">📊 جزئیات</button>' +
          '<button class="gamify-btn sm" data-act="rematch" data-id="' + b.id + '">🔁 مبارزهٔ مجدد</button></div></div>';
      });
    } else {
      if (!S.playersCache.length) body = '<div class="gamify-loading">در حال دریافت بازیکنان واقعی…</div>';
      var others = S.playersCache.filter(function (p) { return p && p.id !== S.me; });
      if (S.playersCache.length && !others.length) body = '<div class="gamify-empty"><div style="font-size:44px;">🌱</div><p>فعلاً بازیکن واقعی دیگری وارد نشده؛ دوستت را به بازی دعوت کن!</p></div>';
      body += '<div class="pvp-hint">💡 بازیکن واقعی را انتخاب کن، دسته را بگذار و دعوت نبرد واقعی بفرست — جواب را خودش می‌دهد، نه ربات!</div>';
      others.forEach(function (p) {
        body += '<div class="pvp-card">' + rowUser(p) +
          '<div class="pvp-acts"><select class="pvp-sel" data-cat-for="' + esc(p.id) + '">' +
          Object.keys(CATS).map(function (c) { return '<option value="' + c + '"' + (c === "general" ? " selected" : "") + ">" + CATS[c] + "</option>"; }).join("") +
          '</select><button class="gamify-btn primary sm" data-act="invite" data-id="' + esc(p.id) + '">⚔️ دعوت</button></div></div>';
      });
    }
    return '<div class="gamify-modal pvp-modal">' + head + '<div style="height:10px"></div>' + tabsHtml + '<div class="gamify-body pvp-body">' + body + "</div></div>";
  }

  function renderPanel() {
    var ov = ensureOverlay();
    if (!ov.classList.contains("open")) return;
    if (!loggedIn()) {
      ov.innerHTML = '<div class="gamify-modal"><div class="gamify-modal-head"><b>⚔️ نبرد واقعی</b><button data-act="close" class="gamify-btn sm">✕</button></div><div class="gamify-empty"><div style="font-size:52px;">🌱</div><h3>ابتدا وارد بازی شو</h3><p>برای نبرد واقعی باید حساب داشته باشی.</p></div></div>';
      bindPanel(ov); return;
    }
    ov.innerHTML = panelHtml();
    bindPanel(ov);
  }

  function bindPanel(ov) {
    ov.querySelectorAll("[data-act]").forEach(function (el) {
      el.addEventListener("click", function () {
        var act = el.getAttribute("data-act");
        var id = el.getAttribute("data-id");
        if (act === "close") return closePanel();
        if (act === "tab") { S.tab = el.getAttribute("data-tab"); return renderPanel(); }
        if (act === "accept") return doAccept(id);
        if (act === "decline") return doSimple(id, "decline", "دعوت رد شد.");
        if (act === "cancel") return doSimple(id, "cancel", "دعوت لغو شد.");
        if (act === "play") return openQuizFromState(id);
        if (act === "watch") return watchResult(id, true);
        if (act === "show-result") return showResultById(id);
        if (act === "rematch") return doRematch(id);
        if (act === "invite") {
          var sel = ov.querySelector('select[data-cat-for="' + id + '"]');
          var cat = sel ? sel.value : "general";
          var p = S.playersCache.filter(function (x) { return String(x.id) === String(id); })[0];
          return sendInvite(p ? p.id : id, p ? p.name : "بازیکن", p ? p.avatar : null, cat);
        }
      });
    });
  }

  // ================= جریان نبرد =================
  function sendInvite(toId, name, avatar, category) {
    toast("⚔️ در حال ارسال دعوت واقعی…");
    api("/api/pvp?action=invite", "POST", { to: toId, category: category }).then(function (r) {
      if (!r.body || r.body.error) { toast("⚠️ " + ((r.body && (r.body.message || r.body.error)) || "خطا در ارسال دعوت")); return null; }
      var b = r.body.battle;
      startWaiting(b);
      return null;
    });
  }

  // نقطهٔ ورود از باندل اصلی (دکمهٔ «دعوت به مسابقه» روی بازیکن واقعی)
  window.__gamifyPvpInvite = function (player, category) {
    if (!player || !player.id) return;
    sendInvite(player.id, player.name, player.avatar, category || "general");
  };

  function doAccept(id) {
    api("/api/pvp?action=accept", "POST", { id: id }).then(function (r) {
      if (!r.body || r.body.error) { toast("⚠️ " + ((r.body && (r.body.message || r.body.error)) || "خطا")); return refreshInbox(true); }
      toast("✅ نبرد پذیرفته شد — بزن بریم!");
      openQuiz(r.body.battle);
    });
  }
  function doSimple(id, action, msg) {
    api("/api/pvp?action=" + action, "POST", { id: id }).then(function () {
      toast(msg);
      var mo = document.getElementById("pvp-invite-modal");
      if (mo) mo.remove();
      delete S.openInviteIds[id];
      refreshInbox(true);
    });
  }
  function doRematch(id) {
    api("/api/pvp?action=rematch", "POST", { id: id }).then(function (r) {
      if (!r.body || r.body.error) { toast("⚠️ " + ((r.body && (r.body.message || r.body.error)) || "خطا")); return null; }
      closeResultModal();
      startWaiting(r.body.battle);
      return null;
    });
  }

  // ---- انتظار پذیرش (چالش‌گر) ----
  function startWaiting(battle) {
    S.waiting = battle;
    renderWaiting();
    if (S.stateInt) clearInterval(S.stateInt);
    S.stateInt = setInterval(function () {
      api("/api/pvp?action=state&id=" + encodeURIComponent(battle.id)).then(function (r) {
        if (!r.body || r.body.error) return;
        var st = r.body;
        if (st.status === "accepted") {
          clearInterval(S.stateInt); S.stateInt = null; S.waiting = null;
          closeWaiting();
          toast("✅ " + (st.opponent.name || "حریف") + " پذیرفت — نوبت تو!");
          openQuiz(st);
        } else if (st.status === "declined") {
          clearInterval(S.stateInt); S.stateInt = null; S.waiting = null;
          closeWaiting();
          toast("❌ " + (st.opponent.name || "حریف") + " الان برای نبرد آماده نیست.");
          refreshInbox(true);
        } else if (st.status === "expired" || st.status === "cancelled") {
          clearInterval(S.stateInt); S.stateInt = null; S.waiting = null;
          closeWaiting();
          toast("⌛ دعوتت بی‌پاسخ ماند؛ دوباره تلاش کن.");
          refreshInbox(true);
        }
      });
    }, 1800);
  }
  function renderWaiting() {
    closeWaiting();
    var b = S.waiting;
    if (!b) return;
    var d = document.createElement("div");
    d.id = "pvp-waiting-modal";
    d.className = "pvp-mini-overlay";
    d.innerHTML = '<div class="gamify-modal pvp-mini">' +
      '<div class="pvp-versus">' + avatarHtml(b.opponent.avatar, b.opponent.name, 84) + '<div class="pvp-swords">⚔️</div></div>' +
      '<h3>در انتظار پذیرش ' + esc(b.opponent.name) + "…</h3>" +
      '<p class="pvp-sub">📚 دسته: ' + esc(catName(b.category)) + " · دعوت واقعی فرستاده شد؛ وقتی قبول کند نبرد شروع می‌شود.</p>" +
      '<div class="pvp-dots"><i></i><i></i><i></i></div>' +
      '<button class="gamify-btn sm" data-cancel="1">لغو دعوت</button></div>';
    document.body.appendChild(d);
    d.querySelector("[data-cancel]").addEventListener("click", function () {
      api("/api/pvp?action=cancel", "POST", { id: b.id });
      if (S.stateInt) { clearInterval(S.stateInt); S.stateInt = null; }
      S.waiting = null;
      closeWaiting();
      toast("دعوت لغو شد.");
    });
  }
  function closeWaiting() { var d = document.getElementById("pvp-waiting-modal"); if (d) d.remove(); }

  // ================= کوییز =================
  function ensureQuizOverlay() {
    if (S.quizOv) return S.quizOv;
    var ov = document.createElement("div");
    ov.className = "gamify-overlay pvp-quiz-overlay";
    ov.id = "gamify-pvp-quiz";
    document.body.appendChild(ov);
    S.quizOv = ov;
    return ov;
  }
  function openQuizFromState(id) {
    api("/api/pvp?action=state&id=" + encodeURIComponent(id)).then(function (r) {
      if (!r.body || r.body.error) { toast("⚠️ " + ((r.body && (r.body.message || r.body.error)) || "خطا")); return null; }
      var st = r.body;
      if (st.status === "finished") return showResult(st), null;
      if (!st.questions || !st.questions.length) { toast("⚠️ سؤال‌ها هنوز آماده نیست؛ کمی صبر کن."); return null; }
      openQuiz(st);
      return null;
    });
  }
  function openQuiz(battle) {
    if (!battle.questions || !battle.questions.length) { toast("⚠️ سؤال‌ها آماده نیست."); return; }
    var ov = ensureQuizOverlay();
    ov.classList.add("open");
    S.quiz = { battle: battle, qs: battle.questions, idx: 0, answers: [], locked: false, startedAt: Date.now(), timerInt: null, qStart: Date.now() };
    renderQ();
  }
  function closeQuiz() {
    if (S.quiz && S.quiz.timerInt) clearInterval(S.quiz.timerInt);
    S.quiz = null;
    if (S.quizOv) S.quizOv.classList.remove("open");
  }
  function renderQ() {
    var q = S.quiz;
    if (!q) return;
    clearInterval(q.timerInt);
    var item = q.qs[q.idx];
    var secs = Math.max(8, Math.min(60, item.seconds || 25));
    q.qStart = Date.now();
    q.locked = false;
    var ov = S.quizOv;
    var dots = q.qs.map(function (_, i) {
      return '<i class="' + (i < q.idx ? "done" : i === q.idx ? "cur" : "") + '"></i>';
    }).join("");
    ov.innerHTML = '<div class="gamify-modal pvp-quiz">' +
      '<div class="gamify-modal-head"><b>⚔️ نبرد با ' + esc(q.battle.opponent.name) + '</b><span class="pvp-count">' + fa(q.idx + 1) + " / " + fa(q.qs.length) + '</span><button class="gamify-btn sm" data-exit="1">خروج ↩</button></div>' +
      '<div class="pvp-progress">' + dots + "</div>" +
      '<div class="pvp-timerbar"><i id="pvp-timer-fill"></i></div>' +
      '<h3 class="pvp-qtitle">' + esc(item.title) + "</h3>" +
      '<div class="pvp-opts">' + item.options.map(function (op, i) {
        return '<button class="pvp-opt" data-i="' + i + '"><span class="pvp-opt-key">' + ["۱", "۲", "۳", "۴"][i] + "</span>" + esc(op) + "</button>";
      }).join("") + "</div>" +
      '<div class="pvp-hint center">پاسخت فقط برای سرور می‌رود — امتیاز = صحت + سرعت ⚡</div></div>';
    ov.querySelectorAll(".pvp-opt").forEach(function (btn) {
      btn.addEventListener("click", function () { pick(parseInt(btn.getAttribute("data-i"), 10)); });
    });
    var exitBtn = ov.querySelector("[data-exit]");
    if (exitBtn) exitBtn.addEventListener("click", function () {
      var bid = q.battle.id;
      closeQuiz();
      toast("بازی نیمه‌تمام ماند؛ از پنل ⚔️ تب «در جریان» ادامه‌اش بده.");
      S.promptedActive[bid] = 1;
      refreshInbox(true);
    });
    var fill = ov.querySelector("#pvp-timer-fill");
    q.timerInt = setInterval(function () {
      var el = Date.now() - q.qStart;
      var left = Math.max(0, secs * 1000 - el);
      if (fill) fill.style.width = (left / (secs * 1000) * 100) + "%";
      if (left <= 3000 && fill) fill.classList.add("low");
      if (left <= 0) { pick(-1); }
    }, 100);
  }
  function pick(i) {
    var q = S.quiz;
    if (!q || q.locked) return;
    q.locked = true;
    clearInterval(q.timerInt);
    var t = Date.now() - q.qStart;
    q.answers.push({ i: i, t: t });
    var ov = S.quizOv;
    if (i >= 0) {
      var btn = ov.querySelector('.pvp-opt[data-i="' + i + '"]');
      if (btn) btn.classList.add("picked");
    } else {
      var tt = ov.querySelector(".pvp-qtitle");
      if (tt) tt.insertAdjacentHTML("afterend", '<div class="pvp-timeout">⏰ وقتت تمام شد!</div>');
    }
    q.idx++;
    if (q.idx < q.qs.length) { setTimeout(renderQ, 500); }
    else {
      ov.innerHTML = '<div class="gamify-modal pvp-quiz"><div class="gamify-loading">📤 در حال ارسال پاسخ‌ها به سرور…</div></div>';
      submitAnswers();
    }
  }
  function submitAnswers() {
    var q = S.quiz;
    api("/api/pvp?action=submit", "POST", { id: q.battle.id, answers: q.answers }).then(function (r) {
      var b = r.body && r.body.battle;
      closeQuiz();
      if (!r.body || r.body.error || !b) { toast("⚠️ ارسال پاسخ‌ها ناموفق بود؛ از پنل ⚔️ پیگیری کن."); refreshInbox(true); return null; }
      if (b.status === "finished" && b.result) { showResult(b); refreshInbox(true); return null; }
      toast("🎯 پاسخ‌هایت ثبت شد؛ منتظر حریف…");
      watchResult(b.id, false);
      return null;
    });
  }

  // ---- انتظار نتیجه (هرکس زودتر تمام کرده) ----
  function watchResult(id, fromPanel) {
    S.watching = id;
    if (fromPanel) closePanel();
    renderWatching();
    if (S.stateInt) clearInterval(S.stateInt);
    S.stateInt = setInterval(function () {
      api("/api/pvp?action=state&id=" + encodeURIComponent(id)).then(function (r) {
        if (!r.body || r.body.error) return;
        if (r.body.status === "finished" && r.body.result) {
          clearInterval(S.stateInt); S.stateInt = null; S.watching = null;
          closeWatching();
          showResult(r.body);
          refreshInbox(true);
        }
      });
    }, 2500);
  }
  function renderWatching() {
    closeWatching();
    var d = document.createElement("div");
    d.id = "pvp-watching-modal";
    d.className = "pvp-mini-overlay";
    d.innerHTML = '<div class="gamify-modal pvp-mini"><div class="pvp-swords big">⚔️</div>' +
      "<h3>پاسخ‌هایت ثبت شد!</h3><p class=\"pvp-sub\">حریفت هنوز دارد بازی می‌کند؛ به‌محض تمام شدن، نتیجه همین‌جا می‌آید.</p>" +
      '<div class="pvp-dots"><i></i><i></i><i></i></div>' +
      '<button class="gamify-btn sm" data-close="1">بستن (نتیجه در پنل ⚔️ می‌آید)</button></div>';
    document.body.appendChild(d);
    d.querySelector("[data-close]").addEventListener("click", function () {
      closeWatching();
    });
  }
  function closeWatching() { var d = document.getElementById("pvp-watching-modal"); if (d) d.remove(); }

  // ---- مودال نتیجه ----
  function showResultById(id) {
    api("/api/pvp?action=state&id=" + encodeURIComponent(id)).then(function (r) {
      if (!r.body || r.body.error || !r.body.result) { toast("⚠️ نتیجه هنوز آماده نیست."); return null; }
      showResult(r.body);
      return null;
    });
  }
  function showResult(b) {
    closeWatching();
    closeWaiting();
    var res = b.result;
    var iWon = res.winnerId && res.winnerId === S.me;
    var draw = !res.winnerId;
    var title = draw ? "مساوی شدید! ⚖️" : iWon ? "بردی! 🏆" : "این دور را باختی 💪";
    var cls = draw ? "draw" : iWon ? "win" : "lose";
    if (S.overlay && S.overlay.classList.contains("open")) S.overlay.classList.remove("open");
    var old = document.getElementById("pvp-result-modal");
    if (old) old.remove();
    var d = document.createElement("div");
    d.id = "pvp-result-modal";
    d.className = "pvp-mini-overlay";
    var per = res.perQ.map(function (q, i) {
      var myOk = q.myPick === q.correct;
      var opOk = q.oppPick === q.correct;
      return '<div class="pvp-perq">' +
        '<div class="t">' + esc(q.title) + "</div>" +
        '<div class="r"><span class="' + (myOk ? "ok" : "no") + '">' + (myOk ? "✅" : "❌") + " تو: " + (q.myPick >= 0 ? esc(q.options[q.myPick]) : "—") + " (+" + fa(q.myPts) + ')</span>' +
        '<span class="' + (opOk ? "ok" : "no") + '">' + (opOk ? "✅" : "❌") + " حریف: " + (q.oppPick >= 0 ? esc(q.options[q.oppPick]) : "—") + " (+" + fa(q.oppPts) + ")</span></div>" +
        (!myOk ? '<div class="corr">پاسخ درست: ' + esc(q.options[q.correct]) + (q.explanation ? " — " + esc(q.explanation) : "") + "</div>" : "") +
        "</div>";
    }).join("");
    d.innerHTML = '<div class="gamify-modal pvp-result ' + cls + '">' +
      '<div class="gamify-modal-head"><b>' + title + '</b><button data-x="1" class="gamify-btn sm">✕</button></div>' +
      '<div class="pvp-score-row">' +
        '<div class="pvp-side me"><div class="lbl">تو</div><div class="sc">' + fa(res.myScore) + '</div><div class="cc">✅ ' + fa(res.myCorrect) + " از " + fa(res.perQ.length) + "</div></div>" +
        '<div class="pvp-vs">VS</div>' +
        '<div class="pvp-side op"><div class="lbl">' + esc(b.opponent.name) + '</div><div class="sc">' + fa(res.oppScore) + '</div><div class="cc">✅ ' + fa(res.oppCorrect) + " از " + fa(res.perQ.length) + "</div></div>" +
      "</div>" +
      '<div class="pvp-hint center">+ امتیاز تجربه و سکهٔ نبرد به حسابت اضافه شد 🎁</div>' +
      '<div class="pvp-scroll">' + per + "</div>" +
      '<div class="pvp-acts center">' +
        '<button class="gamify-btn primary sm" data-rematch="' + b.id + '">🔁 مبارزهٔ مجدد</button>' +
        '<button class="gamify-btn sm" data-x="1">بستن</button>' +
      "</div></div>";
    document.body.appendChild(d);
    if (iWon) jingle();
    api("/api/pvp?action=ack", "POST", { id: b.id });
    d.querySelectorAll("[data-x]").forEach(function (el) { el.addEventListener("click", function () { closeResultModal(); }); });
    var rm = d.querySelector("[data-rematch]");
    if (rm) rm.addEventListener("click", function () { doRematch(b.id); });
    refreshInbox(true);
  }
  function closeResultModal() { var d = document.getElementById("pvp-result-modal"); if (d) d.remove(); }

  // ================= دعوت ورودی (مودال فوری) =================
  function showIncoming(b) {
    if (S.openInviteIds[b.id]) return;
    S.openInviteIds[b.id] = 1;
    var d = document.createElement("div");
    d.className = "pvp-mini-overlay";
    d.id = "pvp-invite-modal";
    d.innerHTML = '<div class="gamify-modal pvp-mini pvp-invite-in">' +
      '<div class="pvp-versus">' + avatarHtml(b.opponent.avatar, b.opponent.name, 84) + '<div class="pvp-swords">⚔️</div></div>' +
      "<h3>" + esc(b.opponent.name) + " تو را به نبرد واقعی دعوت کرد!</h3>" +
      '<p class="pvp-sub">📚 دسته: ' + esc(catName(b.category)) + " · ۵ سؤال · امتیاز = صحت + سرعت</p>" +
      '<div class="pvp-acts center"><button class="gamify-btn primary" data-a="1">✅ قبول نبرد</button><button class="gamify-btn" data-d="1">❌ رد</button></div></div>';
    document.body.appendChild(d);
    jingle();
    d.querySelector("[data-a]").addEventListener("click", function () {
      d.remove(); delete S.openInviteIds[b.id];
      doAccept(b.id);
    });
    d.querySelector("[data-d]").addEventListener("click", function () {
      doSimple(b.id, "decline", "دعوت رد شد.");
    });
    setTimeout(function () { if (document.body.contains(d)) { d.remove(); delete S.openInviteIds[b.id]; refreshInbox(true); } }, 60000);
  }

  // ================= حلقهٔ نظارت =================
  function refreshInbox(silent) {
    if (!loggedIn()) return;
    api("/api/pvp?action=inbox").then(function (r) {
      if (!r.body || r.body.error || Array.isArray(r.body)) return;
      var prev = S.inbox;
      S.inbox = r.body;
      S.me = r.body.me;
      updateFabBadge();
      (r.body.incoming || []).forEach(function (b) { showIncoming(b); });
      // دعوت‌های من که تازه پذیرفته شده‌اند (اگر در حال انتظار نباشم: مثلاً پس از رفرش صفحه)
      (r.body.active || []).forEach(function (b) {
        if (!b.myDone && !S.quiz && !S.waiting && !S.promptedActive[b.id]) {
          var wasPending = prev && (prev.outgoing || []).some(function (o) { return o.id === b.id; });
          if (wasPending) toast("✅ " + (b.opponent.name || "حریف") + " پذیرفت — از پنل ⚔️ نبرد را شروع کن!");
          S.promptedActive[b.id] = 1;
        }
      });
      // نتایج دیده‌نشدهٔ جدید → تست
      (r.body.results || []).forEach(function (b) {
        if (!b.seen && !S.watching && !document.getElementById("pvp-result-modal")) {
          var seenBefore = prev && (prev.results || []).some(function (o) { return o.id === b.id && !o.seen; });
          if (!seenBefore && prev) toast("🏁 نتیجهٔ نبرد با " + (b.opponent.name || "حریف") + " آمد — پنل ⚔️");
        }
      });
      if (!silent && S.overlay && S.overlay.classList.contains("open")) renderPanel();
      else if (S.overlay && S.overlay.classList.contains("open")) renderPanel();
    });
  }

  function loadPlayers() {
    if (Date.now() - S.playersAt < 30000 && S.playersCache.length) { renderPanel(); return; }
    api("/api/players?limit=80").then(function (r) {
      if (Array.isArray(r.body)) {
        S.playersCache = r.body.filter(function (p) { return p && !p.isDemo; }).map(function (p) {
          return { id: p.id, name: p.name, avatar: p.avatar, xp: p.xp, wins: p.wins, online: p.online };
        });
        S.playersAt = Date.now();
        if (S.tab === "players") renderPanel();
      }
    });
  }

  function mountFab() {
    if (document.getElementById("gamify-pvp-fab")) return;
    var b = document.createElement("button");
    b.id = "gamify-pvp-fab";
    b.textContent = "⚔️";
    b.title = "نبرد واقعی بازیکن‌به‌بازیکن";
    b.addEventListener("click", openPanel);
    document.body.appendChild(b);
  }

  function boot() {
    mountFab();
    setTimeout(function () { refreshInbox(true); }, 6000);
    S.pollInt = setInterval(function () { refreshInbox(true); }, 7000);
    setInterval(loadPlayers, 45000);
    document.addEventListener("visibilitychange", function () { if (!document.hidden) refreshInbox(true); });
    window.addEventListener("gamify:players", function () { S.playersAt = 0; });
    window.__gamifyPvpOpen = openPanel;
    console.log("%c[gamify] نبرد واقعی PvP فعال شد ⚔️", "color:#f2ca7c");
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot); else boot();
})();
