# راهنمای گام‌به‌گام راه‌اندازی نسخهٔ جدید گیمیفای ۲ روی `https://bu.gamifi.ir`

این بسته و اسکریپت‌ها دقیقاً بر اساس ساختار سرور شما (`86.107.47.228`) طراحی شده‌اند تا **هیچ آسیبی** به سایت‌های فعلی (`gamifi.ir`، `app.gamifi.ir`، `https://86.107.47.228/`، پوشه‌های `game`، `appgame`، `meshkat`، `gamnasr-deploy` و دیتابیس‌های قبلی) وارد نشود.

---

## مشخصات ایزولهٔ این نصب (کاملاً مستقل از سایر برنامه‌ها)
- **آدرس عمومی:** `https://bu.gamifi.ir/`
- **پورت داخلی برنامه:** `127.0.0.1:3105` (کاملاً جدا از پورت‌های `3000`، `3001` و `3102`)
- **سرویس systemd اختصاصی:** `bu-gamifi.service` (با کاربر محدود لینوکس `bugamifi`)
- **پوشهٔ آماده‌سازی (Staging):** `/root/bu-gamifi-deploy/incoming`
- **تنظیمات محیطی محرمانه:** `/root/bu-gamifi-deploy/app.env`
- **پوشهٔ اجرای زنده:** `/opt/bu-gamifi/app`
- **پوشهٔ بک‌آپ‌ها:** `/var/lib/bu-gamifi/backups`
- **دیتابیس اختصاصی PostgreSQL:** دیتابیس `bugamifi_db` با کاربر مجزای `bugamifi_user` (تا به دیتابیس‌های دیگر مثل `app_db` یا SQLiteهای قبلی مطلقاً دست نخورد)

---

## مرحلهٔ ۱: ثبت زیر دامنه `bu.gamifi.ir` در پنل دامنه (Cloudflare با اکانت گوگل)

بررسی DNS دامنهٔ `gamifi.ir` نشان می‌دهد که NameServerهای دامنهٔ شما روی **Cloudflare** (`rick.ns.cloudflare.com` و `ashley.ns.cloudflare.com`) تنظیم شده‌اند و احتمالاً با اکانت گوگل (**Continue with Google**) وارد آن می‌شوید:

1. وارد سایت **[dash.cloudflare.com](https://dash.cloudflare.com)** شوید و دکمهٔ **Continue with Google** را بزنید.
2. روی دامنهٔ **`gamifi.ir`** کلیک کنید.
3. از منوی سمت چپ وارد بخش **DNS** (زیربخش **Records**) شوید.
4. روی دکمهٔ آبی **Add record** کلیک کنید و این مقادیر را وارد نمایید:
   - **Type:** `A`
   - **Name (نام زیر دامنه):** `bu`
   - **IPv4 address:** `86.107.47.228`
   - **Proxy status:** آن را **خاموش** بگذارید (**DNS only / ابر خاکستری** — دقیقاً مشابه `gamifi.ir` و `app.gamifi.ir` تا گواهی HTTPS در سرور بدون خطا صادر شود).
5. دکمهٔ **Save** را بزنید.

---

## مرحلهٔ ۲: آپلود فایل‌ها در WinSCP (یا نصب مستقیم)

شما به دو روش می‌توانید فایل‌ها را در سرور قرار دهید:

### روش الف (پیشنهادی — آپلود بستهٔ آماده با WinSCP):
1. فایل فشردهٔ **`bu-gamifi-deploy.zip`** را روی کامپیوتر خود از حالت فشرده خارج (Extract) کنید.
2. در **WinSCP** (سمت راست که روی `/root/` هستید):
   - یک پوشه به نام `bu-gamifi-deploy` بسازید و واردش شوید.
   - داخل آن یک پوشه به نام `incoming` بسازید و واردش شوید (مسیر نهایی: `/root/bu-gamifi-deploy/incoming`).
3. محتویات استخراج‌شده (`package.json`، `package-lock.json`، `deploy.sh`، `update.sh`، `init-db.mjs`، پوشه‌های `src` و `public` و ...) را مستقیماً داخل `/root/bu-gamifi-deploy/incoming` بکشید و رها کنید.

---

## مرحلهٔ ۳: اجرای فرمان نصب در کنسول WinSCP

1. در نوار بالای WinSCP روی آیکون ترمینال سیاه‌رنگ (**Open Terminal** یا کلیدهای `Ctrl+T`) کلیک کنید.
2. در کادر **Enter command** دقیقاً این یک فرمان را کپی و **Execute** کنید:

```bash
cd /root/bu-gamifi-deploy/incoming && bash deploy.sh
```

*(نکته: اجرای این فرمان حدود ۱ تا ۲ دقیقه زمان می‌برد چون وابستگی‌ها را نصب و پروژهٔ Next.js را Build می‌کند؛ صبر کنید تا پیام `نصب با موفقیت کامل شد!` نمایش داده شود.)*

---

## مرحلهٔ ۴: برای آپدیت‌های بعدی `bu.gamifi.ir` چه کار کنیم؟

در نسخه‌های بعدی، فقط کافی است فایل‌های جدید را در WinSCP داخل پوشهٔ `/root/bu-gamifi-deploy/incoming` بریزید و در کنسول WinSCP این فرمان را بزنید:

```bash
cd /root/bu-gamifi-deploy/incoming && bash update.sh
```
اسکریپت `update.sh` به‌صورت خودکار از دیتابیس و نسخهٔ قبلی بک‌آپ زمان‌دار می‌گیرد، نسخهٔ جدید را تست و جایگزین می‌کند، و در صورت هرگونه خطا به نسخهٔ قبلی برمی‌گردد (Rollback).
