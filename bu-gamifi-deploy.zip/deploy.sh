#!/usr/bin/env bash
set -euo pipefail

# ==============================================================================
# اسکریپت نصب اولیه و امن سامانه گیمیفای ۲ روی زیر دامنه: bu.gamifi.ir
# پورت داخلی: 127.0.0.1:3105
# سرویس systemd: bu-gamifi.service (کاربر محدود: bugamifi)
# مسیر اجرای زنده: /opt/bu-gamifi/app
# مسیر داده و بک‌آپ: /var/lib/bu-gamifi
# تنظیمات محیطی: /root/bu-gamifi-deploy/app.env
# دیتابیس اختصاصی PostgreSQL: bugamifi_db (کاربر: bugamifi_user)
# بدون هیچ‌گونه تغییر در سرویس‌ها، پورت‌ها، Nginx یا دیتابیس‌های قبلی سرور
# ==============================================================================

export DEBIAN_FRONTEND=noninteractive
export CI=true
export NEXT_TELEMETRY_DISABLED=1

DOMAIN="bu.gamifi.ir"
APP_PORT="3105"
SERVICE_NAME="bu-gamifi.service"
APP_USER="bugamifi"
DEPLOY_ROOT="/root/bu-gamifi-deploy"
INCOMING_DIR="${DEPLOY_ROOT}/incoming"
ENV_FILE="${DEPLOY_ROOT}/app.env"
LIVE_ROOT="/opt/bu-gamifi"
LIVE_APP="${LIVE_ROOT}/app"
DATA_ROOT="/var/lib/bu-gamifi"
BACKUP_DIR="${DATA_ROOT}/backups"
DB_NAME="bugamifi_db"
DB_USER="bugamifi_user"
REPO_URL="https://github.com/hamid-821/servnew5.5"
TIMESTAMP="$(date +%Y%m%d-%H%M%S)"

echo "============================================================"
echo " شروع نصب امن گیمیفای ۲ روی دامنه ${DOMAIN} (پورت ${APP_PORT})"
echo "============================================================"

if [ "$(id -u)" -ne 0 ]; then
  echo "[خطا] لطفاً این اسکریپت را با کاربر root اجرا کنید."
  exit 1
fi

# ۱) بررسی ابزارهای پایه و پورت 3105
echo "[۱/۹] پیش‌بررسی فقط‌خواندنی پورت‌ها و سرویس‌های فعلی..."
for cmd in node npm nginx curl ss; do
  if ! command -v "$cmd" >/dev/null 2>&1; then
    echo "[خطا] ابزار ضروری '$cmd' روی سرور یافت نشد."
    exit 1
  fi
done

PORT_CHECK="$(ss -tulpn | grep -E ":${APP_PORT}\b" || true)"
if [ -n "$PORT_CHECK" ]; then
  if ! systemctl is-active --quiet "$SERVICE_NAME" 2>/dev/null; then
    echo "[توقف ایمن] پورت ${APP_PORT} توسط فرایند دیگری اشغال است:"
    echo "$PORT_CHECK"
    echo "هیچ تغییری اعمال نشد."
    exit 1
  else
    echo "پورت ${APP_PORT} در اختیار سرویس فعلی ${SERVICE_NAME} است."
  fi
else
  echo "پورت 127.0.0.1:${APP_PORT} آزاد است."
fi

# ۲) اطمینان از آماده بودن فایل‌های پروژه در پوشه incoming
echo "[۲/۹] بررسی فایل‌های پروژه در ${INCOMING_DIR}..."
mkdir -p "$INCOMING_DIR"
cd "$INCOMING_DIR"

if [ ! -f "${INCOMING_DIR}/package.json" ] || [ ! -d "${INCOMING_DIR}/src" ]; then
  echo "فایل‌های استخراج‌شده در ${INCOMING_DIR} دیده نشد؛ دریافت خودکار از مخزن ${REPO_URL}..."
  if ! command -v unzip >/dev/null 2>&1 || ! command -v git >/dev/null 2>&1; then
    apt-get update -y && apt-get install -y unzip git
  fi
  TMP_CLONE="${DEPLOY_ROOT}/tmp-clone-${TIMESTAMP}"
  git clone --depth 1 "$REPO_URL" "$TMP_CLONE"
  if [ -f "${TMP_CLONE}/game-deployment-and-bug-fixes.zip" ]; then
    unzip -q -o "${TMP_CLONE}/game-deployment-and-bug-fixes.zip" -d "$INCOMING_DIR"
  else
    cp -a "${TMP_CLONE}/." "$INCOMING_DIR/"
  fi
  mv "$TMP_CLONE" "${DEPLOY_ROOT}/repo-archive-${TIMESTAMP}" 2>/dev/null || true
fi

if [ ! -f "${INCOMING_DIR}/package.json" ] || [ ! -f "${INCOMING_DIR}/src/db/schema.ts" ]; then
  echo "[خطا] ساختار پروژه در ${INCOMING_DIR} کامل نیست (package.json یا src/db/schema.ts یافت نشد)."
  exit 1
fi

# اطمینان از وجود اسکریپت init-db.mjs برای ساخت غیرمخرب جدول‌ها
if [ ! -f "${INCOMING_DIR}/init-db.mjs" ]; then
  cat > "${INCOMING_DIR}/init-db.mjs" << 'EOF_INIT_DB'
import pg from "pg";
const { Pool } = pg;
const databaseUrl = process.env.DATABASE_URL;
if (!databaseUrl) { console.error("DATABASE_URL is required"); process.exit(1); }
const SCHEMA_SQL = `
CREATE TABLE IF NOT EXISTS "achievements" ("id" text PRIMARY KEY NOT NULL, "title" text NOT NULL, "description" text DEFAULT '', "icon" text DEFAULT '🏆', "xp_reward" integer DEFAULT 50, "coin_reward" integer DEFAULT 25);
CREATE TABLE IF NOT EXISTS "audit_log" ("id" integer PRIMARY KEY GENERATED ALWAYS AS IDENTITY, "actor" text DEFAULT '', "action" text DEFAULT '', "target" text DEFAULT '', "created_at" bigint NOT NULL);
CREATE TABLE IF NOT EXISTS "categories" ("id" text PRIMARY KEY NOT NULL, "name" text NOT NULL, "subtitle" text DEFAULT '', "icon" text DEFAULT 'globe', "color" text DEFAULT '#a98cf7', "tag" text DEFAULT '', "safety" integer DEFAULT 0, "active" integer DEFAULT 1);
CREATE TABLE IF NOT EXISTS "daily_claims" ("user_id" text NOT NULL, "day" text NOT NULL, "coins" integer DEFAULT 25, "streak" integer DEFAULT 1, "created_at" bigint NOT NULL, CONSTRAINT "daily_claims_user_id_day_pk" PRIMARY KEY("user_id","day"));
CREATE TABLE IF NOT EXISTS "follows" ("user_id" text NOT NULL, "target_id" text NOT NULL, "status" text DEFAULT 'approved', CONSTRAINT "follows_user_id_target_id_pk" PRIMARY KEY("user_id","target_id"));
CREATE TABLE IF NOT EXISTS "messages" ("id" text PRIMARY KEY NOT NULL, "sender" text NOT NULL, "recipient" text NOT NULL, "body" text DEFAULT '', "media" text DEFAULT '', "created_at" bigint NOT NULL, "seen" integer DEFAULT 0);
CREATE TABLE IF NOT EXISTS "notifications" ("id" text PRIMARY KEY NOT NULL, "user_id" text NOT NULL, "title" text NOT NULL, "body" text DEFAULT '', "link" text DEFAULT '', "created_at" bigint NOT NULL, "seen" integer DEFAULT 0);
CREATE TABLE IF NOT EXISTS "org_members" ("org_id" text NOT NULL, "user_id" text NOT NULL, "status" text DEFAULT 'approved', "joined_at" bigint NOT NULL, CONSTRAINT "org_members_org_id_user_id_pk" PRIMARY KEY("org_id","user_id"));
CREATE TABLE IF NOT EXISTS "organizations" ("id" text PRIMARY KEY NOT NULL, "name" text NOT NULL, "slug" text DEFAULT '' NOT NULL, "description" text DEFAULT '', "logo" text DEFAULT '⚡', "color" text DEFAULT '#f8c56c', "auto_tournament" boolean DEFAULT true, "member_count" integer DEFAULT 0, "created_at" bigint NOT NULL);
CREATE TABLE IF NOT EXISTS "posts" ("id" text PRIMARY KEY NOT NULL, "user_id" text NOT NULL, "user_name" text DEFAULT '', "category" text DEFAULT 'work', "body" text NOT NULL, "media" text DEFAULT '', "audio" text DEFAULT '', "status" text DEFAULT 'pending', "likes" integer DEFAULT 0, "auto_approved" boolean DEFAULT false, "moderated_by" text DEFAULT '', "moderated_at" bigint DEFAULT 0, "created_at" bigint NOT NULL);
CREATE TABLE IF NOT EXISTS "questions" ("id" text PRIMARY KEY NOT NULL, "category" text NOT NULL, "title" text NOT NULL, "options" jsonb NOT NULL, "correct" integer NOT NULL, "explanation" text DEFAULT '', "source" text DEFAULT '', "seconds" integer DEFAULT 25, "kind" text DEFAULT 'text', "media" text DEFAULT '', "status" text DEFAULT 'approved', "author" text DEFAULT '');
CREATE TABLE IF NOT EXISTS "sessions" ("token" text PRIMARY KEY NOT NULL, "user_id" text NOT NULL, "csrf" text DEFAULT '' NOT NULL, "expires" bigint NOT NULL);
CREATE TABLE IF NOT EXISTS "settings" ("key" text PRIMARY KEY NOT NULL, "value" text NOT NULL);
CREATE TABLE IF NOT EXISTS "stories" ("id" text PRIMARY KEY NOT NULL, "user_id" text NOT NULL, "user_name" text DEFAULT '', "category" text DEFAULT 'general', "title" text NOT NULL, "options" jsonb DEFAULT '[]'::jsonb, "correct" integer DEFAULT 0, "explanation" text DEFAULT '', "media" text DEFAULT '', "status" text DEFAULT 'pending', "auto_approved" boolean DEFAULT false, "moderated_by" text DEFAULT '', "created_at" bigint NOT NULL, "expires_at" bigint NOT NULL);
CREATE TABLE IF NOT EXISTS "tournament_players" ("tournament_id" text NOT NULL, "user_id" text NOT NULL, "score" integer DEFAULT 0, "rank" integer DEFAULT 0, "joined_at" bigint NOT NULL, CONSTRAINT "tournament_players_tournament_id_user_id_pk" PRIMARY KEY("tournament_id","user_id"));
CREATE TABLE IF NOT EXISTS "tournaments" ("id" text PRIMARY KEY NOT NULL, "title" text NOT NULL, "category" text DEFAULT 'general', "starts_at" bigint NOT NULL, "ends_at" bigint NOT NULL, "description" text DEFAULT '', "org_id" text DEFAULT '', "tribe_only" boolean DEFAULT false, "max_players" integer DEFAULT 500, "questions" jsonb DEFAULT '[]'::jsonb, "active" boolean DEFAULT true, "created_by" text DEFAULT '', "created_at" bigint NOT NULL);
CREATE TABLE IF NOT EXISTS "tribe_battle_scores" ("battle_id" text NOT NULL, "user_id" text NOT NULL, "tribe_id" text NOT NULL, "score" integer DEFAULT 0, "correct" integer DEFAULT 0, "answers" jsonb DEFAULT '[]'::jsonb, "created_at" bigint NOT NULL, CONSTRAINT "tribe_battle_scores_battle_id_user_id_pk" PRIMARY KEY("battle_id","user_id"));
CREATE TABLE IF NOT EXISTS "tribe_battles" ("id" text PRIMARY KEY NOT NULL, "tribe_a" text NOT NULL, "tribe_b" text NOT NULL, "category" text DEFAULT 'general', "status" text DEFAULT 'pending', "questions" jsonb DEFAULT '[]'::jsonb, "score_a" integer DEFAULT 0, "score_b" integer DEFAULT 0, "winner_id" text DEFAULT '', "created_by" text DEFAULT '', "starts_at" bigint DEFAULT 0, "ends_at" bigint DEFAULT 0, "created_at" bigint NOT NULL);
CREATE TABLE IF NOT EXISTS "tribe_invites" ("id" text PRIMARY KEY NOT NULL, "tribe_id" text NOT NULL, "user_id" text NOT NULL, "inviter_id" text NOT NULL, "status" text DEFAULT 'pending', "created_at" bigint NOT NULL);
CREATE TABLE IF NOT EXISTS "tribe_members" ("tribe_id" text NOT NULL, "user_id" text NOT NULL, "role" text DEFAULT 'member', "contributed_xp" integer DEFAULT 0, "joined_at" bigint NOT NULL, CONSTRAINT "tribe_members_tribe_id_user_id_pk" PRIMARY KEY("tribe_id","user_id"));
CREATE TABLE IF NOT EXISTS "tribes" ("id" text PRIMARY KEY NOT NULL, "name" text NOT NULL, "tag" text DEFAULT '' NOT NULL, "description" text DEFAULT '', "motto" text DEFAULT '', "logo_emoji" text DEFAULT '🛡️', "logo_color" text DEFAULT '#a98cf7', "owner_id" text NOT NULL, "max_members" integer DEFAULT 30, "wins" integer DEFAULT 0, "losses" integer DEFAULT 0, "xp" integer DEFAULT 0, "rating" integer DEFAULT 1000, "is_public" boolean DEFAULT true, "invite_code" text DEFAULT '', "created_at" bigint NOT NULL);
CREATE TABLE IF NOT EXISTS "uploads" ("id" text PRIMARY KEY NOT NULL, "owner" text NOT NULL, "path" text NOT NULL, "mime" text NOT NULL, "size" integer NOT NULL, "created_at" bigint NOT NULL);
CREATE TABLE IF NOT EXISTS "user_achievements" ("user_id" text NOT NULL, "achievement_id" text NOT NULL, "unlocked_at" bigint NOT NULL, CONSTRAINT "user_achievements_user_id_achievement_id_pk" PRIMARY KEY("user_id","achievement_id"));
CREATE TABLE IF NOT EXISTS "users" ("id" text PRIMARY KEY NOT NULL, "local_id" text, "name" text DEFAULT 'میهمان' NOT NULL, "avatar" jsonb DEFAULT '{}'::jsonb, "bio" text DEFAULT '', "email" text DEFAULT '', "phone" text DEFAULT '', "provider" text DEFAULT 'guest', "google_sub" text DEFAULT '', "role" text DEFAULT 'player', "org_id" text DEFAULT '', "xp" integer DEFAULT 0, "coins" integer DEFAULT 50, "cups" integer DEFAULT 0, "streak" integer DEFAULT 0, "wins" integer DEFAULT 0, "played" integer DEFAULT 0, "rating" integer DEFAULT 1000, "week_xp" integer DEFAULT 0, "level" integer DEFAULT 1, "interests" jsonb DEFAULT '[]'::jsonb, "friends" jsonb DEFAULT '[]'::jsonb, "is_private" boolean DEFAULT false, "banned" boolean DEFAULT false, "is_demo" boolean DEFAULT false, "last_seen" bigint DEFAULT 0, "last_daily" text DEFAULT '', "created_at" bigint NOT NULL, "extra" jsonb DEFAULT '{}'::jsonb);
CREATE INDEX IF NOT EXISTS "msg_pair_idx" ON "messages" USING btree ("sender","recipient");
CREATE INDEX IF NOT EXISTS "posts_status_idx" ON "posts" USING btree ("status");
CREATE INDEX IF NOT EXISTS "stories_status_idx" ON "stories" USING btree ("status");
CREATE INDEX IF NOT EXISTS "tribes_xp_idx" ON "tribes" USING btree ("xp");
CREATE INDEX IF NOT EXISTS "users_xp_idx" ON "users" USING btree ("xp");
CREATE INDEX IF NOT EXISTS "users_org_idx" ON "users" USING btree ("org_id");
CREATE INDEX IF NOT EXISTS "users_local_idx" ON "users" USING btree ("local_id");
`;
const pool = new Pool({ connectionString: databaseUrl });
try {
  await pool.query(SCHEMA_SQL);
  console.log("[init-db] Tables & indexes verified.");
} finally {
  await pool.end();
}
EOF_INIT_DB
fi

# ۳) بررسی و آماده‌سازی PostgreSQL و ساخت دیتابیس ایزوله bugamifi_db
echo "[۳/۹] بررسی سرویس PostgreSQL و دیتابیس اختصاصی ${DB_NAME}..."
if ! command -v psql >/dev/null 2>&1; then
  echo "در حال نصب PostgreSQL بدون دست‌زدن به تنظیمات سایر سرویس‌ها..."
  apt-get update -y
  apt-get install -y postgresql postgresql-contrib
fi

systemctl enable --now postgresql

mkdir -p "$DEPLOY_ROOT"
chmod 700 "$DEPLOY_ROOT"

if [ ! -f "$ENV_FILE" ]; then
  DB_PASS="$(head -c 24 /dev/urandom | base64 | tr -dc 'a-zA-Z0-9' | head -c 24)"
  sudo -u postgres psql -tAc "SELECT 1 FROM pg_roles WHERE rolname='${DB_USER}'" | grep -q 1 || \
    sudo -u postgres psql -c "CREATE USER ${DB_USER} WITH PASSWORD '${DB_PASS}';"
  sudo -u postgres psql -c "ALTER USER ${DB_USER} WITH PASSWORD '${DB_PASS}';"
  sudo -u postgres psql -tAc "SELECT 1 FROM pg_database WHERE datname='${DB_NAME}'" | grep -q 1 || \
    sudo -u postgres psql -c "CREATE DATABASE ${DB_NAME} OWNER ${DB_USER};"
  sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE ${DB_NAME} TO ${DB_USER};"

  cat > "$ENV_FILE" << EOF_ENV
NODE_ENV=production
PORT=${APP_PORT}
HOSTNAME=127.0.0.1
BASE_URL=https://${DOMAIN}
NEXT_TELEMETRY_DISABLED=1
DATABASE_URL=postgresql://${DB_USER}:${DB_PASS}@127.0.0.1:5432/${DB_NAME}
EOF_ENV
  chmod 640 "$ENV_FILE"
  echo "فایل تنظیمات محیطی در ${ENV_FILE} ساخته شد."
else
  echo "فایل ${ENV_FILE} از قبل وجود دارد؛ حفظ شد."
fi

# ۴) ساخت کاربر لینوکس محدود و پوشه‌های اجرایی و بک‌آپ
echo "[۴/۹] آماده‌سازی کاربر محدود ${APP_USER} و پوشه‌های ${LIVE_ROOT} و ${DATA_ROOT}..."
if ! id -u "$APP_USER" >/dev/null 2>&1; then
  useradd --system --no-create-home --shell /usr/sbin/nologin "$APP_USER"
fi

chown root:"$APP_USER" "$ENV_FILE"
chmod 640 "$ENV_FILE"
chmod 750 "$DEPLOY_ROOT"
chown root:"$APP_USER" "$DEPLOY_ROOT"

mkdir -p "$LIVE_ROOT" "$DATA_ROOT" "$BACKUP_DIR"
chown -R "$APP_USER":"$APP_USER" "$LIVE_ROOT" "$DATA_ROOT"

# ۵) نصب وابستگی‌ها و Build در پوشه incoming
echo "[۵/۹] نصب وابستگی‌ها و ساخت (Build) نسخه در ${INCOMING_DIR}..."
set -a
# shellcheck disable=SC1090
source "$ENV_FILE"
set +a

cd "$INCOMING_DIR"
if [ -f "package-lock.json" ]; then
  npm ci --no-audit --no-fund
else
  npm install --no-audit --no-fund
fi

npm run typecheck
npm run build

# ۶) ساخت غیرمخرب جدول‌های دیتابیس اختصاصی bugamifi_db
echo "[۶/۹] اطمینان از وجود جدول‌های دیتابیس در ${DB_NAME}..."
node init-db.mjs

# ۷) انتقال اتمیک و قابل بازگشت به /opt/bu-gamifi/app
echo "[۷/۹] آماده‌سازی نسخهٔ جدید و جایگزینی امن در ${LIVE_APP}..."
STAGE_APP="${LIVE_ROOT}/app-stage-${TIMESTAMP}"
mkdir -p "$STAGE_APP"

cp -a "${INCOMING_DIR}/.next" "$STAGE_APP/"
cp -a "${INCOMING_DIR}/public" "$STAGE_APP/"
cp -a "${INCOMING_DIR}/src" "$STAGE_APP/"
cp -a "${INCOMING_DIR}/node_modules" "$STAGE_APP/"
cp -a "${INCOMING_DIR}/package.json" "$STAGE_APP/"
[ -f "${INCOMING_DIR}/package-lock.json" ] && cp -a "${INCOMING_DIR}/package-lock.json" "$STAGE_APP/"
[ -f "${INCOMING_DIR}/next.config.ts" ] && cp -a "${INCOMING_DIR}/next.config.ts" "$STAGE_APP/"
[ -f "${INCOMING_DIR}/tsconfig.json" ] && cp -a "${INCOMING_DIR}/tsconfig.json" "$STAGE_APP/"
[ -f "${INCOMING_DIR}/postcss.config.mjs" ] && cp -a "${INCOMING_DIR}/postcss.config.mjs" "$STAGE_APP/"
[ -f "${INCOMING_DIR}/init-db.mjs" ] && cp -a "${INCOMING_DIR}/init-db.mjs" "$STAGE_APP/"

chown -R "$APP_USER":"$APP_USER" "$STAGE_APP"

PREV_BACKUP=""
if [ -d "$LIVE_APP" ]; then
  PREV_BACKUP="${BACKUP_DIR}/app-prev-${TIMESTAMP}"
  mv "$LIVE_APP" "$PREV_BACKUP"
  echo "بک‌آپ نسخه قبلی در ${PREV_BACKUP} ذخیره شد."
fi

mv "$STAGE_APP" "$LIVE_APP"

# ۸) تنظیم و راه‌اندازی سرویس systemd (فقط bu-gamifi.service)
echo "[۸/۹] تنظیم و راه‌اندازی سرویس ${SERVICE_NAME}..."
cat > "/etc/systemd/system/${SERVICE_NAME}" << EOF_SERVICE
[Unit]
Description=Gamifi 2 (${DOMAIN}) Next.js Service
After=network.target postgresql.service
Wants=postgresql.service

[Service]
Type=simple
User=${APP_USER}
Group=${APP_USER}
WorkingDirectory=${LIVE_APP}
EnvironmentFile=${ENV_FILE}
ExecStart=${LIVE_APP}/node_modules/.bin/next start -H 127.0.0.1 -p ${APP_PORT}
Restart=always
RestartSec=5
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF_SERVICE

systemctl daemon-reload
systemctl enable "$SERVICE_NAME"
systemctl restart "$SERVICE_NAME"

echo "در حال بررسی سلامت سرویس روی http://127.0.0.1:${APP_PORT}/api/health ..."
HEALTH_OK=0
for i in $(seq 1 25); do
  if curl -fsS "http://127.0.0.1:${APP_PORT}/api/health" | grep -q '"ok":true'; then
    HEALTH_OK=1
    break
  fi
  sleep 1
done

if [ "$HEALTH_OK" -ne 1 ]; then
  echo "[خطا] بررسی سلامت سرویس روی پورت ${APP_PORT} ناموفق بود!"
  journalctl -u "$SERVICE_NAME" -n 40 --no-pager || true
  if [ -n "$PREV_BACKUP" ] && [ -d "$PREV_BACKUP" ]; then
    echo "بازگردانی خودکار (Rollback) به نسخه قبلی..."
    mv "$LIVE_APP" "${BACKUP_DIR}/app-failed-${TIMESTAMP}"
    mv "$PREV_BACKUP" "$LIVE_APP"
    systemctl restart "$SERVICE_NAME" || true
  fi
  exit 1
fi
echo "سلامت برنامه و تزریق داده‌های اولیه روی 127.0.0.1:${APP_PORT} با موفقیت تأیید شد!"

# ۹) تنظیم ایزوله Nginx برای bu.gamifi.ir و دریافت گواهی HTTPS
echo "[۹/۹] تنظیم Nginx برای ${DOMAIN}..."
NGINX_AVAIL="/etc/nginx/sites-available/bu-gamifi"
NGINX_ENABLED="/etc/nginx/sites-enabled/bu-gamifi"

if [ ! -f "$NGINX_AVAIL" ] || ! grep -q "listen 443" "$NGINX_AVAIL" 2>/dev/null; then
  cat > "$NGINX_AVAIL" << EOF_NGINX
server {
    listen 80;
    listen [::]:80;
    server_name ${DOMAIN};

    client_max_body_size 25M;

    location / {
        proxy_pass http://127.0.0.1:${APP_PORT};
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_read_timeout 90s;
    }
}
EOF_NGINX
fi

ln -sfn "$NGINX_AVAIL" "$NGINX_ENABLED"

if nginx -t; then
  systemctl reload nginx
  echo "تنظیمات Nginx با موفقیت بارگذاری شد."
else
  echo "[خطا] تست تنظیمات Nginx ناموفق بود؛ فایل جدید غیرفعال شد تا به سایت‌های دیگر آسیبی نرسد."
  unlink "$NGINX_ENABLED" || true
  exit 1
fi

# تلاش غیرتعاملی برای دریافت گواهی HTTPS از طریق Certbot
if command -v certbot >/dev/null 2>&1; then
  echo "بررسی دریافت گواهی HTTPS برای ${DOMAIN}..."
  if certbot --nginx -d "$DOMAIN" --non-interactive --agree-tos --redirect 2>/dev/null || \
     certbot --nginx -d "$DOMAIN" --non-interactive --agree-tos --register-unsafely-without-email --redirect 2>/dev/null; then
    echo "گواهی HTTPS برای https://${DOMAIN}/ با موفقیت فعال شد!"
  else
    echo "------------------------------------------------------------"
    echo "[توجه] برنامه و Nginx کاملاً فعال هستند، اما صدور گواهی HTTPS"
    echo "منتظر ثبت رکورد DNS زیر دامنه ${DOMAIN} روی IP سرور (86.107.47.228) است."
    echo "پس از ثبت رکورد A برای bu در کلودفلر، فقط این فرمان را اجرا کنید:"
    echo "certbot --nginx -d ${DOMAIN} --non-interactive --agree-tos --register-unsafely-without-email --redirect"
    echo "------------------------------------------------------------"
  fi
fi

echo "============================================================"
echo " نصب با موفقیت کامل شد!"
echo " آدرس محلی:  http://127.0.0.1:${APP_PORT}/api/health"
echo " آدرس عمومی: https://${DOMAIN}/"
echo "============================================================"
