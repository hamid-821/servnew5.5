import pg from "pg";

const { Pool } = pg;
const databaseUrl = process.env.DATABASE_URL;

if (!databaseUrl) {
  console.error("[init-db] ERROR: DATABASE_URL is not set.");
  process.exit(1);
}

const SCHEMA_SQL = `
CREATE TABLE IF NOT EXISTS "achievements" (
  "id" text PRIMARY KEY NOT NULL,
  "title" text NOT NULL,
  "description" text DEFAULT '',
  "icon" text DEFAULT '🏆',
  "xp_reward" integer DEFAULT 50,
  "coin_reward" integer DEFAULT 25
);

CREATE TABLE IF NOT EXISTS "audit_log" (
  "id" integer PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
  "actor" text DEFAULT '',
  "action" text DEFAULT '',
  "target" text DEFAULT '',
  "created_at" bigint NOT NULL
);

CREATE TABLE IF NOT EXISTS "categories" (
  "id" text PRIMARY KEY NOT NULL,
  "name" text NOT NULL,
  "subtitle" text DEFAULT '',
  "icon" text DEFAULT 'globe',
  "color" text DEFAULT '#a98cf7',
  "tag" text DEFAULT '',
  "safety" integer DEFAULT 0,
  "active" integer DEFAULT 1
);

CREATE TABLE IF NOT EXISTS "daily_claims" (
  "user_id" text NOT NULL,
  "day" text NOT NULL,
  "coins" integer DEFAULT 25,
  "streak" integer DEFAULT 1,
  "created_at" bigint NOT NULL,
  CONSTRAINT "daily_claims_user_id_day_pk" PRIMARY KEY("user_id","day")
);

CREATE TABLE IF NOT EXISTS "follows" (
  "user_id" text NOT NULL,
  "target_id" text NOT NULL,
  "status" text DEFAULT 'approved',
  CONSTRAINT "follows_user_id_target_id_pk" PRIMARY KEY("user_id","target_id")
);

CREATE TABLE IF NOT EXISTS "messages" (
  "id" text PRIMARY KEY NOT NULL,
  "sender" text NOT NULL,
  "recipient" text NOT NULL,
  "body" text DEFAULT '',
  "media" text DEFAULT '',
  "created_at" bigint NOT NULL,
  "seen" integer DEFAULT 0
);

CREATE TABLE IF NOT EXISTS "notifications" (
  "id" text PRIMARY KEY NOT NULL,
  "user_id" text NOT NULL,
  "title" text NOT NULL,
  "body" text DEFAULT '',
  "link" text DEFAULT '',
  "created_at" bigint NOT NULL,
  "seen" integer DEFAULT 0
);

CREATE TABLE IF NOT EXISTS "org_members" (
  "org_id" text NOT NULL,
  "user_id" text NOT NULL,
  "status" text DEFAULT 'approved',
  "joined_at" bigint NOT NULL,
  CONSTRAINT "org_members_org_id_user_id_pk" PRIMARY KEY("org_id","user_id")
);

CREATE TABLE IF NOT EXISTS "organizations" (
  "id" text PRIMARY KEY NOT NULL,
  "name" text NOT NULL,
  "slug" text DEFAULT '' NOT NULL,
  "description" text DEFAULT '',
  "logo" text DEFAULT '⚡',
  "color" text DEFAULT '#f8c56c',
  "auto_tournament" boolean DEFAULT true,
  "member_count" integer DEFAULT 0,
  "created_at" bigint NOT NULL
);

CREATE TABLE IF NOT EXISTS "posts" (
  "id" text PRIMARY KEY NOT NULL,
  "user_id" text NOT NULL,
  "user_name" text DEFAULT '',
  "category" text DEFAULT 'work',
  "body" text NOT NULL,
  "media" text DEFAULT '',
  "audio" text DEFAULT '',
  "status" text DEFAULT 'pending',
  "likes" integer DEFAULT 0,
  "auto_approved" boolean DEFAULT false,
  "moderated_by" text DEFAULT '',
  "moderated_at" bigint DEFAULT 0,
  "created_at" bigint NOT NULL
);

CREATE TABLE IF NOT EXISTS "questions" (
  "id" text PRIMARY KEY NOT NULL,
  "category" text NOT NULL,
  "title" text NOT NULL,
  "options" jsonb NOT NULL,
  "correct" integer NOT NULL,
  "explanation" text DEFAULT '',
  "source" text DEFAULT '',
  "seconds" integer DEFAULT 25,
  "kind" text DEFAULT 'text',
  "media" text DEFAULT '',
  "status" text DEFAULT 'approved',
  "author" text DEFAULT ''
);

CREATE TABLE IF NOT EXISTS "sessions" (
  "token" text PRIMARY KEY NOT NULL,
  "user_id" text NOT NULL,
  "csrf" text DEFAULT '' NOT NULL,
  "expires" bigint NOT NULL
);

CREATE TABLE IF NOT EXISTS "settings" (
  "key" text PRIMARY KEY NOT NULL,
  "value" text NOT NULL
);

CREATE TABLE IF NOT EXISTS "stories" (
  "id" text PRIMARY KEY NOT NULL,
  "user_id" text NOT NULL,
  "user_name" text DEFAULT '',
  "category" text DEFAULT 'general',
  "title" text NOT NULL,
  "options" jsonb DEFAULT '[]'::jsonb,
  "correct" integer DEFAULT 0,
  "explanation" text DEFAULT '',
  "media" text DEFAULT '',
  "status" text DEFAULT 'pending',
  "auto_approved" boolean DEFAULT false,
  "moderated_by" text DEFAULT '',
  "created_at" bigint NOT NULL,
  "expires_at" bigint NOT NULL
);

CREATE TABLE IF NOT EXISTS "tournament_players" (
  "tournament_id" text NOT NULL,
  "user_id" text NOT NULL,
  "score" integer DEFAULT 0,
  "rank" integer DEFAULT 0,
  "joined_at" bigint NOT NULL,
  CONSTRAINT "tournament_players_tournament_id_user_id_pk" PRIMARY KEY("tournament_id","user_id")
);

CREATE TABLE IF NOT EXISTS "tournaments" (
  "id" text PRIMARY KEY NOT NULL,
  "title" text NOT NULL,
  "category" text DEFAULT 'general',
  "starts_at" bigint NOT NULL,
  "ends_at" bigint NOT NULL,
  "description" text DEFAULT '',
  "org_id" text DEFAULT '',
  "tribe_only" boolean DEFAULT false,
  "max_players" integer DEFAULT 500,
  "questions" jsonb DEFAULT '[]'::jsonb,
  "active" boolean DEFAULT true,
  "created_by" text DEFAULT '',
  "created_at" bigint NOT NULL
);

CREATE TABLE IF NOT EXISTS "tribe_battle_scores" (
  "battle_id" text NOT NULL,
  "user_id" text NOT NULL,
  "tribe_id" text NOT NULL,
  "score" integer DEFAULT 0,
  "correct" integer DEFAULT 0,
  "answers" jsonb DEFAULT '[]'::jsonb,
  "created_at" bigint NOT NULL,
  CONSTRAINT "tribe_battle_scores_battle_id_user_id_pk" PRIMARY KEY("battle_id","user_id")
);

CREATE TABLE IF NOT EXISTS "tribe_battles" (
  "id" text PRIMARY KEY NOT NULL,
  "tribe_a" text NOT NULL,
  "tribe_b" text NOT NULL,
  "category" text DEFAULT 'general',
  "status" text DEFAULT 'pending',
  "questions" jsonb DEFAULT '[]'::jsonb,
  "score_a" integer DEFAULT 0,
  "score_b" integer DEFAULT 0,
  "winner_id" text DEFAULT '',
  "created_by" text DEFAULT '',
  "starts_at" bigint DEFAULT 0,
  "ends_at" bigint DEFAULT 0,
  "created_at" bigint NOT NULL
);

CREATE TABLE IF NOT EXISTS "tribe_invites" (
  "id" text PRIMARY KEY NOT NULL,
  "tribe_id" text NOT NULL,
  "user_id" text NOT NULL,
  "inviter_id" text NOT NULL,
  "status" text DEFAULT 'pending',
  "created_at" bigint NOT NULL
);

CREATE TABLE IF NOT EXISTS "tribe_members" (
  "tribe_id" text NOT NULL,
  "user_id" text NOT NULL,
  "role" text DEFAULT 'member',
  "contributed_xp" integer DEFAULT 0,
  "joined_at" bigint NOT NULL,
  CONSTRAINT "tribe_members_tribe_id_user_id_pk" PRIMARY KEY("tribe_id","user_id")
);

CREATE TABLE IF NOT EXISTS "tribes" (
  "id" text PRIMARY KEY NOT NULL,
  "name" text NOT NULL,
  "tag" text DEFAULT '' NOT NULL,
  "description" text DEFAULT '',
  "motto" text DEFAULT '',
  "logo_emoji" text DEFAULT '🛡️',
  "logo_color" text DEFAULT '#a98cf7',
  "owner_id" text NOT NULL,
  "max_members" integer DEFAULT 30,
  "wins" integer DEFAULT 0,
  "losses" integer DEFAULT 0,
  "xp" integer DEFAULT 0,
  "rating" integer DEFAULT 1000,
  "is_public" boolean DEFAULT true,
  "invite_code" text DEFAULT '',
  "created_at" bigint NOT NULL
);

CREATE TABLE IF NOT EXISTS "uploads" (
  "id" text PRIMARY KEY NOT NULL,
  "owner" text NOT NULL,
  "path" text NOT NULL,
  "mime" text NOT NULL,
  "size" integer NOT NULL,
  "created_at" bigint NOT NULL
);

CREATE TABLE IF NOT EXISTS "user_achievements" (
  "user_id" text NOT NULL,
  "achievement_id" text NOT NULL,
  "unlocked_at" bigint NOT NULL,
  CONSTRAINT "user_achievements_user_id_achievement_id_pk" PRIMARY KEY("user_id","achievement_id")
);

CREATE TABLE IF NOT EXISTS "users" (
  "id" text PRIMARY KEY NOT NULL,
  "local_id" text,
  "name" text DEFAULT 'میهمان' NOT NULL,
  "avatar" jsonb DEFAULT '{}'::jsonb,
  "bio" text DEFAULT '',
  "email" text DEFAULT '',
  "phone" text DEFAULT '',
  "provider" text DEFAULT 'guest',
  "google_sub" text DEFAULT '',
  "role" text DEFAULT 'player',
  "org_id" text DEFAULT '',
  "xp" integer DEFAULT 0,
  "coins" integer DEFAULT 50,
  "cups" integer DEFAULT 0,
  "streak" integer DEFAULT 0,
  "wins" integer DEFAULT 0,
  "played" integer DEFAULT 0,
  "rating" integer DEFAULT 1000,
  "week_xp" integer DEFAULT 0,
  "level" integer DEFAULT 1,
  "interests" jsonb DEFAULT '[]'::jsonb,
  "friends" jsonb DEFAULT '[]'::jsonb,
  "is_private" boolean DEFAULT false,
  "banned" boolean DEFAULT false,
  "is_demo" boolean DEFAULT false,
  "last_seen" bigint DEFAULT 0,
  "last_daily" text DEFAULT '',
  "created_at" bigint NOT NULL,
  "extra" jsonb DEFAULT '{}'::jsonb
);

CREATE INDEX IF NOT EXISTS "msg_pair_idx" ON "messages" USING btree ("sender","recipient");
CREATE INDEX IF NOT EXISTS "posts_status_idx" ON "posts" USING btree ("status");
CREATE INDEX IF NOT EXISTS "stories_status_idx" ON "stories" USING btree ("status");
CREATE INDEX IF NOT EXISTS "tribes_xp_idx" ON "tribes" USING btree ("xp");
CREATE INDEX IF NOT EXISTS "users_xp_idx" ON "users" USING btree ("xp");
CREATE INDEX IF NOT EXISTS "users_org_idx" ON "users" USING btree ("org_id");
CREATE INDEX IF NOT EXISTS "users_local_idx" ON "users" USING btree ("local_id");
`;

const pool = new Pool({ connectionString: databaseUrl });

try {
  await pool.query(SCHEMA_SQL);
  console.log("[init-db] Schema tables and indexes verified successfully.");
} catch (err) {
  console.error("[init-db] Schema initialization failed:", err);
  process.exit(1);
} finally {
  await pool.end();
}
