#!/usr/bin/env bash
set -euo pipefail

# ==============================================================================
# اسکریپت به‌روزرسانی امن (Update + Rollback خودکار) برای: bu.gamifi.ir
# فرمان اجرا:
#   cd /root/bu-gamifi-deploy/incoming && bash update.sh
# ==============================================================================

export DEBIAN_FRONTEND=noninteractive
export CI=true
export NEXT_TELEMETRY_DISABLED=1

DOMAIN="bu.gamifi.ir"
APP_PORT="3105"
SERVICE_NAME="bu-gamifi.service"
APP_USER="bugamifi"
DEPLOY_ROOT="/root/bu-gamifi-deploy"
INCOMING_DIR="${DEPLOY_ROOT}/incoming"
ENV_FILE="${DEPLOY_ROOT}/app.env"
LIVE_ROOT="/opt/bu-gamifi"
LIVE_APP="${LIVE_ROOT}/app"
DATA_ROOT="/var/lib/bu-gamifi"
BACKUP_DIR="${DATA_ROOT}/backups"
TIMESTAMP="$(date +%Y%m%d-%H%M%S)"

echo "============================================================"
echo " شروع به‌روزرسانی امن ${DOMAIN} (${SERVICE_NAME})"
echo "============================================================"

if [ "$(id -u)" -ne 0 ]; then
  echo "[خطا] لطفاً با کاربر root اجرا کنید."
  exit 1
fi

if [ ! -f "$ENV_FILE" ] || [ ! -d "$LIVE_APP" ]; then
  echo "[توجه] نصب اولیه هنوز انجام نشده است؛ اجرای خودکار deploy.sh..."
  exec bash "${INCOMING_DIR}/deploy.sh"
fi

if [ ! -f "${INCOMING_DIR}/package.json" ] || [ ! -f "${INCOMING_DIR}/src/db/schema.ts" ]; then
  echo "[خطا] فایل‌های نسخه جدید (package.json و src/db/schema.ts) در ${INCOMING_DIR} یافت نشدند."
  exit 1
fi

set -a
# shellcheck disable=SC1090
source "$ENV_FILE"
set +a

mkdir -p "$BACKUP_DIR"

# ۱) بک‌آپ زمان‌دار از دیتابیس PostgreSQL اختصاصی (bugamifi_db)
echo "[۱/۵] تهیه بک‌آپ زمان‌دار از دیتابیس در ${BACKUP_DIR}..."
DB_DUMP_FILE="${BACKUP_DIR}/db-backup-${TIMESTAMP}.sql"
if command -v pg_dump >/dev/null 2>&1 && [ -n "${DATABASE_URL:-}" ]; then
  pg_dump "$DATABASE_URL" > "$DB_DUMP_FILE"
  chmod 600 "$DB_DUMP_FILE"
  echo "بک‌آپ دیتابیس ذخیره شد: ${DB_DUMP_FILE}"
fi

# ۲) نصب وابستگی‌ها، تست TypeScript و Build در incoming
echo "[۲/۵] اجرای نصب وابستگی‌ها و Build در ${INCOMING_DIR}..."
cd "$INCOMING_DIR"
if [ -f "package-lock.json" ]; then
  npm ci --no-audit --no-fund
else
  npm install --no-audit --no-fund
fi

npm run typecheck
npm run build

if [ -f "${INCOMING_DIR}/init-db.mjs" ]; then
  node "${INCOMING_DIR}/init-db.mjs"
fi

# ۳) ساخت نسخه آماده در پوشه موقت و جایگزینی قابل بازگشت
echo "[۳/۵] آماده‌سازی نسخه جدید و جایگزینی قابل بازگشت..."
STAGE_APP="${LIVE_ROOT}/app-stage-${TIMESTAMP}"
mkdir -p "$STAGE_APP"

cp -a "${INCOMING_DIR}/.next" "$STAGE_APP/"
cp -a "${INCOMING_DIR}/public" "$STAGE_APP/"
cp -a "${INCOMING_DIR}/src" "$STAGE_APP/"
cp -a "${INCOMING_DIR}/node_modules" "$STAGE_APP/"
cp -a "${INCOMING_DIR}/package.json" "$STAGE_APP/"
[ -f "${INCOMING_DIR}/package-lock.json" ] && cp -a "${INCOMING_DIR}/package-lock.json" "$STAGE_APP/"
[ -f "${INCOMING_DIR}/next.config.ts" ] && cp -a "${INCOMING_DIR}/next.config.ts" "$STAGE_APP/"
[ -f "${INCOMING_DIR}/tsconfig.json" ] && cp -a "${INCOMING_DIR}/tsconfig.json" "$STAGE_APP/"
[ -f "${INCOMING_DIR}/postcss.config.mjs" ] && cp -a "${INCOMING_DIR}/postcss.config.mjs" "$STAGE_APP/"
[ -f "${INCOMING_DIR}/init-db.mjs" ] && cp -a "${INCOMING_DIR}/init-db.mjs" "$STAGE_APP/"

chown -R "$APP_USER":"$APP_USER" "$STAGE_APP"

PREV_BACKUP="${BACKUP_DIR}/app-prev-${TIMESTAMP}"
mv "$LIVE_APP" "$PREV_BACKUP"
mv "$STAGE_APP" "$LIVE_APP"

# ۴) ری‌استارت فقط سرویس bu-gamifi.service
echo "[۴/۵] ری‌استارت سرویس ${SERVICE_NAME}..."
systemctl restart "$SERVICE_NAME"

# ۵) بررسی سلامت (Health Check) و Rollback خودکار در صورت خطا
echo "[۵/۵] بررسی سلامت API روی پورت ${APP_PORT}..."
HEALTH_OK=0
for i in $(seq 1 25); do
  if curl -fsS "http://127.0.0.1:${APP_PORT}/api/health" | grep -q '"ok":true'; then
    HEALTH_OK=1
    break
  fi
  sleep 1
done

if [ "$HEALTH_OK" -ne 1 ]; then
  echo "[خطا] نسخه جدید از تست سلامت رد شد! بازگشت خودکار (Rollback) به نسخه قبلی..."
  mv "$LIVE_APP" "${BACKUP_DIR}/app-failed-${TIMESTAMP}"
  mv "$PREV_BACKUP" "$LIVE_APP"
  systemctl restart "$SERVICE_NAME"
  echo "نسخه قبلی بازیابی و سرویس ری‌استارت شد."
  exit 1
fi

echo "============================================================"
echo " به‌روزرسانی ${DOMAIN} با موفقیت کامل انجام شد!"
echo " بک‌آپ کد قبلی: ${PREV_BACKUP}"
echo " بک‌آپ دیتابیس:  ${DB_DUMP_FILE}"
echo "============================================================"
